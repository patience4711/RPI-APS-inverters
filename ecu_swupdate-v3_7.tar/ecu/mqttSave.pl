#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

# the pamaters are mqtEn mqtRet mqtAdres mqtPort mqtinTopic mqtoutTopic mqtAuth mqtuser mqtpas format
print"running script mqttSave...<br>\n";
$| = 1;

my $query = new CGI;
my $enabled = $query->param('mqtEn');
my $retain = $query->param('mqtRet');
my $address = $query->param('mqtAdres'); 
my $port = $query->param('mqtPort'); 
my $intopic = $query->param('mqtIn');
my $outtopic = $query->param('mqtOut');
my $auth = $query->param('mqtAuth');
my $username = $query->param('mqtUser');
my $password = $query->param('mqtPas');
my $format = $query->param('mqtFormat');

# the checkbox returns only a value when checked
# so if there is no define the value stays 0

if(defined($enabled)) { $enabled=1;} else {$enabled=0;}
if(defined($retain)) { $retain=1;} else {$retain=0;}
if(defined($auth)) { $auth=1;} else {$auth=0;}

#we are going to save the data
my $fileName = "/var/www/ecu_data/mqttConfig.json"; 
#print "\nfileName = $fileName<br>\n";

my $json = qq{'{"enabled":$enabled,"retain":$retain,"address":"$address","port":$port,"intopic":"$intopic","outtopic":"$outtopic","auth":$auth,"username":"$username","password":"$password","format":$format}'};

print("contents = $json \n<br>");
my $savecommand = "echo $json > $fileName";
#print("savecommand = $savecommand \n");
system($savecommand);

print "inverter data saved\n<br>";
print "HTTP:1/1 200 OK";

