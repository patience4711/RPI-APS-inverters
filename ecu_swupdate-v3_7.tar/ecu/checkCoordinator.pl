#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running script checkCoordinator.pl...<br>\n";
print "calling checkCoordinator.cgi\n";
$| = 1;

# my $query = new CGI;
# my $nr = $query->param('normal');
# print "argument is $nr <br>";


my $command = "sudo /usr/lib/cgi-bin/ecu/checkCoordinator.cgi"; 
print "command to run = $command<br>";

system($command);

print "command runned<br>";
print "HTTP:1/1 200 OK";

