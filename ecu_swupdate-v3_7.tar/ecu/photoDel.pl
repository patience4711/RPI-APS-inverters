#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamaters are iv sel in mqidx pan1 pan2 pan3 pan4
print"running script photoDel.pl...<br>\n";
$| = 1;

#we are going to delete the photo file
my $fileName = "/var/www/html/pics/ecu_photo.jpg"; 
print "fileName to delete = $fileName\n<br>";
my $deleteCmd="rm $fileName";
print "deletecommand = $deleteCmd \n<br>";
system($deleteCmd);

print "\n<br>photo deleted\n<br>";
print "HTTP:1/1 200 OK";

