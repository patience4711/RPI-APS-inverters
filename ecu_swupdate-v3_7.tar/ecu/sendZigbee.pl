#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the paramater is cmb
print"running script sendZigbee.pl...<br>\n";
$| = 1;

my $query = new CGI;
my $zbt = $query->param('cmd');
print "argument is $zbt\n<br> ";

#we call testZigbee.cgi with arg cmd

my $testCmd="sudo /usr/lib/cgi-bin/ecu/testZigbee.cgi $zbt";
print "$testCmd\n<br>";
system($testCmd);

print "command processed\n<br>";
print "HTTP:1/1 200 OK";

