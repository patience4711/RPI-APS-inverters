#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

# the pamaters are iv sel in mqidx pan1 pan2 pan3 pan4
print"running script inverterSave...<br>\n";
$| = 1;

my $query = new CGI;
my $new = $query->param('new');
my $nr = $query->param('ivnr'); #nr
my $id = $query->param('ivid'); #id
my $is = $query->param('ivser'); #serial
my $tp = $query->param('invt'); # type
my $in = $query->param('in');   #name
my $mq = $query->param('mqidx'); # mosq idx
my $p1a = $query->param('pan1');
my $p2a = $query->param('pan2');
my $p3a = $query->param('pan3');
my $p4a = $query->param('pan4');

if(defined($new)) {
print "new inverter arguments are $new  $nr $is $tp $in $mq <br> ";
} else {
print "edit inverter arguments are $nr $is $tp $in $mq <br> ";
}

my $p1 = 0;
my $p2 = 0;
my $p3 = 0;
my $p4 = 0;
# the checkbox returns only a value when checked
# so if there is no define the value stays 0
if(defined($p1a)) { print " $p1";   $p1=1;}
if(defined($p2a)) { print " $p2";   $p2=1;}
if(defined($p3a)) { print " $p3";   $p3=1;}
if(defined($p4a)) { print " $p4\n"; $p4=1;}

#my $panels = "$panel1$panel2$panel3$panel4";
#print "<br>panels=$panels<br>";
#new ivnr iv in mqidx pan1 pan2 pan3 pan4

#we are going to save the data
my $fileName = "/var/www/ecu_data/inverters/invProperties$nr"; 
#print "\nfileName = $fileName<br>\n";
 

# if the arg new exists and file not already exists 
# we must increase the counter
if(defined($new) && !-e $fileName) {

  print "new file, need to increment inverterCount\n<br>";
  my $countFile="/var/www/ecu_data/inverterCount.txt";
  my $invCount="";
  if (-e $countFile) 
  {
    open(FH, "<", $countFile) || die $!;
    while ( <FH> ){
    $invCount = $_;
  }
    close(FH);
  } 
    else 
  {
    print"the file inverterCount.txt does not exist\n";
    $invCount="0";
  }
    my $count2int = int($invCount) +1;
    print "inverterCount.txt incremented to $count2int\n<br>";
    system "echo $count2int > $countFile";
} else {
  print "the inverter already existed, no counter increment\n<br>"; 
}

my $json = qq{'{"id":"$id","serial":$is,"type":$tp,"name":"$in","idx":"$mq","panels":[$p1, $p2, $p3, $p4]}'};

print("contents = $json \n");
my $savecommand = "echo $json > $fileName";
print("savecommand = $savecommand \n");
system($savecommand);

print "inverter data saved\n<br>";
# we also set invChoice to the current (new) inverter
my $fname = '/ramdisk/invChoice.txt';
my $savecom = "echo $nr > $fname";
print("savecom = $savecom \n<br>");
system($savecom);

print "HTTP:1/1 200 OK";

