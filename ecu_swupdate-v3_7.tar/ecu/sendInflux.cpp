
#include <iostream>
//#include <cstring>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>



#include "influxdb.hpp"
using namespace std;
int which;

string forMat(float pi, int pr)
{
std::stringstream stream;
stream << std::fixed << std::setprecision(pr) << pi;
std::string s = stream.str();
return s;
}
#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

int main (int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>Hello World - First CGI Program</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>testprogram.cgi running</h4>\n";

string what;
float power;
float energy;
string readdata;
//   int which;
   if(argc > 3)
   {
       using std::atoi;
       which = atoi(argv[3]);
       power = stof(argv[1]);
       energy = stof(argv[2]);
       what = string(argv[3]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: not enough arguments supplied \n<br>";
       return(3);
    }

// we must send a null value for power and the real value for energy
// this value we have to read from the datafile

  char str[1];
  sprintf(str, "%d", which);

/*  
string ourDatafile="/ramdisk/inverterData" + string(str);

    if(fexists(ourDatafile))
    {
       std::ifstream t(ourDatafile);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
       RSJresource my_resource (readdata);
       energy = my_resource["totalen"].as<string>();
    } else {
      energy = "0";
    }
*/
//string dbCommand ="curl -i -XPOST 'http:\/\/localhost:8086/write?db=test' --data-binary 'power" + to_string(which) + ", p=" + forMat(totalpw, 2) + "'";

//string dbCommand = "curl -i -XPOST 'http:\/\/localhost:8086/write?db=invPower' --data-binary 'power" + what + " p=" + forMat(power, 1) + "'";

//cout << "dbCommand = " << dbCommand << "\n<br>"<< endl;

//system(dbCommand.c_str());


string dbCmd = "curl -i -XPOST 'http:\/\/localhost:8086/write?db=invData' --data-binary 'inv" + what + " p=" + forMat(power, 1) + ",e=" + forMat(energy,1) + "'";

cout << "dbCmd = " << dbCmd << "\n<br>"<< endl;

system(dbCmd.c_str());//cout << "ret = " << ret << endl << "\n<br>resp = " << resp << endl;

//ret=0;

   return 0;
}
