#!/usr/bin/python

import datetime
from suntime import Sun, SunTimeException
import json
import os
with open ("/var/www/ecu_data/settings.json", "r") as myfile:
    data=myfile.read().rstrip()

jsondata = json.loads(data)
latitude = jsondata['latitude']
longitude = jsondata['longitude']
offset = jsondata['offset']

sun= Sun(latitude, longitude)

today_sr = sun.get_local_sunrise_time()
today_ss = sun.get_local_sunset_time()

rise = format(today_sr.strftime('%H:%M')) 
set = format(today_ss.strftime('%H:%M'))

pstt = today_sr + datetime.timedelta(minutes = offset)
pstp = today_ss - datetime.timedelta(minutes = offset)

pollstart = format(pstt.strftime('%H:%M'))
pollstop = format(pstp.strftime('%H:%M'))

print("pollstart", pollstart, " pollstop ", pollstop, " sunrise ", rise, " sunset ", set)

pstartminutes = int(format(pstt.strftime('%H'))) * 60 + int(format(pstt.strftime('%M')))
pstopminutes = int(format(pstp.strftime('%H'))) * 60 + int(format(pstp.strftime('%M')))

print("pstartminutes", pstartminutes, " pstopminutes ", pstopminutes)

with open ("/var/www/ecu_data/startstop.txt", "w") as myfile:
    myfile.write(pollstart)
    myfile.write('\n')
    myfile.write(pollstop)
    myfile.write('\n')
    myfile.write(rise)
    myfile.write('\n')
    myfile.write(set)
    myfile.write('\n')
    myfile.write(str(pstartminutes))
    myfile.write('\n')
    myfile.write(str(pstopminutes))

command= "echo \"<br>sun.py : calculated sunrise / sunset \" >> /ramdisk/ecu_log.txt"
os.system(command)
