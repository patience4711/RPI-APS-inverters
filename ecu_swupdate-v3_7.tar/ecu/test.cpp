
//this program reeds an zigbee message from command line and sends it
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <sstream>
#include <iomanip>
#include <ctime>
using namespace std;

//char initCmd[254]={0};
char inMessage[512];
int readCounter = 0;
int fd;



#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

void edit2ndline() {
// first we have to find the date of yesterdat
    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);

    --ptm->tm_mday; // Move back one day
    mktime(ptm); // Normalize

    char baffer[11];

//strftime(buffer, sizeof(buffer), "%a %b %d %H:%M:%S %Y", date);
    strftime(baffer, sizeof(baffer), "%Y-%m-%d", ptm);
    cout << "baffer = " << baffer << "\n" << endl;    
   // now we have to appned this value to /var/www/ecu_data/customQdate.txt
   // first delete the last line
   // we first read the first line
  ifstream infile("/var/www/ecu_data/customQdate.txt");

  if (infile.good())
  {
    string sLine;
    getline(infile, sLine);
    cout << sLine << endl;
    string cd1 = "echo " + sLine + " > /var/www/ecu_data/customQdate.txt";
    cout << "cd1 = " << cd1 << "<br>\n" << endl;
    system(cd1.c_str());
    //now apped baffer
    string s;
    s += baffer;
    string cd2 = "echo " + s + " >> /var/www/ecu_data/customQdate.txt";
    cout << "cd2 = " << cd2 << "<br>\n" << endl;
    system(cd2.c_str()); 
 }
}

int main (int argc, char **argv)
{

   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running test.cgi</h4>\n";

  char initCmd[30]={""};


    //if(which == 1){normalOps = true;}

    if (wiringPiSetup () == -1) /* initializes wiringPi setup */
    {
      
      cout << "unable to start wiringPi\n<br>" << endl;
      return 1;  
    }
       else 
    {
    cout << "wiringPi started\n<br>" << endl;
    }

// start the serial port
//int serial_port;
//  int fd;
  if ((fd = serialOpen("/dev/serial0", 115200)) < 0)
  {
    cout << "unable to open serial_port serial0\n<br>" << endl;
    return(0);
  }
  // construct the command now we put len and checksum
           
    edit2ndline();  
 
  serialClose(fd);
  return 0;
//exit(0);
}

/* sofar found that a globally defined oper works 
*/

