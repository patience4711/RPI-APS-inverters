#!/bin/bash

# this script starts the normal wifi and reboots

echo "closing ap...
/bin/bash /home/pi/normal.sh
echo "rebooting......
sudo /sbin/reboot
echo "HTTP/1.1 200 OK"
