#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>

#include <math.h>
#include <sstream>
#include <iomanip>

using namespace std;

#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running setPasswd.cgi</h4>\n";

// we need arguments for user and passwd
string user;
string pass;
//   int which;
   if(argc > 2)
   {
       
       user = string((argv[1]));
       pass = string(argv[2]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "not enough arguments provided\n<br>" << endl;
       return 1;
    }


// we start with making the log empty
  string pasCmd = "htpasswd -bc /etc/htpasswd/.htpasswd " + user + " " + pass;
  cout << "the command = " << pasCmd << "\n<br>" << endl;
  system(pasCmd.c_str());

return 0;
}
// end main

 


