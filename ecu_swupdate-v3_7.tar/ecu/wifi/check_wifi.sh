#!/usr/bin/env bash

#dit script wordt gestart door de service wificheck.service
#we weten dat pogingen om te verbinden geheel achter de rug zijn.

#/usr/bin/python /usr/lib/cgi-bin/radio/display/matrix1x.py "check wifi..."
echo $(date) > /home/pi/check.txt

/bin/sleep 20
var="iwgetid -r" 

eval "$var"
y=$(eval "$var")

if [ ! -z "$y" ]; then
    _IP=$(hostname -I) || true
    printf 'Skipping WiFi Connect\n'
    echo "check_wificonnect says: connected to $y" >> /usr/lib/cgi-bin/ecu/wifi/check.txt

    #schrijf het ip nummer weg
    echo "$_IP">/var/www/ecu_data/myipnr.txt

    /bin/sleep 60

# if there was no ip we are not connected, We start AP now
else
    echo "Starting WiFi Connect\n"
    # we first set the ip settings to dhcp
    # otherwise the accesspoint wont start properly
    /usr/bin/perl /usr/lib/cgi-bin/ecu/wifi/wifi_reset.pl
    

    /usr/sbin/service hostapd stop >> check.txt
    ifdown --force wlan0
    /sbin/iwconfig wlan0 mode Managed
    ifconfig wlan0 192.168.4.1
    ifconfig wlan0 up >> check.txt
    /bin/sleep 10
    /usr/sbin/service hostapd start >> check.txt
    iptables -t nat -A PREROUTING -p tcp -m tcp -s 192.168.4.0/24 --dport 80 -j DNAT --to-destination 192.168.4.1
    iptables -t nat -A PREROUTING -p tcp -m tcp -s 192.168.4.0/24 --dport 443 -j DNAT --to-destination 192.168.4.1
    /usr/sbin/service dnsmasq start >> check.txt

echo $(date) > /home/pi/check.txt
echo "Geen wifi, AP opgestart" >> check.txt

# we can try to reboot after 5 minutes. This means a retry to connect


/bin/sleep 300

# now we have to check if there was a static ip set and set this again
file="/var/www/ecu_data/wifistatus.txt"
status=$(cat "$file")
echo $status
if [ $status = "static" ]
then
   cp /etc/network/interfaces_stat /etc/network/interfaces
   echo "wifistatus revised"
fi

perl /usr/lib/cgi-bin/ecu/system/reboot.pl
fi
