#!/usr/bin/perl
#Dit script wordt uitgevoerd om de wificredentials op te slaan 
#via een sh script wifi_conf.sh
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
# call with ssid= pswd= user= pwd=
my $query = new CGI;

my $bauser = $query->param('user');
my $bapass = $query->param('pwd');

print "running script setPasswd.pl ";
#print $ssid."<br>";
#print $pswd."<br>";

my $authCmd = "sudo /usr/lib/cgi-bin/ecu/wifi/setPasswd.cgi $bauser $ bapass";
print $authCmd;
system ($authCmd);
print "HTTP/1.1 200 OK";

