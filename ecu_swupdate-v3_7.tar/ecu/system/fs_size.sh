#!/bin/bash
df -h | grep /dev/root > /var/www/ecu_data/fs_size.txt
#df -h > /var/www/radio_data/diskinfo.txt

