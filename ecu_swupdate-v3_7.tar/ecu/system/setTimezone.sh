#!/bin/bash

#read tijdzone.txt
read -r tijdzone</var/www/ecu_data/timezone_temp.txt
echo $tijdzone
echo $tijdzone | tr "\n" " "
tijdzone=$(echo $tijdzone|tr -d '\n')
echo $tijdzone

if [ $(echo "$tijdzone" | wc -l) -gt 1 ];
then
    echo "new line present"
else
    echo " no new lines."
fi

if [ "$tijdzone" != "error" -a "$tijdzone" != "nothing" ];
then
timedatectl set-timezone $tijdzone 2> /usr/lib/cgi-bin/ecu/system/tijdzone.txt

timedatectl show > /var/www/ecu_data/timezone.txt

echo nothing > /var/www/ecu_data/timezone_temp.txt 

else
echo $tijdzone
fi
