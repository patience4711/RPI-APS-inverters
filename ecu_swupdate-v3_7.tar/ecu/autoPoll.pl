#!/usr/bin/perl
use strict;
use warnings;
use DateTime;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the parameter is cmb
# this script runs every 5 minutes
# it checks if it is day or night time
# and polls all inverters when autopollflag is set
# the parameter is cmb


print"running script autoPoll.pl...<br>\n";
$| = 1;

sub getLoggingTime {

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
    my $nice_timestamp = sprintf ( "%02d:%02d:%02d",
                                   $hour,$min,$sec);
    return $nice_timestamp;
}

sub writeNull() {
        # for all inverters we check if there is an invData file
        # if yes 
        # we reset all values in all existing datafiles
        # and we insert a null values in our database
        my @a = (0..8);
        for(@a)
        {
             # we must check if the inverter exixts
             # datafiles are removed at midNight 
             # so we check if invProperties exists insteat
             # my $file="/ramdisk/invData$_";
             my $file="/var/www/ecu_data/inverters/invProperties$_";
             print "file=$file";
             if (-e $file)
             {
                # write null values into the datafile / ramdisk/invData$_
                # if the datafile was removed at midNight in which case the
                # invdataNull.cgi wil make a new datafile with null values,
                # otherwise all values are set to null except totalen.
                my $nullcmd = "/usr/lib/cgi-bin/ecu/invdataNull.cgi $_";
                print "$nullcmd \n<br>";
                system($nullcmd);
                
                # write null values in the database invData
                my $cmd = "/usr/lib/cgi-bin/ecu/sendInflux.cgi 0 0 $_";
                print "cmd = $cmd \n<br>";
                system($cmd);
                # we should also mqtt the null values for this converter
                my $mosquittocmd = "/usr/lib/cgi-bin/ecu/sendMqtt.cgi $_";
                print "mosquittocmd = $mosquittocmd \n<br>";
                system($mosquittocmd);
                } # end if invData$_ exists
        } # end for loop
}# end sub

my $logfile = "/ramdisk/ecu_log.txt";
my $sleepflag = "/ramdisk/sleepFlag.txt";


#now we establish whether it is daytime or not
# we read the last 2 lines in startstop.txt
open my $fh,'<',"/var/www/ecu_data/startstop.txt" or die $!;
my $line = <$fh>;
$line = <$fh>;
$line = <$fh>;
$line = <$fh>;
my $startminutes = <$fh>;
my $stopminutes = <$fh>;
close $fh;
# now we compare this with the minutes from localtime
my $hour = (localtime)[2];
my $minute = (localtime)[1];
#print "hour = $hour \n";
#print "minute = $minute \n";
my $totalminutes = $minute + $hour*60;
print "current totalminutes = $totalminutes \n";
#my $logfile = "/ramdisk/ecu_log.txt";
#my $sleepflag = "/ramdisk/sleepFlag.txt";


# *******************************************************************
#                    d a y t i m e
# *******************************************************************
# line 51

if ( $totalminutes > $startminutes and $totalminutes < $stopminutes) 
{
  print "pollingtime\n"; 
  # we remove the file sleepFlag if exists
  # my $sleepflag = "/ramdisk/sleepFlag.txt";

  if(-e $sleepflag) 
  {
  # the sleepflag exists so we woke up
  # in this case we only write null values to our database and datafile
  # and than exit. So after the next 5 minutes we start to poll
  # first we remove the sleep flag
     my $systemCm = "rm $sleepflag";
     system($systemCm);
     # write in the journal that we woke up and what we did
     my $timestamp= getLoggingTime();
     my $toLog = "<br> $timestamp woke up from sleep, goodmorning!<br>going to perform the morning ritual";
     print "$toLog \n<br>";
     #my $logfile = "/ramdisk/ecu_log.txt";
     my $logCmd = "echo '$toLog' >> $logfile";
     system($logCmd);
     # write null values in invData for all relevant inverters
     writeNull();

    my $toLog2 = "<br>Wrote 0 in database invData,<br>1st poll in 5 min, now exit";

     my $logCmd2 = "echo '$toLog2' >> $logfile";
     system($logCmd2);
     exit(1);
  }
  # we are going to poll all inverters that have a properties file
  
   my @a = (0..8);
      for(@a)
      {
	# we must check if the inverter exixts
	my$filename="/var/www/ecu_data/inverters/invProperties$_";
	print "filename=$filename \n<br>";
	if (-e $filename) 
        {
	  my$autopollCmd = "sudo /usr/lib/cgi-bin/ecu/inverterPoll.cgi $_";
	  print "autopollCmd = $autopollCmd\n<br>";
	  my $result = system($autopollCmd);
	  print "result = $result \n<br>"; # result = 0 or 256 -1
 
          # if result = 0 the polling succeeded then we should mqtt
	     if($result == 0) 
	     {
	         my $mqttCommand = "/usr/lib/cgi-bin/ecu/sendMqtt.cgi $_"; 
	         system($mqttCommand);
	     } 

	  } 
	  else 
	  {
	  print "filename not exists, skipping<\n<br>";
	  } 

	} # end for loop
    } #end if autopollflag
#} # end is it polling time
else
{
# *******************************************************
#                     N I G H T T I M E
# *******************************************************
  # first check if the file sleepFlag not exist
  # if not, we create it, log that it is night time and
  # put all values to zero
  # line 98
  #my $sleepflag = "/ramdisk/sleepFlag.txt";
  if(! -e $sleepflag)
  {
  	# sleepflag does not exist so we create it
  	# now we write sleepFlag to prevent endless repetition
  	my $systemCmd = "echo \"sleep\" > $sleepflag";
  	system($systemCmd);
  	# the sleepflag is created now we log that it is nighttime
  	my $timestamp= getLoggingTime();
  	my $toLog = "<br> $timestamp sleep time start, goodnight";
  	print "$toLog \n<br>";
  	#my $logfile = "/ramdisk/ecu_log.txt";
  	my $logCmd = "echo '$toLog' >> $logfile";
  	system($logCmd);
  	# 
        # write null values in the database and datafiles
        writeNull();
        print "set sleepFlag and set null values\n<br>";        
  } # end if sleepFlag exixts
  else
  {
  print "sleepFlag was set, nothing to do\n<br>";
  }

} # end else ( it is nighttime)


print "command processed\n<br>";
print "HTTP:1/1 200 OK";




