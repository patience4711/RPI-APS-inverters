#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";

print"running script healthInflux.pl...<br>\n";
$| = 1;

my  $dbCmd = "curl -G http://localhost:8086/health";
print "$dbCmd \n<br>";
#print "<h4> ** query last 20 entries from $dat **</h4>";
print "<h4> ** health influxdb **</h4>";
my $result="";
$result=qx/$dbCmd/;

print "result=$result";
my $sub="ready for queries and writes";
if(index($result, $sub) != -1) {
print("<h4>influxdb is running</h4>");
} else { 
print("<h4>influxdb is currently not (yet) running</h4>");
}
print "\n healthInflux.pl ready\n<br>";
print "HTTP:1/1 200 OK";

