#!/usr/bin/perl

use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running chartDateSave.pl";
# test = ecuid=AABBCCDD1122 pw1=1234 pint=120 offs=22
my $query = new CGI;
my $datum = $query->param('datum');


#print "the received in settings.pl commando is:\n ";
#print "$ecu_id $user_pw $poll_int $offset $night_mode $aut_polling<br>\n";

#we gaan deze waarden opslaan in settings.txt
my $filename = '/var/www/ecu_data/chartDate.txt';

my $savecommand = "echo $datum > $filename";
print("savecommand = $savecommand \n<br>");
system($savecommand);

print "\n chartData.txt saved<br>\n<br>";
print "HTTP/1.1 200 OK";

