#!/usr/bin/perl
use strict;
use warnings;
#use JSON::Parse 'parse_json';
#use JSON qw( );

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamater is cmb
print"running script mqtt.pl...<br>\n";
$| = 1;


my $mqttConf = "/var/www/ecu_data/mqttConfig.json";

if (-e $mqttConf) {

my $json = do {
   open(my $json_fh, "<:encoding(UTF-8)", $mqttConf)
      or die("Can't open \$mqttConf\": $!\n");
   local $/;
   <$json_fh>
    };    

print $json;
my $place = index($json, "format");
#print "place = $place \n";
my $format = substr $json, $place+8, 1;
#print "format = $ format \n";
if($format = "1") {
print "format = $format";
}

  } else {
  print "filename not exists, skipping<\n<br>";
 } 


print "command processed\n<br>";
print "HTTP:1/1 200 OK";




