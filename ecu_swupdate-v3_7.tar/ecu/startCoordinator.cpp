#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <sstream>
using namespace std;

char initCmd[254]={0};
char inMessage[512];
int readCounter = 0;
int fd;
//string id_inv;
//string ecu_short;

// convert a char to Hex **********************************
int StrToHex(char str[])
{
    return (int)strtol(str, 0, 16);
}

// ************ calculate length of a message to send *****************
char* sLen(char Command[])
{
    char* bufferSln = new char[254];
    sprintf(bufferSln, "%02x", (strlen(Command) / 2 - 2));
    delayMicroseconds(250); //give memset a little bit of time to empty all the buffers

    uint8_t iToUpper = 0;
    while (bufferSln[iToUpper])
    {
        bufferSln[iToUpper] = toupper(bufferSln[iToUpper]);
        iToUpper++;
    }
    return bufferSln;
}

// *************  calculate  the checksum of the message ****************************
char *checkSum(char Command[])
{
    char* bufferCRC = new char[254];
    char bufferCRCdiezweite[254] = {0};

    strncpy(bufferCRC, Command, 2); //as starting
    delayMicroseconds(250);         //give memset

    for (uint8_t i = 1; i <= (strlen(Command) / 2 - 1); i++)
    {
        strncpy(bufferCRCdiezweite, Command + i * 2, 2);
        delayMicroseconds(250);
        sprintf(bufferCRC, "%02x", StrToHex(bufferCRC) ^ StrToHex(bufferCRCdiezweite));
        delayMicroseconds(250); //give memset a little bit of time to empty all the buffers
    }
    uint8_t iToUpper = 0;
     while (bufferCRC[iToUpper])
    {
        bufferCRC[iToUpper] = toupper(bufferCRC[iToUpper]);
        iToUpper++;
    }
    return bufferCRC;
}


void sendZigbee(char sendString[] )
{
  // print the FE first
     serialPutchar(fd, 0xFE);

     char bufferSend[3];
     for (uint8_t i = 0; i <= strlen(sendString) / 2 - 1; i++)
        {
         // we use 2 characters to make a byte
            strncpy(bufferSend, sendString + i * 2, 2);
            delayMicroseconds(250);                  
            serialPutchar(fd, StrToHex(bufferSend)); 
        }

//cout << "all cmds done" << endl;
}


#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}


// **********   wait for serail available ********************************
bool waitSerialAvailable()
{
  //We start with a delay
  unsigned long wait = millis();
  while ( serialDataAvail(fd) == 0 )
      {
      if ( millis() - wait > 2000) return false; // return false after 200
      }
  // if we are here there is something available
   delay(500); // to give the sender the time to write the data
   return true;
}


// *****************  format the incoming byte ***************************$
void processIncomingByte(int inByte)
{
char oneChar[10] = {0};
    sprintf(oneChar, "%02x", inByte);
    strncat(inMessage, oneChar, 2); // append
} // end of processIncomingByte


void readZigbee() {
  readCounter = 0;
  memset( &inMessage, 0, sizeof(inMessage) ); //zero out the
  delayMicroseconds(250);

  while ( serialDataAvail(fd) > 0 )
    {
      if (readCounter < 512)
      {
         processIncomingByte(serialGetchar(fd));
         readCounter ++;
       }
       else
       {
         serialGetchar(fd); // just read to empty the serial buff$
       }

       if (serialDataAvail(fd) == 0)  // the buffer is empty
         {

         uint16_t iToUpper = 0; // has to be 16bit because the received me$

         while (inMessage[iToUpper])
          {
             inMessage[iToUpper] = toupper(inMessage[iToUpper]);
             iToUpper++;
          }
        }
     }
        // now we should have catched inMessage
     if (serialDataAvail(fd) == 0)
     {
          //  _waiting_for_response = false;
          //  _ready_to_send = true;
      }
    //cleanIncoming(); // check for F8 and remove it
}



void sendCommands(bool norMal) {
string idInvers = "xxxxxxxxxxxx";
string ecuShort="xxxx";
string readdata;
char baseCmd[][254] = {
  "2605030103", // ok   this is a ZB_WRITE_CONFIGURATION CMD //changed to 01
  "410000",     // ok   ZB_SYS_RESET_REQ
  "26050108FFFF", // + ecu_id_reverse,  this is a ZB_WRITE_CONFIGURATION CMD
  "2605870100",  //ok
  "26058302",  // + ecu_id.substring(0,2) + ecu_id.substring(2,4),
  "2605840400000100", //ok
  "240014050F00010100020000150000",  //AF_REGISTER register an application.s en$
  "2600", //ok ZB_START_REQUEST
  // extra command for normal operations
  "2401FFFF1414060001000F1E", // cmd 6 + ecu_reverse
  "FBFB1100000D6030FBD3000000000000000004010281FEFE",
  };


    string fileToread="/var/www/ecu_data/ecuProperties";
    cout << "fileToread = " << fileToread << "\n<br>" << endl;
    if(fexists(fileToread)) {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
    } else {
    cout << fileToread << " not exists\n<br>" << endl;
    return;
    }
     RSJresource my_ecuRead (readdata);
    // cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
// is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
      idInvers = my_ecuRead["idinvers"].as<string>();
      cout << "idinvers from file = " << idInvers << "\n<br>" << endl;
      ecuShort = idInvers.substr(10, 2) + idInvers.substr(8, 2);
      cout << "ecushort  = " << ecuShort << "\n<br>" << endl;
// alter the base commands
      strncat(baseCmd[2], idInvers.c_str(), 12);
      strncat(baseCmd[4], ecuShort.c_str(), 4);
      strncat(baseCmd[8], idInvers.c_str(), 12);
  
      cout << "base commands edited\n<br>" << endl;
  //cout << "cmd 2 = " << baseCmd[2] << endl;
  //cout << "cmd 4 = " << baseCmd[4] << endl;

  for( int x=0; x < 8; x++ )
  {
    strcpy(initCmd, baseCmd[x]);
    strcpy(initCmd, strncat(sLen(initCmd), initCmd, sizeof(sLen(initCmd)) + sizeof(initCmd)));
    strcpy(initCmd, strncat(initCmd, checkSum(initCmd), sizeof(initCmd) + sizeof(checkSum(initCmd))));

    cout << "cmd  = " << initCmd << "\n<br>" << endl;
    sendZigbee(initCmd);
    waitSerialAvailable();
    readZigbee();
    if(readCounter > 0) 
    { 
      cout << "answer = " << inMessage << "\n<br>" << endl;
    } else { 
      cout << "no answer\n<br>" << endl;
    }
  } // end for loop

  if(norMal == 1) {
    cout << "extra cmd needed\n<br>" << endl;
    // now the normal operations command
    //strncat(baseCmd[8], id_inv.c_str(), 12);
    strncpy(initCmd, baseCmd[8], sizeof(baseCmd[8]));
    strncat(initCmd, baseCmd[9], sizeof(baseCmd[9]));
    strcpy(initCmd, strncat(sLen(initCmd), initCmd, sizeof(sLen(initCmd)) + sizeof(initCmd)));
    strcpy(initCmd, strncat(initCmd, checkSum(initCmd), sizeof(initCmd) + sizeof(checkSum(initCmd))));
    cout << "extra cmd = " << initCmd << "\n<br>" << endl;
    sendZigbee(initCmd);
    }
    cout << "all cmds done\n<br>" << endl;
}


int main (int argc, char **argv)
{

   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running startCoordinator.cgi</h4>\n";

   bool normalOps = false;
   int info;
   int which;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: no argument supplied\n<br>";
       return(3);
    }

    cout << "startCoordinator running with arg "<< which << "\n<br>" << endl;   
   if(which == 1){normalOps = true;}

   if (wiringPiSetup () == -1) /* initializes wiringPi setup */
   {
      
      cout << "unable to start wiringPi\n<br>" << endl;
      return 1;  
   }
    else 
   {
    
        pinMode(1, OUTPUT); // pin for the reset
        cout << "wiringPi started\n<br>" << endl;
   }

// start the serial port
//we open serial0 (portalias) should work for raspberry 2
  if ((fd = serialOpen("/dev/serial0", 115200)) < 0)
  {
    cout << "unable to open serial_port\n<br>" << endl;
    return(0);
  } else {
    cout << "opened port serial0 \n<br>" << endl;
    // if port open we read the serial buffer empty
  }


//  if ((fd = serialOpen("/dev/ttyS0", 115200)) < 0)
//  {
//    cout << "unable to open ttyS0\n<br>" << endl;
//    return(0);
//  }

// loop
// We start with a reset command
   digitalWrite(1, LOW);
   delay(500); 
   digitalWrite(1, HIGH);
   delay(1000);

  sendCommands(normalOps);
  cout << "coordinator should be running now\n<br>"<< endl;

   //memset( &initCmd, '\0', sizeof(initCmd) ); //zero out the
   //delayMicroseconds(250);
   serialClose(fd);
  return 0;
//exit(0);
}

 


