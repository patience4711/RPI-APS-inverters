<?php
/*
this page writes the begin and end dates for the statistical analysis.
*/

//echo "running writeQuerydates.php, arguments are :";
$beginDate = $_POST["startDate"];
$endDate = $_POST["endDate"];
//$finaldata = $postreq . "-01";

//echo "\n<br>beginDate = " . $beginDate;
//echo "\n<br>endDate = " . $endDate;

file_put_contents("/var/www/ecu_data/customQdate.txt", $beginDate . "\n" . $endDate . "\n");

?>
