<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="112">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />

<style>
body {
 background-color: #EEE;
}
table, th,  {
  border: 1px solid blue;
 border-collapse: collapse;
  font-size:14px; 
  padding:2px;
  }
.celwidth {
width: 90px;
border:none
}
.celwidth2 {
width: 80px;
border:none
}

.lijn3 {
borders:none;
border-bottom:1px solid black; 
height: 1px;
}

tr {height:38px;}

.linkbt {
  width: 78px;
  height: 40px;
  border-radius: 10px;
  border: solid 1px black;
  box-shadow:  2px 2px 4px black; /*r u u d */
  padding: 0px 2px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size:18px;
  font-weight: bold;
  background-image:
    radial-gradient(
      rgb(255, 255, 0), 
      #004d00 80%
    );
  color: black; 
}
.linkbt:hover {background-image: linear-gradient(red, yellow, green);}

.linkbt:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

a {
  text-decoration: none;
  color: green;
}
.nm {
  width:140px;
  font-size:20px;
  font-weight: bold;
  text-align: center;
  border: none;
  }

.haha {
Background-color:#e6b3cc;   
font-weight:bold; 
font-size:18px; 
text-align:center;
}
.hihi , .hihi2 {
border-collapse: collapse;
font-size:18px; 
text-align:center;
font-weight:bold; 
}
.hihi2 {Background-color:#e6b3cc; }  

@media only screen and (max-width: 800px) {
.celwidth {width: 120px;}
.celwidth2 {width: 90px;}

.nm {width: 160px;}
}

</style>
<SCRIPT language=JavaScript>

var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT>


</head>
<body style="font-family: 'lato',Verdana,Sans-serif;font-size:16px;">
<ul>
<?php
// test if client is local
if ((substr($_SERVER['REMOTE_ADDR'],0,8) == "192.168.") || ($_SERVER['REMOTE_ADDR'] == "127.0.0.1")) {
    // client is local
    echo "<li style='float: right;'><a href='/protected/menu.html'>menu</a>";
} 
?>



<li style='float: right;'><a href='details.php'>info</a>
<!-- <li style='float: right;'><a href='test.php?inv=2'>test</a> -->
</li>
</ul>


<div id='msect'><center>
<div id='bo'></div>
<span style = 'font-size: 22px;
  line-height: 34px;
  height: 35px;'
>
RPI ECU MAIN INVERTERDATA</span>
</div>

<?php

// we read the time data
$filename = '/var/www/ecu_data/startstop.txt';
$file = fopen($filename ,"r");
$start = fgets($file);
$stop = fgets($file);
$rise = rtrim(fgets($file));
$set = rtrim(fgets($file));
fclose($file);
// the sunrise /set info
$tm = ((int)date("H") * 60) + ((int)date("i"));
$rs =(int)substr($rise,0,2)*60 + (int)substr($rise,3,5); 
$ss =(int)substr($set,0,2)*60 + (int)substr($set,3,5); 

// we first need to know if there is sunshine
// we read the average power 
$red = intval(file_get_contents("/ramdisk/avgpw.txt"));
$blue = 255 - $red;
$blur = intval(($red/100) * 8);

// and we first need to know if it is nighttime
//we can check if exists /ramdisk/sleepFlag.txt
$fn = "/ramdisk/sleepFlag.txt";
if(!file_exists($fn)) {
 $bac="linear-gradient(#e8edc8, #c8eaed)"; $clr="green";
} else { 
$bac="grey"; $clr="white"; $blur = $red = $blue = 0;
}

echo "<div id='msect'><div class='divstijl' style='background:" . $bac . ";height:78vh;'><center>";


echo "<pre><span style='color:" . $clr . "'>sunrise : " . $rise . "   sunset : " . $set . "</span></pre>";

# *****************************************************
# *    TABLE START                                    *
# *****************************************************

echo "<center><table style='border:1px solid black; background-color:#d1d1e0;box-shadow: 0px 0px ". $blur . "px 2px rgb(". $red . ", 0, " . $blue . ");'>";

echo"<tr style='font-weight:bold; font-size:14px; text-align:center; border:none;'><td class='celwidth'> name / link<td class='celwidth2'>power W<td class='celwidth2'>nrg kWh</td></tr>";

echo "<tr class='lijn3'><td class='lijn3' colspan='100%'></td></tr>";
/*
# *****************************************************
# *    READING INV PROPERTIES AND DATA                *
# *****************************************************
*/
$count=0;
$total_en = 0;
$total_pw = 0;

// **************************************************
//        we read the file invCount.txt
// **************************************************
$fp = fopen('/var/www/ecu_data/inverterCount.txt', 'r');
$invCount = (int)fgetc($fp);
fclose($fp);
//echo "invCount = " , $invCount;
// some empty rows depending on invCount
for ( $x=0; $x < 5-$invCount; $x++ ) { echo "<br>"; }

for($x = 0; $x < 10; $x++){
# pick the available inverters

$filename="/var/www/ecu_data/inverters/invProperties" . $x;
if(file_exists($filename)) {
$count++;
  // we read the name from invProperties
  $jsan=file_get_contents($filename);
  $orr = json_decode($jsan, true);
  $name = $orr["name"];
  //now we check if there is a datafile
  $datafile="/ramdisk/invData" . $x;
  if(file_exists($datafile)) {
    $json = file_get_contents($datafile);
    $arr = json_decode($json, true);
    $pwr = floatval($arr["totalpw"]);
    //$en = floatval($arr["totalen"]) / 1000;
    $en = floatval($arr["totalenStack"]) / 1000;
    $total_en = $total_en + $en; // the total of all inverters
    $total_pw = $total_pw + $pwr;// the total of all inverters
    
   } else {
    // if no datafile we make all values nul
    $pwr = "n/a";
    $en = "n/a";
    } 

    $link = "<a href='invpage.php?inv=" . $x . "'><button   class='linkbt' style='width:140px;'> " . $name . "</button></a>";

    echo "<tr style='font-weight:bold; font-size:14px; text-align:center;'><td>" . $link;

   echo "<td><a href='chartjs/chart_pe.php?page=0&inv=" . $x . "'><button class='linkbt'>" . number_format($pwr, 1, '.', '') . "</button></a>";

   echo "<td><a href='chartjs/chart_en_mth.php?page=0&inv=" . $x . "'><button class='linkbt'>" . number_format($en, 2, '.', '') . "</button></a>";    

    echo "<tr class='lijn3'><td class='lijn3' colspan='100%'></td></tr>";
    
  }
}
// **********   T O T A L S **********
// only if invcount > 1
if ($invCount > 1) 
{

//$format_pw = number_format($total_pw, 1, '.', '');
//$format_en = number_format($total_en, 1, '.', '');
echo "<tr><td class='nm'>totals<td class='hihi'>" . number_format($total_pw, 1, '.', '') . "<td class='haha'>" . number_format($total_en, 2, '.', '');
}

echo "</table>";

if($invCount == 0){
echo"<center><br><br><br><h3>currently no inverters registered!</h3>";
}
// some empty rows depending on invCount
for ( $x=0; $x < 5-$invCount; $x++ ) { echo "<br>"; }

echo "<pre><span style='color:" . $clr . "'>Powered by Hansiart</span></pre>";

?>
</div>

<br><center><iframe name='hiddenFrame' width='420' height='100' hidden ></iframe>  </body>
 </html> 
