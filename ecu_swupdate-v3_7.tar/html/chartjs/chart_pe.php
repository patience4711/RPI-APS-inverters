<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="112">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<style type="text/css">

#chart-container {
    width: 90vw;
    height: auto;
    border: 1px solid;
    background: white;
    font-color:yellow;
}
canvas{
  width:90vw !important;
  height:38vw !important;
}
@media screen and (max-width: 800px) {
canvas{ 
  height:250px !important;
  }
}
@media screen and (max-width: 800px) and (orientation: landscape) {
canvas{ 
  height:300px !important;
  }
}

.close {
  color: red;
  float: right;
  font-size: 58px;
  font-weight: bold;
  cursor: pointer;
padding: 0px 20px 0px 0px; /* trbl */
}
.close:hover {color: green;}

</style>
<script>
function submitFunction(a) {
var terug = "chart_pe.php?inv=" + a;
document.getElementById("bo").innerHTML="<br>wait...<br>quering<br>this<br>chart"; 
document.getElementById("bo").style.display="block"; 
document.getElementById('formulier').submit();
//setTimeout(function(){window.location.href='chart_pe.php';}, 3000 ); 
setTimeout(function(){window.location.href=terug;}, 3000 ); 
}

var message = "viewing this page is not allowed!";
function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }
if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }
document.onmousedown = rtclickcheck;

</script>

</head>
<body>

<script type="text/javascript" src="chart.min.js"></script>

<script type="text/javascript" src="jquery.min.js"></script>


<div id='bo'></div>
<div id='msect'>
   <div class='divstijl'><center>

<?php

//we read the serverargument to find the way back
$invnr = $_GET['inv'];
$goBack = $_GET['page'];
if($goBack == 0) {  
echo '<a href="/index.php"><span class="close">&times;</span></a><br>';
} else {
echo '<a href="/invpage.php?inv=' . $invnr . '"><span class="close">&times;</span></a><br>';
}
echo '<form id="formulier" action="/cgi-bin/setchartDate.pl" target="hiddenFrame">';

$file="/var/www/ecu_data/chartDate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$dat = fgets($fp);

$datum = new DateTime("$dat");
$datum = $datum->format("Y-m-d");
fclose($fp);
} else {
$datum = date('Y-m-d');
}
echo"<input type='date' onchange='submitFunction(" . $invnr . ")' name='datum' value='" . $datum . "' style='width: 180px;' >";
echo "</input></form>";

//echo "<h4>invnr = " . $invnr . "</h4>";
$namepw="power inverter " . $invnr; // to be used as chart tittle
$namepe="energy inverter " . $invnr; // to be used as chart 

?>
<br>
<div id="chart-container">
  <canvas id="graphCanvas"></canvas>
</div>
<br><br>
</div></div>
<script>
var naam1 = "<?php echo $namepw; ?>"; // chart tittle lable
var naam2 = "<?php echo $namepe; ?>"; // chart tittle lable
var w = "chartdata_pe.php?inv=" + "<?php echo $invnr; ?>"; 

$(document).ready(function () {showGraph();});

   function showGraph()
   {
     {
       //$.post("chartdata_pe.php", function (data)
       $.post(w, function (data)
       {
    //var naam = 'power inverter';            
    var time = [];
    var pwr = []; 
    var eny = []; 
    jsonObj = eval("("+data+")");
    if(jsonObj.length ===0){
     console.log("obj = null");
     var canvas = document.getElementById('graphCanvas');
     var ctx = canvas.getContext("2d");
     ctx.font = "30px Arial";
     ctx.fillText("no data available",30,70);
     ctx.globalCompositeOperation = 'destination-over'
     // Now draw!
     ctx.fillStyle = "#ffcce0";
     ctx.fillRect(0, 0, canvas.width, canvas.height);
     return;    
     }
    for(var i in jsonObj)
    {
    tijd = jsonObj[i].time.substr(11,5);
    time.push(tijd);
    pwr.push(jsonObj[i].p);
    eny.push(jsonObj[i].e);
    }
                     
     var chartdata = {
        labels: time,
         datasets: [
            
              {
               //type: 'line',
               label: naam1,
               //fill: 'origin',      
               fill: {
                target: 'origin',
                //above: 'rgba(10, 95, 150, 0.2)', 
                above: '#b3ffff5a',   
               },

               backgroundColor: '#49e2ff',
               borderColor: '#46d5f1',
               borderWidth: 2,
               pointBorderWidth: 2,
               pointRadius: 1,
               hoverBackgroundColor: '#CCCCCC',
               hoverBorderColor: '#666666',
               data: pwr,
              },
              {
                label: naam2,
                type: 'bar',
                backgroundColor: '#ff33bb',
                borderColor: '#ff33bb',
                borderWidth: 2,
                pointBorderWidth: 2,
                pointRadius: 1,
                hoverBackgroundColor: '#CCCCCC',
                hoverBorderColor: '#666666',
                data: eny,
               }


                ]

                };

                var graphTarget = $("#graphCanvas");

                var barGraph = new Chart(graphTarget, {
                    type: 'line',
                    data: chartdata,
                options: {
    responsive: true,
      plugins: {
         legend: {
           labels: {
             color: "#000099",
                font: {
                  size: 18,
                 }
               }
          }    
     },
   maintainAspectRatio: false,

                    scales: {
 y: { 
    title: { 
       display: true,
       color: 'red', 
      text: 'watt / watt/hr' 
     },
     grid: {
        color: 'lightgrey'
      },
     ticks: {
        color: 'red',
     }
   }//end y:
}
                    }

                 });
             });
          }
      }
      </script>
<br><center><iframe name='hiddenFrame' width='420' height='100' hidden ></iframe>  
</body>
</html>

