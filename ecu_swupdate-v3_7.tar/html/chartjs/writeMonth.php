<?php
/*
this file writes the date for monthly energy values
so the graph starts at the 1sth of a month
*/




$postreq = $_POST["maand"];
if ($postreq != "") {
$finaldata = $postreq . "-01";
echo "finaldata = " . $finaldata;
}
// so if we have a post we get a month + -01
file_put_contents("/var/www/ecu_data/chartMonth.txt", $finaldata);

// we also write today's date
//$date = date('Y-m-d');
//file_put_contents("/var/www/ecu_data/chartMonth.txt",$finaldata . "\n" . $date);
exit;
?>