<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="112">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<style>
table, th, td {
  Background-color:#d9ffb3; 
  border: 1px solid blue; 
border-collapse: collapse;
  text-align:center;
  padding:2px;
  font-size:16px; 
  }
.celwidth {width: 80px;}
.haha {
Background-color:lightgreen; 
}
.hihi {
Background-color:#99ccff; 
}
.hoho {
Background-color:#0000b3;
color: white; 
}
tr {height:38px;} 
@media only screen and (max-width: 800px) {
table, th, td {
  font-size:14px; 
  }

}

</style>

<script>
var message = "viewing this page is not allowed!";
function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }
if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }
document.onmousedown = rtclickcheck;
</script>

</head><body>
<div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>STATS HELP</h3>
  <b>PURPOSE:</b><br>
  This page shows some statistical data over the total lifecycle of the project.
  <br><br><b>BEGIN- AND ENDDATE</b><br>The period is including the begin and enddate.<br><br><strong>Please note: </strong>The present day is not included in this overview,<br>as this data is not yet available in the database. 
<br><br>

</div>
<?php
// **************************************************
//        we read the serverargument for inv
// **************************************************
$invnr = $_GET['inv'];

// compose the link

echo"<div id='msect'><ul>";

echo "<li><a href='#' onclick='helpfunctie()'>help</a></li>";
echo "<li><a href='/chartjs/chart_en.php?inv=" . $invnr . "'>chart</a></li>";
echo "<li><a href='/ANALYZE.php?inv=" . $invnr . "'>analyze</a></li>";
echo '<li style="float:right;"><a href="/invpage.php?inv=' . $invnr . '"><img src="/close.png" class="icon"></a><li>';
echo "</ul></div>";


// **************************************************
//        we read the file invProperties.txt
// **************************************************
$filename="/var/www/ecu_data/inverters/invProperties" . $invnr;
  if(file_exists($filename)) {
    $jsan = file_get_contents($filename);
    $orr = json_decode($jsan, true);
    $name = $orr["name"];
    fclose($filename);
  } 

echo "<div id='msect'><div id='bo'></div><h2>statistics " . $invnr . " " . $name . "</h2></div>";

echo "<div id='msect'><div class='divstijl' style='width:500px' ><center>";

$from="inv". $invnr; // to be used in the query
//echo "<h4>$from = " . $from . "<br>";
// **************************************************
//        we read the file settings.json
// **************************************************
// we also need the energy price from settings.json
$filename="/var/www/ecu_data/settings.json";
  if(file_exists($filename)) {
    $jsun = file_get_contents($filename);
    $urr = json_decode($jsun, true);
    $price = $urr["price"];
    //$cur = $urr["cur"];
    fclose($filename);

} else {$price = 0;}

$currency = "&curren;";
// we have to read the currency sign
$filename="/var/www/ecu_data/currency.txt";
  if(file_exists($filename)) {
    $fp = fopen($filename, 'r');
    $cur = trim(fgets($fp));    
    fclose($filename);
    if($cur=="er"){
    $currency = "&euro;";
    } elseif ($cur=="do"){
    $currency = "&dollar;";
    } elseif ($cur=="po"){
    $currency = "&pound;";
    } 
   } 
// so if the file not exixts its always curren

require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";
$dbname= "invEnergy";
//get connection
$client = new InfluxDB\Client($host, $port);
$database = $client->selectDB('invEnergy');

// ************  select total energy ***************
$query="SELECT sum(e),count(e) FROM {$from} ";
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
$punten = json_decode($points, true);
$total = floatval($punten[0]["sum"]/1000);
$count = $punten[0]["count"];
if($total == 0) { 

goto skip; 
}

// *** select first to get the the begindate ******
$query="SELECT first(e) FROM {$from} ";
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
$punten = json_decode($points, true);
$start = substr($punten[0]["time"], 0, 10);
//echo "\n" . $tijd;

// ******* select highest value*****************
$query="SELECT max(e) FROM {$from} ";
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
$punten = json_decode($points, true);
$max = $punten[0]["max"]/1000;
$whenhigh = substr($punten[0]["time"], 0, 10);


// ******* select lowest value*****************
$query="SELECT min(e) FROM {$from} ";
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
$punten = json_decode($points, true);
$low = $punten[0]["min"]/1000;
$whenlow = substr($punten[0]["time"], 0, 10);


// ******* select last e in invData *****************
// to get the total energy at this moment
//$dbname= "invData";
//$database = $client->selectDB('invData');
//$query="SELECT last(e) FROM {$from} ";
//$result=$database->query($query);
//$points = $result->getPoints();
//$points = json_encode($points);
//$punten = json_decode($points, true);
//$grandtotal = $punten[0]["last"]/1000;
//echo"grandtotal " . $grandtotal;
//$grandtotal = $grandtotal + $total;


skip:
if($total == 0) {
echo"<br><br><br><h3>no data available</h3>"; } else
{
echo"<table style='width:90%'>";

//$today = date("Y/m/d");
echo"<tr><td class='hoho' style='font-weight:bold;' colspan='2'><pre><h3>" . $start . "\tTO   \t" . date("Y-m-d",strtotime("-1 days")) ."</h3></pre></td>";

echo"<tr><td>number of whole days: <td>" . $count;

$av = $total/$count;
echo "<tr><td title='calculated over the number of whole days'> moving daily average : <td title='calculated over the number of whole days'>" . number_format($av, 2) . " KWh";

echo"<tr><td>highest energy on " . $whenhigh . "<td>" . number_format($max, 2) . " KWh";

echo"<tr><td>lowest energy on " . $whenlow . "<td>" . number_format($low, 2) . " KWh";

echo"<tr><td class='hihi'>total energy generated : <td class='hihi' >" . number_format($total, 2) . " KWh";

echo "<tr><td class='hihi' >total financial return: <td class='hihi' >" . number_format($total*$price, 2) . " " .$currency . "</tr>";

echo "<tr><td title='based on 230g/KWh' class='haha' >CO<sub>2</sub> emission saved: <td class='haha' title='based on 230g/KWh'>" .number_format($total*0.230, 2) . " kg";

echo "<tr><td class='haha' >trees planted: <td class='haha' >" .number_format($total*0.0117, 2);



//co2 factor 230 g/kWh.
// trees factor 0.0117
echo"</table>";
}
?>

<script>
function invSelect() {
var a = document.getElementById('ivnr').value;
document.getElementById("bo").innerHTML="<br>wait...<br>quering<br>data"; 
document.getElementById("bo").style.display="block"; 
document.getElementById('invKeuze').submit();
setTimeout(function(){window.location.href='/chartjs/stats_e.php';}, 3000 ); 
}

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}


</script>
<br><center><iframe name='hiddenFrame' width='420' height='100' hidden ></iframe>  

</body></html>
