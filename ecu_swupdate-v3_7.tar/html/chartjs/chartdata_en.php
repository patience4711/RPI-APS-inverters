<?php
/*
this page queries values from invEnergy invx
also queries the last entry of energy in invData invx
If that value != null we add it to the first query
so that we have a value for the present day.
At midnight the value in invData is copied to invEnergy
and the value in inv is set to null.
The database is in utc time so midnight = 23.00 !!!
*/

// we need to read which inverter we want
// so we read the file invChoice.txt
//$invnr = file_get_contents("/ramdisk/invChoice.txt");
// we read the inverternr from the url
$invnr = $_GET['inv'];

$from="inv". $invnr; // to be used in the query

require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";
$dbname= "invEnergy";
//get connection

$client = new InfluxDB\Client($host, $port);

// ******* select e in invEnergy *****************
$database = $client->selectDB('invEnergy');
$query="SELECT e FROM {$from} ";
$result=$database->query($query);
$points = $result->getPoints();


// ******* select sum e in invData for today *****************
$begin = date("Y-m-d 03:i:s");
$eind = date("Y-m-d 23:i:s");

$result = "";
$dbname= "invData";
$database = $client->selectDB('invData');

$query="SELECT sum(e) FROM {$from} where time > '{$begin}' and time < '{$eind}' tz('$tz')"; // gives sum(e)
$result=$database->query($query);
$paints = $result->getPoints();
$sum = $paints[0]["sum"];
//echo "sum = " .$sum;

// we need to know if the e value = null

if($sum <= 0) { 
//echo "\nfound null value\n";
$points = json_encode($points);
 
} 
else 
{
//echo "found a value so we merge the array's";
$mix=array_merge($points, $paints);
$points = json_encode($mix);
// we have to replace sum with e
$points = str_replace("sum","e", $points);
}


echo $points;

?>
