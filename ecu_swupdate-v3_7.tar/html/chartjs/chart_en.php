<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="112">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<style type="text/css">

#chart-container {
    width: 90vw;
    height: auto;
    border: 1px solid;
    background: white;
    font-color:yellow;
}
canvas{
  width:90vw !important;
  height:38vw !important;
}
@media screen and (max-width: 800px) {
canvas{ 
  height:250px !important;
  }
}
@media screen and (max-width: 800px) and (orientation: landscape) {
canvas{ 
  height:400px !important;
  }
}


.close {
  color: red;
  float: right;
  font-size: 58px;
  font-weight: bold;
  cursor: pointer;
padding: 0px 20px 0px 0px; /* trbl */
}
.close:hover {color: green;}

</style>
<script>
function submitFunction() {
document.getElementById("bo").innerHTML="<br>wait...<br>quering<br>this<br>chart"; 
document.getElementById("bo").style.display="block"; 
document.getElementById('formulier').submit();
setTimeout(function(){window.location.href='chart_pw.php';}, 3000 ); 
}
var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;
</script>

</head>
<body>

<script type="text/javascript" src="chart.min.js"></script>

<script type="text/javascript" src="jquery.min.js"></script>

<div id='msect'>
<div id='bo'></div>
   <div class='divstijl'><center>



<?php
// we read the file invChoice.txt to find the way back
// $invnr = file_get_contents("/ramdisk/invChoice.txt");

$invnr = $_GET['inv'];

echo '<a href="stats_e.php?inv=' . $invnr . '"><span class="close">&times;</span></a><br>';

$name="daily energy inverter " . $invnr; // to be used as chart tittle
echo"<h3>DAILY ENERGY INVERTER " . $invnr . "</h3>";
$file="/var/www/ecu_data/chartDate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$doffset = (int)fgets($fp);
//echo "file exists value $doffset = " . $doffset;
fclose($fp);
} else {
$doffset = 0;
}
//echo"</select></form>";

?>

<div id="chart-container">
  <canvas id="graphCanvas"></canvas>
</div>
<br><br>
</div></div>
<script>
var naam = "<?php echo $name; ?>"; // chart tittle lable
var w = "chartdata_en.php?inv=" + "<?php echo $invnr; ?>"; 

$(document).ready(function () {showGraph();});

   function showGraph()
   {
     {
       //$.post("chartdata_en.php", function (data)
       $.post(w, function (data)
       {
    
    var time = [];
    var energy = []; 
    jsonObj = eval("("+data+")");
     if(jsonObj.length ===0){
     console.log("obj = null");
     var canvas = document.getElementById('graphCanvas');
     var ctx = canvas.getContext("2d");
     ctx.font = "30px Arial";
     ctx.fillText("no data available",30,70);
     ctx.globalCompositeOperation = 'destination-over'
     // Now draw!
     ctx.fillStyle = "#ffcce0";
     ctx.fillRect(0, 0, canvas.width, canvas.height);
     return;    
     }




    for(var i in jsonObj)
    {
    tijd = jsonObj[i].time.substr(0,10);
    
    time.push(tijd);
    energy.push(jsonObj[i].e);

    }
                     
     var chartdata = {
        labels: time,
       datasets: [
            {
               label: naam,
                fill: {
                target: 'origin',
                //above: 'rgba(150, 95, 15, 0.2)', 
                above: '#ff33bb5a',   
               },


               backgroundColor: '#ff4d4d',
               borderColor: '#ff33bb',
               borderWidth: 2,
               pointBorderWidth: 2,
               pointRadius: 1,
               hoverBackgroundColor: '#CCCCCC',
               hoverBorderColor: '#666666',
               data: energy,
               },]
            }

                var graphTarget = $("#graphCanvas");

                var barGraph = new Chart(graphTarget, {
                    type: 'line',
                    data: chartdata,
                 options: {
    responsive: true,
    maintainAspectRatio: false,
                    scales: {
 y: { 
    title: { 
       display: true,
       color: 'red', 
      text: 'Watt/hour' 
     },
     grid: {
        color: 'lightgrey'
      },
     ticks: {
        color: 'red',
     }
   }//end y:
}
                    }

                 });
             });
          }
      }
      </script>
<br><center><iframe name='hiddenFrame' width='420' height='100' hidden ></iframe>  
</body>
</html>
