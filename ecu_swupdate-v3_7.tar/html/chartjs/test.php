
<?php
/*
this page queries the values from invEnergy invx per month
also queries the last entry of energy in invData invx when
the query is over the currnt month
If that value != null we add it to the first query
so that we have a value for the present day.
At midnight the value in invData is copied to invEnergy
and the value in inv is set to null.
*/
$invnr = $_GET['inv'];  //
//echo "kut = " . $_GET['kut'];  //
$req=$_SERVER['QUERY_STRING'];

//if($invnr == 0) { echo "inv = 0"; } else { echo "inv = not 0";}

$uptime = exec("/usr/bin/uptime");
//echo $uptime;
$clients = exec("netstat -nt | grep :80 | wc -l");
echo $clients;
?>
