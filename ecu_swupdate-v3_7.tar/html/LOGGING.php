<!DOCTYPE html><html><head><meta charset='utf-8'>
<meta http-equiv="refresh" content="200">
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<script type='text/javascript'>

function clearFunctie() {
if(!confirm("haha you would do that too, would you?")){
return false;}

document.getElementById("bo").innerHTML="<br>wait...<br>processing<br>your<br>request"; 
document.getElementById("bo").style.display="block"; 
//document.getElementById("clear").submit();
setTimeout(function(){window.location.href="LOGGING.php";}, 3000 ); 
}

var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</script>
<style>
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }
div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}

html {
  scroll-behavior: smooth;
 }
</style>
<script>
function scrollDown(){
//alert("haha");
document.getElementById('down').scrollIntoView(true);
}
</script>
</head>
<body onload="scrollDown()">
<div style='position:fixed;'>
  <div id='msect'>
    <div id='bo'></div>
    <form id="clear" action="/cgi-bin/ecu/logClear.pl" target="hiddenFrame"> </form>
    <ul>
    <!--<li><a href='details.php'>done</a></li>-->
    <li><a href='#' onclick='clearFunctie()'>clear</a></li>
    <li><a href="#up">up</a><li>
    <li><a href="#down">down</a><li>
     <li style='float:right;'><a href='details.php'><img src='/close.png' class='icon'></a><li>';
    </ul>
   </div>

   <div id='msect'>
   <kop>EVENTS JOURNAL</kop>
   </div>
</div>
<div id='msect'>
<div class='divstijl' id='up' style='width: 98vw'>
<center><br><br><br><br><br><br>
<?php

$filename="/ramdisk/ecu_log.txt";

if(file_exists($filename)) { 
$log = file_get_contents($filename);
} else {
goto error1;
}

echo $log;

goto phpend;

error1:
echo"<h1>currently no log exists, click done</h4>"; 
echo"</body></html><!--"; 

phpend:
?>
<div id='down'></div>
<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>  

<br>
</body></html>