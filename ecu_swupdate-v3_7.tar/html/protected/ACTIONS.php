<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">

<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
//alert("hiding loader");
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}

</script>
<style>

.butt {
  font-size:24px; 
  heigth:34px;
    border: 2px solid black;
  border-radius:6px;
  box-shadow: 5px 10px #888888;

}
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }

div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}

.loader {
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-bottom: 16px solid #ffff00; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  font-size: 38px;
  color: #ff00ff; 
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
</head>
<body>

<div id='msect'>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>CONSOLE HELP</h3>
This console is a very powerfull instrument to debug the various processes of the system.<br><br>
<b>usage</b><br>
- Enter an argument, e.g. a command or an inverternr in the attribute field.<br>
- Choose an action<br>
The action will be processed and the output appears in the frame.
<br><br>
<b>factory reset</b><br>
All inverter settings/databases are removed. Individual inverters can be deleted via the inverters menu. Their database can be deleted via the database menu.<br><br>
<b>zigbee commands explanation</b><br>
A command exists of FE, length(1byte), command (2 bytes), data (x bytes) and checksum.<br>
In the field you only have to enter the command bytes and data if applicable (eg 410000).<br><br>
  <b>commands and answers:</b><br>
  2700 test if the coordinator is running<br>
answer FE0E670000FFFF80971B01A3D6FEFF<mark>070000</mark>17: <br> ready but needs to be started ( command 2600)<br>

answer FE0E670000FFFF80971B01A3D6FEFF<mark>070900</mark>17: running
<br>
2100 ping
answer 
<br><br>In the screen below you can follow the process.<br><br>

  </div>
</div>

<div id='msect'>
<ul>
<!--<li><a href='menu.html'>done</a></li>-->
<li><a href='#' onclick='helpfunctie()'>help</a></li>
  <li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

</ul>
</div>
<div id='msect'>
<kop>ECU CONSOLE</kop>
</div>
<div id='msect'>
<center><div class='divstijl' style='height:100vh; width: 94vw'>
<br>

<div id='refreshdiv' style='visibility: hidden; position:absolute; top: 140px; left: 35vw; z-index: 10;'><button class='butt' onclick='refreshfunction()'>send another command</button></div>

<div id='formdiv' style='visibility: visible;'></>
<select id='sel' class='sb1' name"actionSelect" onchange="actionFunction()">
<option selected readonly>CHOOSE AN ACTION</option>
<option value='1'>start coordinator for normal</option>
<option value='0'>start coordinator for pairing</option>
<option value='2'>run health check coordinator</option>
<option value='3'>send a zigbee command</option>
<option value='4'>pair an inverter</option>
<option value='5'>poll an inverter</option>
<option value='7'>remove wifi credentials</option>
<option value='6'>factory reset</option>
</select>
<input name='cmd' id='com' placeholder='command attribute' class='inp6'></input>
</div>
<br>

<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>

<iframe id='of' name='outputFrame' width='90%' height='450'></iframe>

<br></div></div>
<form id='initN' action='/cgi-bin/ecu/startCoordinator.pl' style='display:none' target='outputFrame'><input name="normal" value='1'></input></form>

<form id='initP' action='/cgi-bin/ecu/startCoordinator.pl' style='display:none' target='outputFrame'><input name="normal" value='0'></input></form>

<form id='health' action='/cgi-bin/ecu/checkCoordinator.pl' style='display:none' target='outputFrame'></form>

<form id='reset' action='/cgi-bin/ecu/resetScript.pl' style='display:none' target='outputFrame'></input></form>

<form id='test' action='/cgi-bin/ecu/sendZigbee.pl' style='display:none' target='outputFrame'><input id='testCmd' name='cmd'></input></form>

<form id='pair' action='/cgi-bin/ecu/inverterPair.pl' style='display:none' target='outputFrame'><input id='welkePair' name='ivnr'></input></form>
 
<form id='poll' action='/cgi-bin/ecu/inverterPoll.pl' style='display:none' target='outputFrame'><input id='welkePoll' name='welke'></input></form>

<form id='wipe_cr' action='/cgi-bin/ecu/wifi/wipe_wificredentials.pl' style='display:none' target='outputFrame'></input></form>

</body>

<script>

function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
//setTimeout( function() { hideLoader(); }, 1000);
}

function actionFunction() 
{

// we change the visibility for the inputs
   document.getElementById("formdiv").style.visibility = 'hidden';
   document.getElementById("refreshdiv").style.visibility = 'visible';
   
   b=document.getElementById("sel").value;
   
   if(b==0) 
   {
       if(!confirm("are you sure to start the coordinator for pairing? (WARNING this can take a minute)"))
       {
          return false;
       } else {
          spinner();
          checkReaction();   
          document.getElementById("initP").submit();
        } 
    }
   if(b==1) 
   {
       if(!confirm("are you sure to start the coordinator for normal operations? (WARNING this can take a minute)"))
       {
          return false;
       } else {
          spinner();
          checkReaction();   
         document.getElementById("initN").submit();
       } 
    }

   if(b==2)  // health
   {
       if(!confirm("are you sure to check the coordinator ?"))
       {
          return false;
       } else {
          spinner(); 
          checkReaction();
          document.getElementById("health").submit();
       } 
   }
   
   if(b==3) // zigbee command
   {
      command=document.getElementById('com').value;
      var length = command.length;   
      var islow = hasLowerCase(command);
      if( length < 4 || islow==true  ) 
      {
  alert("you should provide valid data ( length > 4 only digits and uppercase letters) " + length);
        location.reload();
      } else {
        spinner();
        checkReaction();
        document.getElementById("testCmd").value=command;
        document.getElementById("test").submit();
        //return false;
       } 
   }

   if(b==4) // pair an inverter command 
   {
   command=document.getElementById('com').value;
   var length = command.length;
   //
   if(length != 1 || isDigit(command)== false ){
   
    alert("you should provide valid data ( 0 to 8)");
     location.reload();
      } else {
      spinner();
      checkReaction();   
      document.getElementById("welkePair").value=command;
      //alert(" b = 4 value = " + command);
      document.getElementById("pair").submit();
      } 
   }


   if(b==5) // poll an inverter command 
   {
   command=document.getElementById('com').value;
   var length = command.length;
   //
   if(length != 1 || isDigit(command)== false ){
   
    alert("you should provide valid data ( 0 to 8)");
     location.reload();
      } else {
      spinner();   
      document.getElementById("welkePoll").value=command;
      //alert(" b = " + b + " value = " + command);
      checkReaction();
      document.getElementById("poll").submit();
      } 
   }

   if(b==6) // factory reset
   {
       if(!confirm("This command will delete all inverters and all database entries! ! ! Are you sure to do this? (see help)"))
       {
          location.reload() 
          return false;
       }
        if(!confirm("FACTORY RESET: all inverter settings and databases entries will deleted ! ! ! Are you REALLY VERY sure you want this?"))
       {
          location.reload() 
          return false;
       }
          spinner();
          checkReaction();   
          document.getElementById("reset").submit();
   } 

   if(b==7) // remove wifi credentials 
   {
       if(!confirm("This command will delete your wificredentials. At reboot the system can't connect to your wifi anymore and will start the accesspoint radioAP ! ! ! \n\n Are you sure you want this? (see help)"))
       {
          location.reload() 
          return false;
       }
          spinner();
          checkReaction();   
          document.getElementById("wipe_cr").submit();
   } 


}
var isDigit = (function() {
    var re = /^\d$/;
    return function(c) {
        return re.test(c);
    }
}());

function hasLowerCase(str) {
    return (/[a-z]/.test(str));
}

function checkReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
}
}

</script>
</html>