<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=0.78' />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<style>
table, th, td {
  border: 1px solid black;
}
td {
width:70px;
text-align:center;
}
</style>
<script>
function helpfunctie(){
alert("The information about the sd-card usage may not be correct right after the file sytem expansion.\r\nAfter another reboot it will be displayed correctly!");
}
</script>

</head>
<body>
<div id="msect">
<ul>
<!--<li><a href='/index.php'>home</a></li>-->
<li><a href='#' onclick='helpfunctie()'>help</a></li>
<li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>
</ul><br>
</div>
<div id="msect">
<kop>  HANSIART RPI ECU </kop>
</div>

<div id="msect"><center>
<div class='divstijl' style='width:430px; font-size:16px;'>

<h4>RPI ECU SYSTEM INFORMATION</h4>

<?php
// Collect the Data first
// we read the file swVersion.txt
$fp = fopen('/var/www/ecu_data/swVersion.txt', 'r');
$version = fgets($fp);
fclose($fp);
echo "firmware version = " . $version . "<br>";
// Get uptime info from system call to uptime
$uptime = exec("/usr/bin/uptime");
$tijd = substr($uptime,0, 9);
echo "systemtime = " . $tijd . "<br>";

$rest = substr($uptime,9 );
//echo "rest = " . $rest . "<br>";
// als geen dagen dan is rest: up 2:16, 2 users, load average: 0.20, 0.13, 0.14 en dan zijn er 5 elementen
$myarray = (explode(",", $rest));
$num_tags = count($myarray);
if($num_tags==5) {
//de up informatie bestaat uit uren en min
$myarray2 = (explode(":",$myarray[0]));
echo "uptime = " . $myarray2[0] . "hr " . $myarray2[1] . "min.<br>";
} else {
//er zijn nu 6 elementen, element 0= "up 2 days"
//de up informatie ziet er zo uit up 2 days, 10:20
//dagen zitten in nu in element 0
//echo "myarray[0]= ". $myarray[0];
$dagen = substr($myarray[0],3);
$dagen = substr($dagen, 0, -4);
//echo "dagen = ". $dagen;
$myarray2 = (explode(":",$myarray[1]));
//echo "rest = " . $rest;
echo "uptime = " . $dagen . "days " . $myarray2[0] . "hr " . $myarray2[1] . "min. <br>";

}
//echo "usercount" . $myarray[$num_tags-4] . "<br>";  //aantal users

$myarray3 = substr($myarray[$num_tags-3], 15);
echo "av. cpu occupation : " . $myarray3. " " . $myarray[$num_tags-2] . " "  .  $myarray[$num_tags-1] . "<br>";


// *********************   temperature ******************
$temperature = exec("cat /sys/class/thermal/thermal_zone0/temp");
$hele = substr($temperature, 0, 2);
$digs = substr($temperature, 3, 4);
echo "core temperature " . $hele . "." . $digs ."&degC<br>";

// *********************   memory ******************
$mem = shell_exec("free --mega");
$tot = substr($mem, 96, 3);
$use = substr($mem, 109, 3);
$vrij = substr($mem, 121, 3);
echo "memory total Mb: " . $tot . "   used: ". $use . "  free: ". $vrij . "<br>";

// *********************   disk info ******************

$file = fopen("/var/www/ecu_data/fs_size.txt","r");
$line1 = fgets($file);
//$line2 = rtrim(fgets($file));
fclose($file);
echo "<br>sdcard usage: (please see help)<br> ";
echo"<table><tr><td>filesystem<td>size <td>used <td>available <td>use %";
$items = explode(" ", $line1);
$removed = array_pop($items); // remove het laatste element
echo "</td><tr>";

foreach($items as $v){
if ($v != '') { echo "<td>". $v . "</td>";}
}
echo "</table>";
echo "<br>";


$filename = '/var/www/ecu_data/startstop.txt';

$file = fopen($filename ,"r");
$start = fgets($file);
$stop = fgets($file);
$rise = fgets($file);
$set = fgets($file);
//fclose($file);
 
echo "sunrise is at : " . $rise . " and sunset is at " . $set;
echo "<br>polling starts at: " . $start . " and stops at " . $stop;

?>


</span>
<br><br><span style='color: green; font-size: 12px;' class="groen">
<!--Tip: De timer blijft actief totdat op "disarm" is gedrukt.-->
</span>
<br>
</div>

</div>
<br><br>
</body>
</html> 
