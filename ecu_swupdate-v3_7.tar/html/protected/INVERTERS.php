<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">

<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function submitFunction(a) {
if(!confirm("are you sure to save inverter " + a + "?")){
return false;
}
document.getElementById("bo").innerHTML="<br>wait...<br>processing<br>your<br>request"; 
//document.getElementById("bo").style.display="block"; 
spinner();
checkReaction();

document.getElementById('formulier').submit();
setTimeout(function(){window.location.href='INVERTERS.php';}, 5000 ); 

}
function delFunctie(a) {
if(!confirm("are you sure to delete inverter " + a + " ??")){
return false;
}
document.getElementById('invdel').value=a;
spinner();
//checkReaction();

document.getElementById('delform').submit();
setTimeout(function(){window.location.href='INVERTERS.php';}, 5000 ); 
}
</script>
<style>
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }
div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}
</style>
</head>
<body>

<div id='msect'>
<div id='bo'></div>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>INVERTER SETTINGS HELP</h3>
  <b>you can add max 9 inverters.</b><br><br>
  <b>name</b><br>
  Enter a meaningfull name or the position of the inverter.
  <br><br><b>inverter serialnr:</b><br>
  You can find the serialnr stickered on the inverter.
  <br><br><b>panels:</b><br>
  Check which panels are connected.
  <br><br><b>Dom idx:</b><br>
  Identification that is sent in mqtt messages to 'Domoticz'.

  <br><br><b>pair:</b><br>
  link your inverter to this ECU in order to make the zigbee communication possible.<br>
  When paired you will see the obtained inverter ID in the status field.
  You can find more information in the log or information page. 
  <br><br>
  </div>
</div>

<div id='msect'>
<ul>
<!--<li><a href='menu.html'>done</a></li>-->
  <li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

<?php

$inverterCount;
if(file_exists("/var/www/ecu_data/inverterCount.txt"))
{
$file = fopen("/var/www/ecu_data/inverterCount.txt","r");
$Count = rtrim(fgets($file));
$inverterCount=(int)$Count;
fclose($file);
} 
else 
{
$inverterCount=0;
echo "<li><a href='ADDINV.php'>add</a></li>";
goto error1;
}

for ($x = 0; $x < 10; $x++) {
# if there is a file we display the link 
$filename="/var/www/ecu_data/inverters/invProperties" . $x;

if(file_exists($filename)) { 
echo "<li><a href=# onclick='invKeuze(" . $x . ")'>inv " . $x . "</a></li>";

}
}
if($inverterCount < 9) {
echo "<li><a href='ADDINV.php'>add</a></li>";
}
echo "</ul></div><div id='msect'>";

// we read the file for the value of invKeuze
$file="/ramdisk/invChoice.txt";
if(file_exists($file)){
$inv = file_get_contents($file);
} else {
$inv = 0;
}
$invnr = intval($inv);

echo "<div class='divstijl' style='height:64vh;'><center>";
/*
# *****************************************************
# *            START OF THE FORM                      *
# *****************************************************
*/
echo "<form id='formulier' method='get' action='/cgi-bin/ecu/inverterSave.pl' oninput='showSubmit()' target='hiddenFrame'>";
  
echo "<table><tr><td style='width:90px;'>";
// if we deleted inv 0, invChoice becomes the first available

if($inverterCount == 0) {goto error1;}

//$filename="/var/www/ecu_data/inverters/invProperties" . $invnr;
$filename="/var/www/ecu_data/inverters/invProperties$invnr";
//echo "<h2>filename = " . $invnr;
$json = file_get_contents($filename);
//echo "<h2>json= " . $json . "</h2>";
$arr = json_decode($json, true);
$invID=$arr["id"];
$invSerial=$arr["serial"];
$invType=$arr["type"];
$invName=$arr["name"];
$invIdx=$arr["idx"];
$p0=$arr["panels"][0];
$p1=$arr["panels"][1];
$p2=$arr["panels"][2];
$p3=$arr["panels"][3];

echo"<h4>INVERTER</h4><td style='width:90px;'><input class='inp1' name='ivnr' value='" . $invnr . "' readonly>";

echo"<td style='width:50px;'><h4>STATUS:</h4><td>";
if($invID == "") {$invID="unpaired";}
echo"<input style='width:100px;' name='ivid' class='inp3' value='" . $invID . "' readonly></tr></table><br>";

echo"<table style='background-color: lightgreen; padding:10px;'>";
    
echo"<tr><td class='cap' style='width:100px;'>SERIALNR<td><input class='inp4' id='iv' name='ivser' minlength='12' maxlength='12' required value='" . $invSerial . "'></input></tr>";

echo"<tr><td class='cap'>TYPE<td><select id='invt' name='invt' class='sb2' onchange='myFunction()'>";
$selyc='';
$selds='';
$selqs='';

if($invType == '0') {
$selyc = "selected";
} elseif ($invType == '1') {
$selqs = "selected";
} else {
$selds = "selected";
}

echo"<option value='0' " . $selyc . ">YC600</option>";
echo"<option value='2' " . $selds . ">DS3</option>";
echo"<option value='1' " . $selqs . ">QS1</option>";
echo"</select></tr>";

echo "<tr><td class='cap' >NAME<td class='cap' ><input class='inp4' id='in' name='in' maxlength='12' value='" . $invName . "'></input>";

echo"<tr><td class='cap' >DOM. IDX<td class='cap' ><input class='inp2' name='mqidx' value='". $invIdx . "' size='4' length='4'></td></tr>";
$check0='';
$check1='';
$check2='';
$check3='';
echo"<tr><td class='cap' >PANELS:<td style='width: 230px;'>";

if($p0 == "1") {$check0 = "checked";}
echo"1&nbsp;<input type='checkbox' name='pan1'" . $check0 . ">";

if($p1 == "1") {$check1 = "checked";}
echo"2&nbsp;<input type='checkbox' name='pan2'" . $check1 . ">";

echo"<span id='invspan' style='display:";
if($invType == '1') {echo"inline;'>";} else {echo"none;'>";} 

if($p2 == "1") {$check2 = "checked";}
echo"3&nbsp;<input type='checkbox' name='pan3'" . $check2 . ">";

if($p3 == "1") {$check3 = "checked";}

echo"4&nbsp;<input type='checkbox' name='pan4'" . $check3 . ">";
echo "</span>";



echo "</tr></td></table></form><br></div></div>";
echo "<div id='msect'><ul>";
echo"<li><a href='#' onclick='delFunctie(" . $invnr . ")'>delete</a></li>";


echo"<li><a href='PAIRING.php'>pair</a></li>";
echo"<li><a href='#' onclick='helpfunctie()'>help</a></li>";

echo"<li id='sub'><a href='#' onclick='submitFunction($invnr)'>save</a></li>";

goto phpend;
error1:
echo"<h1>currently no inverter exists, click add</h4>"; 
echo"</body></html><!--"; 

phpend:
?>

</ul>

<br>
<form id='delform' action='/cgi-bin/ecu/inverterDel.pl' style='display:none' target='hiddenFrame'>
<input name='ivnr' id='invdel'></form>
</div>

<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>

<script type="text/javascript">

function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

function showFunction() {
  //alert("showFunction");
  document.getElementById("invspan").style.display = "inline";
}
function hideFunction() {
  //alert("showFunction");
  document.getElementById("invspan").style.display = "none";
}
function myFunction(){
 if(document.getElementById("invt").value != '1' ) { 
    hideFunction();
 } else {
   showFunction();
 }
}
function invKeuze(a) {
document.getElementById("ivnr").value = a;
spinner();
checkReaction();
document.getElementById("invKeuze").submit();
}

function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
   }
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
location.reload();
}
</script>
<iframe id='hf' name='hiddenFrame' width='420' height='100' hidden></iframe>

<form id='invKeuze' action='/cgi-bin/ecu/invkeuzeSave.pl' target='hiddenFrame'>
<input name='ivnr' id='ivnr' style='visibility:hidden'>
</div>
  
</body></html>
