<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="212">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="212">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<style>
body {
 background-color: #EEE;
}
table, th, td {
  border: 1px solid blue; 
font-size:14px; 
padding:2px;
border-collapse: collapse;
  }

.nm {
  width:140px;
  text-align: center;
  Background-color:lightblue;
  }

#ch0 { 
  font-size:20px;
  text-align: center;
  type:text;
  background-color: #ccffcc;
  width:180px;}
  }


@media only screen and (max-width: 800px) {
#ch0 { 
  width:160px;
  font-size:18px;
  }
}

</style>
<SCRIPT language=JavaScript>

var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT>

</head>
<body style="font-family: 'lato',Verdana,Sans-serif;font-size:16px;" onload='colorFields()'>
<div id='msect'>
<ul>
<!--<li><a href='/index.php'>done</a></li>-->
<li><a href='/photo.html'>photo</a></li>
<li><a href='/LOGGING.php'>journal</a></li>
<li><a href='/MEMO.php'>memo's</a></li>
<li style='float:right;'><a href='index.php'><img src='close.png' class='icon'></a><li>';
</ul>
</div>

<div id='msect'><div id='bo'></div><center>
<h2>RPI ECU INFORMATION</h2>
</div>
<div id='msect'><center>
<table>
<?php
$invCount=0;
// read the version 
$version=file_get_contents('/var/www/ecu_data/swVersion.txt');
echo"<tr><td class='nm'>software version<td id='ch0'>" . $version . "</tr>";

// read the number of inverters
$invCount=file_get_contents('/var/www/ecu_data/inverterCount.txt');
echo file_get_contents('var/www/ecu_data/inverterCount.txt');
echo"<tr><td class='nm'>number of inverters<td id='ch0'>" . $invCount . "</tr>";

$panelsCount = 0;
// read the number of panels
for($x = 0; $x < 10; $x++) {
$filename="/var/www/ecu_data/inverters/invProperties" . $x;
if (file_exists($filename)) {
  $jsan = file_get_contents($filename);
  $arr = json_decode($jsan, true);
  if($arr["panels"][0] == '1') {$panelsCount++;}
  if($arr["panels"][1] == '1') {$panelsCount++;}
  if($arr["panels"][2] == '1') {$panelsCount++;}
  if($arr["panels"][3] == '1') {$panelsCount++;}
  }
}
echo "<tr><td class='nm'>number of panels<td id='ch0'>". $panelsCount;

// we read the time data
$filename = '/var/www/ecu_data/startstop.txt';
$file = fopen($filename ,"r");
$start = fgets($file);
$stop = fgets($file);

//$rise = rtrim(fgets($file));
//$set = rtrim(fgets($file));
fclose($filename);
// the start /stop info
echo "<tr><td class='nm'>polling starts at<td id='ch0'>". $start . "hr";
echo "<tr><td class='nm'>polling stops at<td id='ch0'>". $stop .  "hr";

// try fo figure the total energy from database
require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";
$dbname= "invEnergy";
//get connection
$client = new InfluxDB\Client($host, $port);
$database = $client->selectDB('invEnergy');
$total = 0;
for ($x=0; $x < 10; $x++) {
// ************  select total energy ***************
$from="inv". $x; 
$query="SELECT sum(e),count(e) FROM {$from} ";
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
$punten = json_decode($points, true);
//$eng = floatval($punten[0]["sum"]/1000);
$total = $total + floatval($punten[0]["sum"]/1000);
//echo "<tr><td>queried " . $from . "value = " . $eng;
}
echo "<tr><td class='nm'>overall total energy<td id='ch0'>". number_format($total, 1, '.', '') . " kWh"; 

echo "<tr><td title='based on 230g/KWh' class='nm' >CO<sub>2</sub> emission saved: <td id='ch0' title='based on 230g/KWh'>" .number_format($total*0.230, 1) . " kg";

echo "<tr><td class='nm' >trees planted: <td id='ch0' >" .number_format($total*0.0117, 1);




?>
</table>

</div>
<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>  


</body>
 </html> 
  
