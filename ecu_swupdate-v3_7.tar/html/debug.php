<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=0.78' />
<link rel="shortcut icon" type="image/png" href="/favicon.png"/>
<link rel="stylesheet" type="text/css" href="STYLESHEET.css" />

<style>
table{margin-left:50px}
table, th {text-align: center;}

.switch {
  position: relative;
  display: inline-block;
  width: 120px;
  height: 36px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}
.slidecontainer {
    width: 99%; 
    background: #daf7a6;
    } 

.slider {
    -webkit-appearance: none; 
    width: 100%; 
    height: 45px; 
    background: #d3d3d3; 
    opacity: 1;
    } 

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "debug";
  height: 36px;
  width: 52px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(52px);
  -ms-transform: translateX(52px);
  transform: translateX(52px);
  content: "debug";
}

</style>
<script type='text/javascript'>
    

function test() {
alertbox();
document.getElementById('switch').submit();
setTimeout(function(){location.reload(true); }, 5000);
}

function alertbox(){
document.getElementById('waitDiv').innerHTML = "<div class='loader'></div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

</script>

  
</head>
<body>
<div id='msect'>
<kop>  HANSIART RPI ECU </kop>
</div>
<ul>
<li><a href='/index.php'>HOME</a></li>
</ul><br><br>

<div id='waitDiv' style='position:absolute; top: 140px; left: 150px; visibility: hidden'></div>

<div id='msect'>
<div class='divstijl' style='width:430px; font-size:16px;'>
<center>

<h4>DEBUG SETTINGS</h4>
<br>

With the switch below you can determine whether debug information is shown on the webpages.
<br><br><table><tr>

<form method='post' id='switch' action='cgi-bin/ecu/debug_conf.pl' target='hiddenFrame'>
<td>NO<td><label class="switch">
<?php
$file = fopen("/var/www/ecu_data/debugstatus.txt","r");
$status = rtrim(fgets($file));
fclose($file);
if ($status == 'on') {
$chk = 'checked';
} else {
$chk = "";
}
echo"<input type='checkbox' onchange='test()' id='sw' name='sw'" . $chk . ">
  <span class='slider'></span>";
?>
</label><td>YES</td></tr></form></table><br>

<br><br><span style='color: green; font-size: 12px;' class="groen">Tip: When you want to shut off, don't just pull the plug! This can sometimes lead to a corrupt file system. First go to "system commands" amd click shutdown!</span><br></div>

</div>
<br>
<br>
<?php
$file = fopen("/var/www/ecu_data/debugstatus.txt","r");
$status = rtrim(fgets($file));
fclose($file);
if ($status == 'on') {

echo "<iframe name='hiddenFrame' width='420' height='50'></iframe>";
} else {
echo"<iframe name='hiddenFrame' width='20' height='50'hidden></iframe>";
}
?>



</body>
</html> 


