#!/bin/bash

FILE="ecu"
if [ -d "$FILE" ]; then
  echo "<br><br>replace.sh: removing directory ecu<br>"
  rm -rf /usr/lib/cgi-bin/ecu/*
  echo "listing /usr/lib/cgi-bin/ecu to check removal<br>"
  ls /usr/lib/cgi-bin/ecu

  echo "<br>end list: if you see any files, something went wrong.<br>"
  # now restore the html files
  echo "<br>going to copy the ecu directory<br>"
  cp -R ecu /usr/lib/cgi-bin/
else
  echo "error: ecu does not exist<br>"
fi  

  shopt -s extglob
  #$ rm -- !(file.txt 

FILE="html"
if [ -d "$FILE" ]; then

  # to prevent the photo to be overwritten we delete the new photo
  echo "<br>removing an eventual photo from the new html<br>"
  rm html/pics/ecu_photo.jpg

  rm -rf /var/www/html/!(pics)
  echo "<br>removing dir /var/www/html except pics<br>"
  
  echo "listing var/www/html to check removal<br>"
  ls /var/www/html
  echo "<br>should only contain pics !<br>end list<br>"
  # now restore the html files except pics
  echo "<br>going to copy the html directory<br>"

  cp -R html /var/www/ 
else
  echo "error, html does not exist"
fi

  #echo "can we run /usr/lib/cgi-bin/ecu/system/setPermissions.sh?<br>"

  #souce /usr/lib/cgi-bin/ecu/system/setPermissions.sh

  #echo "returned from setPermissions.sh<br>"
  echo "<br><br>script replace.sh ready<br>"
  echo "HTTP:1/1 200 OK<br><br>"

