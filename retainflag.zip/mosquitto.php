<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<script type='text/javascript'>
function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function submitFunction(a) {
document.getElementById("bo").innerHTML="<br>wait...<br>saving<br>mqtt<br>data"; 
document.getElementById("bo").style.display="block"; 
document.getElementById('formulier').submit();
setTimeout(function(){window.location.href=a;}, 3000 ); 
}

function testfunctie(a) {
document.getElementById("bo").innerHTML="<br>wait...<br>sending<br>mqtt<br>message"; 
//document.getElementById("bo").style.display="block"; 
document.getElementById('mqttest').submit();
//setTimeout(function(){window.location.href=a;}, 3000 ); 
}


</script>
</head>

<body>
<div id='msect'>
<div id='bo'></div>
  <div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>MOSQUITTO HELP</h3>
  Mosquitto can be used to send short messages back and forth to an mqtt server (broker).<br>Check 'enable' if you want to use mosquitto.<br><br>
<b>retain flag:</b><br> 
When checked, the last message is kept for a new subscriber.<br><br> 
  <b>address:</b><br>The (ip) address of the mqtt-broker cq domoticz<br><br>
  <b>send topic:</b><br>For outgoing communication to domoticz, the topic is '<strong>domoticz/in</strong>'.<br><br>
  <b>receive topic:</b><br>The topic where will be subscribed for incoming messages.<br><br>
  <b>authentication</b><br>Check this if you want to send username and password with your message. 
  <br><br>
 <b>json format:</b><br>
 the mqtt messages are sent in json format. Choose from the several options you have here.
<br><br>
  <b>json format1:</b>{"idx":215,"nvalue":0, "svalue:":"power;energy"} (domoticz)<br>

<b>json format2:</b>
{"serial":"x","acv":x,"freq":x,"temp":x,"pwr":[pw1, pw2, pw3, pw4], "en":[en1, en2, en3, en4],"totalpwr":x,"totalen":x}<br>

<b>json format3:</b>
{"serial":"x","pw0":x,"pw1":x,"pw2":x,"pw3":x","en0":x,"en1":x,"en2":x,"en3":x,"totalpwr":x,"totalen":x}<br>
<b>json format4:</b>
{"serial":"x","acv":x,"freq":x,"temp":11.8,"dcv":[39.2,39.2,0.0,0.0],"dcc":[0.0,0.0,0.0,0.0],"pw":[0.4,1.0,0.0,0.0],"en":[3.9,3.3,0.0,0.0]}<br>
<b>json format5:</b>
{"serial":"x","acv":x,"freq":x,"temp":11.8,"ch0":[39.2,0.0,0.4,3.9], "ch1":[39.8,0.0,1.0,3.3]} (per channel: dcv dcc pwr en)

<br><br>
<b>test:</b>
Will send a message for testing purpose only on the default port 1883.
 <br><br>

  </div>
</div>
<div id='msect'>
  <ul>
  <li id='sub'><a href='#' onclick='submitFunction("mosquitto.php")'>save</a></li>
  <!--<li><a href='menu.html'>done</a>-->
  <li><a href='#' onclick='testfunctie("mosquitto.php")'>test</a>
  <li><a href='#' onclick='helpfunctie()'>help</a>
<li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';


</ul>
  <br>
</div>

<div id='msect'>
  <h3>MOSQUITTO CONFIGURATION</h3>
</div>

<div id='msect'>
  <div class='divstijl'>
  <center>
  <form id='formulier' method='get' action='/cgi-bin/ecu/mqttSave.pl' oninput='showSubmit();' target='hiddenFrame'><table>
<?php  
// read mqttConfig.json
$filename="/var/www/ecu_data/mqttConfig.json";

$json = file_get_contents($filename);

$arr = json_decode($json, true);

$en = $arr["enabled"];
$ret = $arr["retain"];
$adr = $arr["address"];
$prt = $arr["port"];
$int = $arr["intopic"];
$outt = $arr["outtopic"];
$auth = $arr["auth"];
$us = $arr["username"];
$pw = $arr["password"];
$format = $arr["format"];

if($en == '1'){ $sel = "checked"; }
echo "<tr><td style='width:130px;'>enable ?<td><input type='checkbox' style='width:30px; height:30px;' name='mqtEn' " . $sel . "></input></tr>"; 

if($ret == '1'){ $sal = "checked"; }
echo "<tr><td style='width:130px;'>retain flag ?<td><input type='checkbox' style='width:30px; height:30px;' name='mqtRet' " . $sal . "></input></tr>"; 


echo "<tr><td >address<td><input class='inp6' name='mqtAdres' value='" . $adr . "' size='31' placeholder='broker adres'></tr>";
  
echo "<tr><td >port<td><input class='inp2' name='mqtPort' value='". $prt . "' size='31' placeholder='mqtt port'></tr>";

echo"<tr><td>receive topic:&nbsp<td><input class='inp6' name='mqtIn' value='" . $int . "' placeholder='mqtt topic send' length='60'></tr>";

echo "<tr><td>send topic:<td><input class='inp6' name='mqtOut' value='" . $outt . "' placeholder='mqtt topic receive' length='60'></tr>";

if($auth == '1'){ $sol = "checked"; }
echo "<tr><td style='width:130px;'>authent. ?<td><input type='checkbox' style='width:30px; height:30px;' name='mqtAuth' " . $sol . "></input></tr>"; 

echo "<tr><td>username:&nbsp<td><input class='inp4' name='mqtUser' value='" . $us . "' size='4' length='4'></td></tr>";

echo "<tr><td>password:&nbsp<td><input class='inp4' name='mqtPas' value='" . $pw . "' size='4' length='4'></td></tr>";

if ($format == "1") { $sel1 = 'selected'; }
if ($format == "2") { $sel2 = 'selected'; }
if ($format == "3") { $sel3 = 'selected'; }
if ($format == "4") { $sel4 = 'selected'; }
if ($format == "5") { $sel5 = 'selected'; }
echo "<tr><td>mqtt format<td><select name='mqtFormat' class='sb1' style='width:120px;'>";
echo "<option selected readonly>CHOOSE A FORMAT</option>";
echo "<option value='1' " . $sel1 . ">format 1</option>";
echo "<option value='2' " . $sel2 . ">format 2</option>";
echo "<option value='3' " . $sel3 . ">format 3</option>";
echo "<option value='4' " . $sel4 . ">format 4</option>";
echo "<option value='5' " . $sel5 . ">format 5</option>";

echo "</select></form></td></table></div><br></div>";

// *******************************************************
//         test form
// *******************************************************

echo "<form id='mqttest' style='display:hidden' action='/cgi-bin/ecu/mqttTest.pl' target='new'>";
echo "<input type='hidden' name='addr' value='" . $adr . "'></input>";
echo "<input type='hidden' name='out' value='" . $outt . "'></input>";
echo "<input type='hidden'name='auth' value='" . $auth . "'></input>";
if($auth == 1) {
  echo "<input type='hidden'name='user' value='" . $us . "'></input>";
  echo "<input type='hidden' name='pasw' value='" . $pw . "'></input>";
}
echo"</form>";
?>

<br><br>
<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>  
</body></html>