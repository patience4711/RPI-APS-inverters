<!DOCTYPE html><html><head><meta charset='utf-8'>

</head>
<?php
//first detrmine what the query is and extract the inv nr
$req=$_SERVER['QUERY_STRING'];
$errornr = 0;
$findme = "inv=";
$pos = strpos($req, $findme);
if(strpos($req, $findme) === 0) {
	$len=strlen($req);
	$inv = substr($req, 4, $len-4);
	$intval = intval($inv);
	if($intval > 9 or $intval < 0 ){
		echo "bad inverter nr " . $intval . "<br>";
		
           goto end;
	}        

	// now we check if this inverter has a data file
	$dataFile = "/ramdisk/invData" . $inv;
	//echo "dataFile = " . $dataFile ."<br>\n";
	if(!file_exists($dataFile)) {
	     
          echo "inverter " . $intval . " has no data, is it night?<br>\n";	
		goto end;
		}
	// the file exists so now we read it
	$json = file_get_contents($dataFile);
	echo $json;

} else {
echo "<br>bad request " . $req . ", skipped\n";
}
end:

?>
