<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU-ANALYSIS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">

<style>
.tab {
  Background-color:#d9ffb3; 
  border: 1px solid blue;
  border-collapse: collapse; 
  text-align:left;
  padding:2px;
  font-size:16px; 
  }
td {
  border: 1px solid blue; 
  text-align:left;
  padding:6px 2px 6px 6px;
  font-size:16px; 
  }
tr {height:30px !important;}

tr:nth-child(6n+7),
tr:nth-child(6n+8),
tr:nth-child(6n+9),
tr:nth-child(6n+10) 
{
  background: #cceeff;
}
#loading {
  width:100%;
  height:100%; /* height of 100% too*/
  position: absolute;
  left:0; top:0;
  background-color:rgba(192,192,192,0.9);
  color:white; 
  z-index:10;
  font-size: 60px;
  font-weight: bold;
  text-align: center;
  }
</style>
<SCRIPT language=JavaScript>
var message = "viewing this page is disabled!";
function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }
if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }
document.onmousedown = rtclickcheck;
</SCRIPT>

</head>
<body>
<div id='loading'><br>RPI-ECU<br>please wait<br>for the data <br> to be collected.. </div>

<script>
function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
</script>


<div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>STATISTICS HELP</h3>
  <b>begin and enddate</b><br>The period is including the begin and enddate.
  <br><br><b>average (mean)</b><br>
  The total of energy this period, divided by the count of days.<br><br>
  <b>spread</b><br>
  The difference betweeen the highest and the lowest value.<br><br>
<b>mode</b><br>
  The value that occurs most often.<br><br>
<b>median</b><br>
The middle value when the values are ordered from high to low. <br><br>

</div>
<div id='msect'>

  <ul>
  <!--<li><a href='/chartjs/stats_e.php'>done</a></li>-->
  <li><a href='#' onclick='helpfunctie()'>help</a></li>
  
  

 <!-- </ul></div><div id='msect'> -->

<?php
// read the invnr from the url
$invnr = $_GET['inv'];
echo "<li><a href='/AN_PERIOD.php?inv=" . $invnr . "'>period</a></li>";
echo "<li style='float:right;'><a href='/chartjs/stats_e.php?inv=" . $invnr . "'><img src='close.png' class='icon'></a><li>";

echo "</ul></div><div id='msect'>"; 

// these lines are to get the loading screen
ob_start();

$kat=10;
ob_end_flush(); // <--------------

ob_flush();
flush();


//first we read the start/enddate and inv nr in customQdate.txt
$file="/var/www/ecu_data/customQdate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$dat = fgets($fp);
$Bdatum = new DateTime("$dat");
$Bdatum = $Bdatum->format("Y-m-d");
$dat = fgets($fp);
$Edatum = new DateTime("$dat");
$Edatum = $Edatum->format("Y-m-d");
//$invnr = (int)fgetc($fp);
fclose($fp);
}

// we read the file invChoice.txt
//$invnr = file_get_contents("/ramdisk/invChoice.txt");

echo "<h2>statistical data inverter " . $invnr . "</h2></div><div id='msect'><div class='divstijl'><center>";

echo "<form id='formulier' method='post' action='writeQuerydates.php' target='hiddenFrame'>";


// **************************************************
//        we read the file settings.json
// **************************************************
// we also need the energy price from settings.json
$filename="/var/www/ecu_data/settings.json";
  if(file_exists($filename)) {
    $jsun = file_get_contents($filename);
    $urr = json_decode($jsun, true);
    $price = $urr["price"];
    fclose($filename);
} else {$price = 0;}

$currency = "&curren;";
// we have to read the currency sign
$filename="/var/www/ecu_data/currency.txt";
  if(file_exists($filename)) {
    $fp = fopen($filename, 'r');
    $cur = trim(fgets($fp));    
    fclose($filename);
    if($cur=="er"){
    $currency = "&euro;";
    } elseif ($cur=="do"){
    $currency = "&dollar;";
    } elseif ($cur=="po"){
    $currency = "&pound;";
    } 
   }  
// so if the file not exixts its always current

require 'cusQuery.php';
//echo "cusQuery has run<br>";
//echo "error = " . $error;
//$compare = "query invalid";
if ( $error == "invalid") {
echo "<br><br><h3>no data available</h3>";
goto error;
}

echo "<table><tr>";
echo "<td style='border:none'><strong>timespan : " . $Bdatum . "</strong><td style='width:30px; text-align:center; border:none'> to <td style='border:none'><strong>" . $Edatum . "</strong></table>";

echo"<table class='tab'>";
echo "<tr><td style='width:240px;'>";
echo "total count of days <td style='width:100px;'>" . $cnt . " days";
echo "<tr><td>";
if($sum > 1000) {
echo "total energy produced <td style='width:100px;'>" . number_format($sum/1000, 1, '.', '') . " KWh";
} else {
echo "total energy this period <td style='width:100px;'>" . number_format($sum, 2, '.', '') . " Wh";
}
echo " <tr><td> average energy per day<td> ". number_format($mean, 1, '.', '') .  " Wh</tr>";
$earn= $mean*$price/1000;
echo " <tr><td> average financial return<td> ". number_format($earn, 3, '.', '') .  " " . $currency . "</tr>";
echo "<tr><td> energy spread <td> " . number_format($spread, 2, '.', '');
echo "<tr><td> energy median <td> " . number_format($median, 2, '.', '');
echo "<tr><td> energy mode <td> " . number_format($mode, 2, '.', '');

echo "<tr><td> average power this period<td> " . number_format($meanP, 2, '.', '') .  " W</tr>";
echo "<tr><td> power peak (" . $whenhigh . ")<td> " . number_format($maxP, 2, '.', '') .  " W</tr>";
echo "<tr><td> max avg power (" . $whenhighavg . ")<td> " . number_format($maxavgP, 2, '.', '') .  " W</tr>";
echo "<tr><td> min avg power (" . $whenlowavg . ")<td> " . number_format($minavgP, 2, '.', '') .  " W</tr>";

error:
/*
echo '<script>
    document.getElementById("loading").style.visibility = "hidden";
}
</script>';
*/
?>
</table>

<script>
window.onload = function(){
//alert("loaded"); 
    document.getElementById("loading").style.visibility = "hidden";
}
</script>

<iframe name='hiddenFrame' width='420' height='300' hidden></iframe>  
</body>
</html>
