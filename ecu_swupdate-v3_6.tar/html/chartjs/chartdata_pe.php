<?php
// we need to read which date and inverter we want
// we read the file invChoice.txt
//$invnr = file_get_contents("/ramdisk/invChoice.txt");
// we read the inverternr from the url
$invnr = $_GET['inv'];

$from="inv". $invnr; // to be used in the query

// read the date
$file="/var/www/ecu_data/chartDate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$datum = fgets($fp);
rtrim($datum, "\r\n");
//echo "file exists value datum = " . $datum . "\n<br>";
fclose($fp);
} else {
$datum = date('Y-m-d');
}


if (date_default_timezone_get()) {
$tz = date_default_timezone_get();
}

require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";
$dbname= "invEnergy";
//get connection

$client = new InfluxDB\Client($host, $port);



$database = $client->selectDB('invData');

$begin = new DateTime("$datum");
//$begin->modify("-1 day");
$begin = $begin->format("Y-m-d 03:i:s");

$eind = new DateTime("$datum");
//$eind->modify("+1 day");
$eind = $eind->format("Y-m-d 23:i:s");

$query="SELECT * FROM {$from} where time > '{$begin}' and time < '{$eind}' tz('$tz')";

//echo $query;

$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);

echo $points;



?>

