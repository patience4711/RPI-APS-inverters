<?php
echo "going to upload the file\r\n<br>";
$target_dir = "/var/www/html/pics/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
print_r("\r\n target_file = " .$target_file) . "\r\n";
$uploadOk = 0;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
echo "\r\n<br>imageFileType= " . $imageFileType . "\r\n";


if($target_file != "") {
if ($_FILES["fileToUpload"]["size"] > 140000) {
  echo "\r\n<br>Error, file is too large.\r\n";
  $uploadOk = 0;
  goto skip;
}

if (strstr($target_file, '/var/www/html/pics/ecu_photo') && strstr($target_file, '.jpg'))  {
    echo "\r\n<br>File name is correct.\r\n<br>";
    $uploadOk = 1;
  } else {
    echo "\r\n<br> Filename not correct should contain ecu_photo.jpg \r\n";
  
  $uploadOk = 0;
  }

}

skip:
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) 
{
  echo "\r\n<br>Error, your photo was not uploaded.\r\n";
  // if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
    {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
     } else {
    echo "\n\r\<br>Error, there was an error uploading your file.";
     }
 }
?>
