<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="/favicon.png"/>
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<script>
function helpfunctie(){
alert("make a note of memorable events. Click add to make a new note, or edit in the txtfield. Always preceed with the date");
}

function addNote() 
{
let note = prompt("please enter your note here");
if (note == null) {
  //alert ("null");
  return;
  }
//let Dat = new Date();
    var d = new Date();
        month = '' + (d.getMonth() + 1);
        day = '' + d.getDate();
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2)  day = '0' + day;

  datum = year + "-" + month + "-" + day;
  
  toadd = datum + ":\n" + note + "\n";
alert("toadd = " + toadd);
  const textfield = document.getElementById('notes');
  textfield.value += toadd;

}

function newInput() {
// we make the div onchange visible, the submitbutton
document.getElementById('onchange').style.visibility='visible';
}
</script>

<style>
  .hide { position:absolute; top:-1px; left:-1px; width:1px; height:1px; }

@media only screen and (max-width: 800px) {
  li a {
    font-size:16px;
    padding: 14px 20px 10px 20px;
    width: 44px;
  }
}
</style>


</head>
<div id='msect'><center>
   
<ul style='width: 96vw'>
<!--<li><a href='/index.php'>done</a></li>-->
<li><a href='#' onclick='helpfunctie()'>help</a></li>
<li><a href='#' onclick='addNote()'>add</a></li>
  <li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

</ul><br>

<div class='divstijl' style='width:340px; font-size:20px;'>
<center>
click add to make a new note.<br>
<span style='font-size: 12px'>


<?php
if($_POST['Submit']){ 
$open = fopen("/var/www/ecu_data/notes.txt","w+"); 
$text = $_POST['update']; 
fwrite($open, $text); 
fclose($open); 
echo "<br><br>The file is edited.<br><br />";
echo "<a href='edit_notes.php'><button class='knop'>OK</button></a>";   
  
} else { 

$file = "/var/www/ecu_data/notes.txt"; 

echo "<form id='formulier' action=\"".$PHP_SELF."\" method=\"post\">"; 

echo "<textarea id='notes' Name='update'  cols='40' rows='20'>"; 

if(file_exists($file)) {
//echo "file exists";
  foreach(file($file) as $line) { 
      echo $line;
    } 
  } 

//$dat = date("Y-m-d");
//echo "\n" . $dat . " :\n"; 

echo "</textarea><br><br>";
//echo "<div id='onchange' style = 'visibility:hidden;'";
echo "<button name='Submit' type='submit' class='knop' value='Submit'>save</button></form>"; 

//echo "<button name='add' class='knop' onclick='adNote()'>add a note</button>"; 
}
?> 
</body></html>