<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<script type='text/javascript'>

function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function submitFunction() {
if(!confirm("are you sure? And did you note down the new credentials?")){
   return false;
   }
spinner();
checkReaction();   
document.getElementById('pwform').submit();
 
}

function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
   }
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

</script>
<style>
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }
div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}
.loader {
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-bottom: 16px solid #ffff00; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  font-size: 38px;
  color: #ff00ff; 
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
</head>
<body>

<div id='msect'>
<ul>
<!--<li><a href='menu.html'>done</a></li>-->
<li id='sub'><a href='#' onclick='submitFunction()'>save</a></li>
<li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

</ul>
</div>
<div id='msect'>
<kop>CHANGE PASSWORD</kop>
</div>
<div id='msect'>
<center><div class='divstijl' style='height:64vh; width: 94vw'>
<br><br>
Here you can change the credentials for this website.<br>
If you have this website open to the world it is very important<br>to have a strong password!!!
<form id='pwform' method='get' action='/cgi-bin/ecu/wifi/setPassword.pl' oninput='showSubmit()' target='outputFrame'>
<br><table style="border: 1px solid">
<th><th>your website credentials</th>
<tr><td>user<td><input class='inp7' type='text' name='user' required></tr>
<tr><td>passw<td><input class='inp7' type='text' name='pwd' required></tr>
</table><br>

</form>

<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>

<br>
<iframe name='outputFrame' width='90%' height='250' hidden></iframe>

<br></div></div>
<div id='msect'>

<br>

</body></html>