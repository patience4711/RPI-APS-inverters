<html>
<head>
<title>hansiart RPI ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>

<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">


<style>
  .hide { position:absolute; top:-1px; left:-1px; width:1px; 
   height:1px; 
  }

  td {position : relative;
    height: 45px;
    }
 .butt {
    width: 180px;
}   

</style>

<script type='text/javascript'>
    

function systemHalt() {
if(confirm('system halt, are you sure?')) {
  spinner();
  checkReaction();   
  document.getElementById('haltknop').submit();
}
else {
  alert("shutdown gecanceld"); 
  return false; } 
}

function systemReboot() {
if(confirm('system reboot, are you sure?')) {
  spinner();
  checkReaction();   
  document.getElementById('rebootknop').submit();
}
else {
     alert("reboot cancelled"); 
     return false; } 
}

function fsExpand() {
if(confirm('expand filesystem, are you sure?')) {
var iframe = document.getElementById('frame');
iframe = iframe.contentWindow || ( iframe.contentDocument.document || iframe.contentDocument);

iframe.document.open();
iframe.document.write('<br>the filesystem is going to expand, please wait, this may take some time!');
iframe.document.close();
document.getElementById('expandknop').submit();
}
else {
     alert("expand filesystem canceled"); 
     return false; } 
}


function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
//setTimeout( function() { hideLoader(); }, 1000);
}


function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
     hideLoader();
     //document.getElementById("dldiv").style.visibility="visible";
  }
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

</script>

</head>
<body>
<div id='msect'>   
<ul>
<!--<li><a href='/index.php'>home</a></li>
<li><a href='settimezone.php'>timez</a></li>
<li><a href='ip_config.php'>wifi</a></li>-->
<li><a href='PASSWORD.php'>passwd</a></li>
<li><a href='SWUPDATE.php'>update</a></li>
<li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

</ul><br>
</div>
<div id='msect'>
<kop>  HANSIART RPI ECU </kop>
</div>
<div id='msect'>
<div class='divstijl' style='width:420px; font-size:16px;'>
<center><h4>SYSTEM COMMANDS</h4>

<table>

<tr><td>
<form method="post" id='rebootknop' target='hiddenFrame' action="/cgi-bin/ecu/system/reboot.pl">
<button type='button' id='rb' name='rb' onclick='systemReboot()' class='butt'>system reboot
</button></form>
</tr>

<tr><td>
<form method="post" id='haltknop' target='hiddenFrame' action="/cgi-bin/ecu/system/shutoff.pl">
<button type='button' id='so' name='so' onclick='systemHalt()' class='butt'>system halt
</button></form>
</tr>


<?php
// read the file to see if the expand button is needed.
$file = fopen("/var/www/ecu_data/expand.txt","r");
     $expand = fgetc($file);
     fclose($file);
if ( $expand != "y" ){     
echo"<tr><td><form method='post' id='expandknop' target='hiddenFrame' action='/cgi-bin/ecu/system/expand.pl'>
<button type='button' id='exp' name='exp' onclick='fsExpand()' class='butt'>expand fs</button></form></tr></table>";
}
?>

</table>
<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>
</div>

</div>
<center><iframe id='frame' name='hiddenFrame' width='90%' height='200'></iframe>
<br>
</div>
</body>
</html> 