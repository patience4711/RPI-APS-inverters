#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>
using namespace std;


// ***********************************************************
//                     M A I N
// ***********************************************************

int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running inverterPoll.cgi</h4>\n";

string what;
string when;
string newValue;
//   int which;
   if(argc > 3)
   {
       using std::atoi;
       
       what = string(argv[1]);
       when = string(argv[2]);
       newValue = string(argv[3]); 
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: not enough arguments supplied \n<br>";
       return(3);
    }

cout << "arg1 = " << what << "\n<br>" << endl;
cout << "arg2 = " << when << "\n<br>" << endl;
cout << "arg3 = " << newValue << "\n<br>" << endl;

}
