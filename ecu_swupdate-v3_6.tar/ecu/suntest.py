#!/usr/bin/python
from __future__ import division
import datetime
from suntime import Sun, SunTimeException
import json
import os
with open ("/var/www/ecu_data/settings.json", "r") as myfile:
    data=myfile.read().rstrip()
#print(data)

#{"id":"D6B3011B9780","longitude":5.4780,"latitude":51.439,"offset":20}

jsondata = json.loads(data)
latitude = jsondata['latitude']
longitude = jsondata['longitude']
offset = jsondata['offset']
#print(latitude)
#print(longitude)

#latitude = 51.432
#longitude = 5.476
sun= Sun(latitude, longitude)

today_sr = sun.get_local_sunrise_time()
today_ss = sun.get_local_sunset_time()

rise = format(today_sr.strftime('%H:%M')) 
set = format(today_ss.strftime('%H:%M'))

#print(rise)
#print(set)

pstt = today_sr + datetime.timedelta(minutes = offset)
pstp = today_ss - datetime.timedelta(minutes = offset)

pollstart = format(pstt.strftime('%H:%M'))
pollstop = format(pstp.strftime('%H:%M'))

print("pollstart", pollstart, " pollstop ", pollstop, " sunrise ", rise, " sunset ", set)
#print(pollstop)

pstartminutes = int(format(pstt.strftime('%H'))) * 60 + int(format(pstt.strftime('%M')))
pstopminutes = int(format(pstp.strftime('%H'))) * 60 + int(format(pstp.strftime('%M')))
#print("pstartminutes", pstartminutes)
print("pstartminutes", pstartminutes, " pstopminutes ", pstopminutes)

srminutes = int(format(today_sr.strftime('%H'))) * 60 + int(format(today_sr.strftime('%M')))
ssminutes = int(format(today_ss.strftime('%H'))) * 60 + int(format(today_ss.strftime('%M')))
#print("pstartminutes", pstartminutes)
#print("srminutes", srminutes, " ssminutes ", ssminutes)
dltotalmin = ssminutes - srminutes
#print(str(dltotalmin))
dl=dltotalmin/60
#print(dl)
dlhrs=int(dl)
#print("dlhrs = ", dlhrs)

dlmin=int(round((dl-dlhrs)*60))
#print("dlmin = ", str(dlmin))
print("day length = ", dlhrs, ": ", dlmin, " total minutes: ", dltotalmin)

with open ("/var/www/ecu_data/startstop.txt", "w") as myfile:
    myfile.write(pollstart)
    myfile.write('\n')
    myfile.write(pollstop)
    myfile.write('\n')
    myfile.write(rise)
    myfile.write('\n')
    myfile.write(set)
    myfile.write('\n')
    myfile.write(str(pstartminutes))
    myfile.write('\n')
    myfile.write(str(pstopminutes))
    myfile.write('\n')
    myfile.write(str(dltotalmin))
    myfile.write('\n')
    myfile.write(str(dlmin))
    myfile.write('\n')
    myfile.write(str(dlhrs))

command= "echo \"<br>midnight, time.py runned\" >> /ramdisk/ecu_log.txt"
os.system(command)
