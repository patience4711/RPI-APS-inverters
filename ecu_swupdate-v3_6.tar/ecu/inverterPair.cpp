#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <sstream>
using namespace std;
//using std::strtol;

char pairCmd[224]={0};
int  fd;
char inMessage[512];
int readCounter = 0;
//string invSerial;
string invSerial = "xxxxxxxxxxxx";

// convert a char to Hex **********************************$
int StrToHex(char str[])
{
    return (int)strtol(str, 0, 16);
}

// ************ calculate length of a message to send *****************
char* sLen(char Command[])
{
    char* bufferSln = new char[254];
    sprintf(bufferSln, "%02x", (strlen(Command) / 2 - 2));
    delayMicroseconds(250); //give memset a little bit of time to empty all the buffers

    uint8_t iToUpper = 0;
    while (bufferSln[iToUpper])
    {
        bufferSln[iToUpper] = toupper(bufferSln[iToUpper]);
        iToUpper++;
    }
    return bufferSln;
}


// *************  calculate  the checksum of the message ****************************
char *checkSum(char Command[])
{
    char* bufferCRC = new char[254];
    char bufferCRCdiezweite[254] = {0};

    strncpy(bufferCRC, Command, 2); //as starting point perhaps called "seed" use the first two chars fro$
    delayMicroseconds(250);         //give memset a little bit of time to empty all the buffers

    for (uint8_t i = 1; i <= (strlen(Command) / 2 - 1); i++)
    {
        strncpy(bufferCRCdiezweite, Command + i * 2, 2);
        delayMicroseconds(250);
        sprintf(bufferCRC, "%02x", StrToHex(bufferCRC) ^ StrToHex(bufferCRCdiezweite));
        delayMicroseconds(250); //give memset a little bit of time to empty all the buffers
    }
    uint8_t iToUpper = 0;
    while (bufferCRC[iToUpper])
    {
        bufferCRC[iToUpper] = toupper(bufferCRC[iToUpper]);
        iToUpper++;
    }
    return bufferCRC;
}



// **********   wait for serail available *************************************
bool waitSerialAvailable()
{
  //We start with a delay
  unsigned long wait = millis();
  while ( serialDataAvail(fd) == 0 )
      {
      if ( millis() - wait > 2000) return false; // return false after 2000 milis time out
      }
  // if we are here there is something available
   delay(500); // to give the sender the time to write the data
   return true;
}
// *****************  format the incoming byte *************************************
void processIncomingByte(int inByte)
{
char oneChar[10] = {0};
    sprintf(oneChar, "%02x", inByte);
    strncat(inMessage, oneChar, 2); // append
} // end of processIncomingByte


void sendZigbee(char sendString[] )
{
//serial_port is opened in main;
// print the FE first
     serialPutchar(fd, 0xFE);
     //
     char bufferSend[3];
     for (uint8_t i = 0; i <= strlen(sendString) / 2 - 1; i++)
        {
         // we use 2 characters to make a byte
            strncpy(bufferSend, sendString + i * 2, 2);
            delayMicroseconds(250);                    
            serialPutchar(fd, StrToHex(bufferSend));   
        }


}

void readZigbee() {
  readCounter = 0;
  memset( &inMessage, 0, sizeof(inMessage) ); //zero out the
  delayMicroseconds(250);

  while ( serialDataAvail(fd) > 0 )
    {
      if (readCounter < 256)
      {
         processIncomingByte(serialGetchar(fd));
         readCounter += 1;
       }
       else
       {
         serialGetchar(fd); // just read to empty the serial buffer but do not process
       }

       if (serialDataAvail(fd) == 0)  // the buffer is empty
         {
         //fullIncomingMessage[readcounter] = '\0'; // terminate the char ha mod
         uint16_t iToUpper = 0; // has to be 16bit because the received message if the YC600 a$

         while (inMessage[iToUpper])
          {
             inMessage[iToUpper] = toupper(inMessage[iToUpper]);
             iToUpper++;
          }
        }
     }
        // now we should have catched inMessage
     if (serialDataAvail(fd) == 0)
     {
          //  _waiting_for_response = false;
          //  _ready_to_send = true;
      }
    //cleanIncoming(); // check for F8 and remove it
}

char *split(char *str, const char *delim)
{
    char* p = new char[254]; //strstr(str, delim);
    //char *p = strstr(str, delim);
    p = strstr(str, delim);
   if (p == NULL)
        return NULL; // delimiter not found
    *p = '\0';                // terminate string after head
    return p + strlen(delim); // return tail substring
}

#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

// ****************************************************************************
//             D E C O D E   T H E  I N C O M I N G  M E S S A G E
// ****************************************************************************  


bool decodePairMessage(int welke)
{
// we need the fullincomingMessge and the invSns  invSns = inverterSerial
char messageToDecode[256] = {0};
char CC2530_answer_string[9] = "44810000";
char noAnswerFromInverter[32] = "FE0164010064FE034480CD14011F";
char * result;
char temp[13];
char invID[13]={"xxxxxxxxxxxx"}; // testvalue
//char invSerial[13]="xxxxxxxxxxxx"; // testvalue
string readdata;
//received message with inverter id like : 
//for testing
//strncpy(messageToDecode, "FE1C4481000001013A101414003400622305000008FF1A4080001582153A100E08", 66);
//
//  FE1C 4481000001013A101414002700321401000008FFFF4080001582153A100E9D
//  FE0164020067 FE25448100000F0100001414013100204D03000011408000158215A3D610FFFF80971B01A3D63A100DD9FE1C4481000001013A1014140031007D5003000008FFFF4080001582153A100E82
// the 2nd message is shorter 2524020FFFFFFFFFFFFFFFFF14FFFF140F0102000F1100408000157673A3D810FFFF80971B01A3D8D3

    //Serial.println("inMessage = " + String(inMessage));
    //cout << "inMessage = " << inMessage << "\n<br>";
    if (strlen(inMessage) < 255) {
      strncpy(messageToDecode, inMessage, strlen(inMessage));  // get rid of the preceeding FE0164020067
      delayMicroseconds(250); //give memset a little bit of time to empty all the buffers
    } else {
    cout << "inMessage too long \n<br> " << endl; 
      return false;
    }  
    //Serial.println("messageToDecode = " + String(messageToDecode));
    
    if (strcmp(messageToDecode, noAnswerFromInverter) == 0) // default answer if the asked inverter doesn't send us values we compare the whole message
    //if (strcmp(inMessage, noAnswerFromInverter) == 0)
    { 
    cout << "received noAnswerFromInverter code, returning..\n<br>" << endl;
      return false;
    }
    // a correct pairig answer = 162
    if (strlen(messageToDecode) < 130 || strlen(messageToDecode) > 180)
    //if (strlen(inMessage) < 130 || strlen(inMessage) > 180)
    {
    cout << "no pairing answer, returning...\n<br>" << endl;
      return false;   
    }
// the message is shorter ans long enough so continueing    
// look for invSerial !!!!! this is a string !!!!
    if (!strstr(messageToDecode, invSerial.c_str())) {
   //if (!strstr(inMessage, invSerial.c_str())) {
      cout << "not found serialnr, returning" << endl;
      return false;
    }

     // invSerial is in the message so we split there
     cout << "split to find invSerial \n<br>" << endl;
     result=split(messageToDecode, invSerial.c_str());
     //result=split(inMessage, invSerial.c_str());
     cout << "result after 1st split = " << result << "\n<br>"<< endl;
// so long the invSerial is in  the message, we keep splitting it there
     while ( strstr(result, invSerial.c_str()) )
     {
     result=split(result, invSerial.c_str());
     }
     cout << "result after next split = " << result << "\n<br>"<< endl;

// now we know that it is what we expect so do the next test

    strncpy(temp, result, 4); //this must be the invID
    temp[4]='\0';
//Serial.println("found invID on MessageToDecode" + String(temp));
    memset(invID, 0, sizeof(invID)); //zero out the 
    delayMicroseconds(250);  

    strncpy(invID, "0x", 2);
    strncat(invID, temp + 2, 2);
    strncat(invID, temp, 2);
    invID[6] = '\0';
    
    if ( string(temp) == "0000" ) {
    //String term = "pairing failed, returning false";
    //Update_Log("pairing" , term);
    //ws.textAll(term);
    cout << "the found id (temp) = " << temp << endl;
    return false;    
    }
    cout<< "success, got invID: saving: " << invID << "\n<br>" << endl;

   // now we have to save this to the inv properties file 
   // we already know that this file exists
    char str[1];
    sprintf(str, "%d", welke);
    string fileToread="/var/www/ecu_data/inverters/invProperties" + string(str);
    cout << "fileToread = " << fileToread << "<br>" << endl;
    //if(fexists(fileToread)) {
    std::ifstream t(fileToread);
    std::stringstream buffer;
    buffer << t.rdbuf();
    readdata=buffer.str();
  
    RSJresource my_inverterRead (readdata);
   // cout << "json from file = " <<  my_inverterRead.as_str() << endl;
    string my_id = "'" + string(invID) + "'";
    my_inverterRead["id"] = my_id;
   // this is a trick to get the quotes at the name
    string name = my_inverterRead["name"].as<string>();
    string my_name = "'" + name + "'";
    my_inverterRead["name"] = my_name;
// do the same for idx
    string didx = my_inverterRead["idx"].as<string>();
    string my_idx = "'" + didx + "'";
    my_inverterRead["idx"] = my_idx;

   // now we added the id and took care for the quotes
   // we can save this now
    string toSend = my_inverterRead.as_str();
    string command = "echo \"" + my_inverterRead.as_str() + "\" > \"" + fileToread + "\"";
    cout << "save command = " << command <<  "\n<br>" << endl; // prints 5
    system(command.c_str());

    // the file was saved with single quotes so we have to replace them
     char sedCmd[130]={"sed -i 's|['AA']|'BB'|g' "};
     //add the filename
     strncat( sedCmd, fileToread.c_str(), strlen(fileToread.c_str()));
     //replace AA with \' and BB with \"
     sedCmd[12] = 92; sedCmd[13] = 39;
     sedCmd[18] = 92; sedCmd[19] = 34;
     cout << "sedCmd = " <<  sedCmd << "\n<br>" <<endl;
     system(sedCmd);

  
     //memset( &messageToDecode, 0, sizeof(messageToDecode) ); //zero out the
     //delayMicroseconds(250);     
     memset( &result, 0, sizeof(result) ); //zero out the
     delayMicroseconds(250);
     cout << "returning to function sendCommands\n<br>" << endl;
     return(true);
} 

// ******************************************************************
//                              SEND THE COMMANDS
// ******************************************************************
int sendCommands(int welke)
{
  string idInvers = "xxxxxxxxxxxx";
  string ecuShort="xxxx";
  //string invSerial = "xxxxxxxxxxxx";
  string readdata;
  int success = 0;
  //bool success = false;
  char sendCmd[254];
  char baseCmd[][254] = {
    "24020FFFFFFFFFFFFFFFFF14FFFF140D0200000F1100", // + String(inv_sn) + "FFFF10FFFF" + ecu_id_reverse,
    "24020FFFFFFFFFFFFFFFFF14FFFF140C0201000F0600",  // + String(inv_sn),
    "24020FFFFFFFFFFFFFFFFF14FFFF140F0102000F1100",  // + String(inv_sn) + ecu_id.substring(2,4) + ecu_id.substring(0,2) + "10FFFF" + ecu_id_reverse,
    "24020FFFFFFFFFFFFFFFFF14FFFF14010103000F0600",  // + ecu_id_reverse
   };
   // we need to read inverter serial, ecu id short and ecu_id invers
   //read the ecu invers

    string fileToread="/var/www/ecu_data/ecuProperties";
    cout << "fileToread = " << fileToread << "<br>" << endl;
    if(fexists(fileToread)) {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
    } 
    else
    {
    cout << fileToread << " not exists\n<br>" << endl;
    return(1);
    }
     RSJresource my_ecuRead (readdata);
     cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
// is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
      idInvers = my_ecuRead["idinvers"].as<string>();
      cout << "idinvers from file = " << idInvers << "\n<br>" << endl;
      ecuShort = idInvers.substr(8, 4);
      cout << "ecushort  = " << ecuShort << "\n<br>" << endl;

// now read the inverter serialnt    
    char str[1];
    sprintf(str, "%d", welke);
    fileToread="/var/www/ecu_data/inverters/invProperties" + string(str);
    cout << "fileToread = " << fileToread << "<br>" << endl;
    if(fexists(fileToread)) {
    std::ifstream t(fileToread);
    std::stringstream buffer;
    buffer << t.rdbuf();
    readdata=buffer.str();
    } 
    else 
    {
    cout << fileToread << " not exists" << endl;
    return(2);
    }
    RSJresource my_inverterRead (readdata);
    cout << "json from file = " <<  my_inverterRead.as_str() << endl;
    // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
    invSerial = my_inverterRead["serial"].as<string>();
    cout << "serial from file = " << invSerial << "\n<br>" << endl;

    cout << "trying to pair inverter"<< welke << "\n<br>" << endl;
   // now we have all the data and we can contruct the commands
   // ***************************** command 1 ********************************************
   // now build command 0 this is prefix + "0D0200000F1100" + String(invSerial) + "FFFF10FFFF" + ecu_id_reverse,
   strncpy(sendCmd, baseCmd[0], sizeof(baseCmd[0]));
   strncat(sendCmd, invSerial.c_str(), 13);
   strncat(sendCmd, "FFFF10FFFF", 11);
   strncat(sendCmd, idInvers.c_str(), 13 );
   //strncat(baseCmd[0], invSerial.c_str(), 13);
   //strncat(baseCmd[0], "FFFF10FFFF", 11 );
   //strncat(baseCmd[0], idInvers.c_str(), 13);
   strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 0 " << sendCmd << "\n<br>" << endl; //oke
   sendZigbee(sendCmd);
   waitSerialAvailable();
   readZigbee();
   if(readCounter == 0 || strlen(inMessage) < 4) { return(4); }
   cout << "inMessage = " << inMessage << "\n<br>";
   // we are not interested in the answer at this time, however when no answer we return
   // build and send command 1
   // cmd_prefix + "0C0201000F0600" + String(inv_sn),
   strncpy(sendCmd, baseCmd[1], sizeof(baseCmd[1]));
   strncat(sendCmd, invSerial.c_str(), 13);
   // add len and crc
   strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 1 " << sendCmd << "\n<br>" << endl; //oke
   sendZigbee(sendCmd);
   waitSerialAvailable();
   readZigbee();   
   if(readCounter == 0 || strlen(inMessage) < 4) { return(4); }
   cout << "inMessage = " << inMessage << "\n<br>";
   // it seems that we here already can have a good answer
   // if this is true we dont have to nalize the other answers
   //if(decodePairMessage(welke) == true) { success = 1;}
  if(decodePairMessage(welke)){ success = true;}

   cout << "proceeding with the next cmd \n<br> " << endl;
   // build and send command 2
   // cmd_prefix + + invSerial + short ecu_id_reverse, + 10FFF + ecu_id_reverse
   strncpy(sendCmd, baseCmd[2], sizeof(baseCmd[2]));
   strncat(sendCmd, invSerial.c_str(), 13);
   strncat(sendCmd, ecuShort.c_str(), 5);
   strncat(sendCmd, "10FFFF", 7);
   strncat(sendCmd, idInvers.c_str(), 13);
   strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 2 " << sendCmd << "\n<br>" << endl; // oke
   sendZigbee(sendCmd);
   waitSerialAvailable(); 
   readZigbee(); // the answer is in inMessage
   if(readCounter == 0 || strlen(inMessage) < 4) { return(4); }
   cout << "decode inMessage = " << inMessage << "\n<br>";
   // now we should check if we have an answer
   // we decode if success = stil false
   if(!success){
   if(decodePairMessage(welke) == true) {success = 1;}
   }
   // build and send command 3
   //pcmd_prefix + "010103000F0600" + ecu_id_reverse
   
   decodePairMessage(welke);
   cout << "proceeding with the next cmd \n<br> " << endl;

   strncpy(sendCmd, baseCmd[3], sizeof(baseCmd[3]));
   strncat(sendCmd, idInvers.c_str(), 13);
   strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   cout << "send cmd 3 " << sendCmd << "<br> " << endl;
   sendZigbee(sendCmd);
   waitSerialAvailable();
   readZigbee(); // the answer is in inMessage
   cout << "decode inMessage = " << inMessage << "\n<br>";
   // now we should check if we have an answer
   // we only decode if success = false
   if(!success) {
   if(decodePairMessage(welke) == true) { success = 1; };
   }//now check if we have an answer
   cout << "all pair cmds done<br>" << endl;
   if(!success) { return(5);}

   return 0;
}

int charToInt(char c)
{
   int arr[]={0,1,2,3,4,5,6,7,8,9};
   return arr[c-'0'];
}


// ***********************************************************
//                                MAIN
// ***********************************************************
int main (int argc, char **argv)
{

   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running inverterPair.cgi</h4>\n";

   int info;
   int which;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);     
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: no inverternumber supplied\n<br>";
       return(3);
    }

    cout << "inverterpair running with arg"<< which << "<br>" << endl;
    //cout << "\n";
    //printf("this is printf<br>");
//     cout << "which = "<< which << endl;


   if (wiringPiSetup () == -1) /* initializes wiringPi setup */
     {
      cout << "unable to start wiringPi<br>" << endl;
      return(1);  
     }
      else 
     {
       cout << "wiringPi started\n<br>" << endl;
     }

  //int serial_port;
  //we open serial0 (portalias) should work for raspberry 2

  if ((fd = serialOpen("/dev/serial0", 115200)) < 0)
  {
    cout << "unable to open serial_port\n<br>" << endl;
    return(0);
  } else {
    cout << "opened port serial0 \n<br>" << endl;
    // if port open we read the serial buffer empty
  }

// loop
// run the commands
info = sendCommands(which);

cout << "info = " << info << "\n<br>" << endl;
switch(info) {
   case 0:
     cout << "successfully paired \n<br>";
     break;
   case 1:
     cout << "could not read /var/www/ecu_data/ecuProperties<br>";
     break;
   case 2:
     cout << "could not read /var/www/ecu_data/inverters/invProperties#<br>";
     break;
   case 3:
     cout << "no valid argument (inverternr) supplied\n<br>";
   case 4:
     cout << "no incoming messages\n<br>";
   case 5:
     cout << "pairing failed, try again...\n<br>";
   default:
     cout << "inverterPair ready\n<br>";
   }
   serialClose(fd);
   
  return info;
}
