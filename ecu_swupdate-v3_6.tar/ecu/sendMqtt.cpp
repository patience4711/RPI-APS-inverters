#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <sstream>
using namespace std;
//using std::strtol;

int mqtt_format;
string mqtt_port; // was int
string mqtt_out;
string mqtt_adr;
int enabled;
int auth;
string mqtt_user;
string mqtt_pass;
string invSerial = "xxxxxxxxxxxx";
string invIdx;

string freq;
string acv;
string temp;
string totalen;
string totalpwr;
string dcv0;
string dcv1;
string dcv2;
string dcv3;
string dcc0;
string dcc1;
string dcc2;
string dcc3;
string pw0;
string pw1;
string pw2;
string pw3;
string en0;
string en1;
string en2;
string en3;

string readdata;
string toMqtt;

int which;
int invType;
int fd;
// template to be able to read values from json as float
    template<>
    float RSJresource::as<float> (const float& def) {
        // return 'def' if empty
        if (!exists()) return (def); // required
        // convert member 'data' (of type std::string) into 'user_t' and return
        return (stof(data)); // example
    }

#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

void sendMqtt() {
  if(auth != 1) {
     string systemCmd="mosquitto_pub -h " + mqtt_adr + " -p " + mqtt_port + " -t " + mqtt_out + " -m " + toMqtt ;
     cout << "systemCmd = " << systemCmd << "\n<br>" << endl;
     system (systemCmd.c_str());
  } else {
//void sendMqttauth() {
    string systemCmd="mosquitto_pub -h " + mqtt_adr + " -p " + mqtt_port + " -u " + mqtt_user + " -P " + mqtt_pass + " -t " + mqtt_out + " -m " + toMqtt ;
    cout << "systemCmd = " << systemCmd << "\n<br>" << endl;
    system (systemCmd.c_str());
  }
} //end sendMqtt()
// ******************************************************************
//                 READ THE CONFIGFILE
// ******************************************************************
int readConfig()
{
    string fileToread="/var/www/ecu_data/mqttConfig.json";
    cout << "fileToread = " << fileToread << "<br>" << endl;
    if(fexists(fileToread)) {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
    } 
    else
    {
    cout << fileToread << " not exists\n<br>" << endl;
    return 1;
    }
     RSJresource my_ecuRead (readdata);
     //cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
// is like this{{"enabled":1,"address":"localhost","port":1883,"intopic":"esp/out","outtopic":"domoticz/in","format":1}
      enabled = my_ecuRead["enabled"].as<int>();
      if(enabled != 1) { return 2; }
      mqtt_adr = my_ecuRead["address"].as<string>();
//      cout << "mqtt_adr from file = " << mqtt_adr << "\n<br>" << endl;
      mqtt_out = my_ecuRead["outtopic"].as<string>();
//      cout << "mqtt_out from file = " << mqtt_out << "\n<br>" << endl;
//      mqtt_port = my_ecuRead["port"].as<int>();
      mqtt_port = my_ecuRead["port"].as<string>();

      auth = my_ecuRead["auth"].as<int>();
      //if(auth != 1) { return 2; }
      mqtt_user = my_ecuRead["username"].as<string>();
      mqtt_pass = my_ecuRead["password"].as<string>();

//      cout << "mqtt_port from file = " << mqtt_port << "\n<br>" << endl;
      mqtt_format = my_ecuRead["format"].as<int>();
//      cout << "mqtt_adr from file = " << mqtt_format << "\n<br>" << endl;
      return 0;
}

int readInverterprop() {

// now read the inverter serialnt    
    char str[1];
    sprintf(str, "%d", which);
    string fileToread="/var/www/ecu_data/inverters/invProperties" + string(str);
    cout << "fileToread = " << fileToread << "\n<br>" << endl;
    if(fexists(fileToread)) {
    std::ifstream t(fileToread);
    std::stringstream buffer;
    buffer << t.rdbuf();
    readdata=buffer.str();
    } 
    else 
    {
    cout << "invProperties " << which << "not exists\n<br>" << endl;
    return 2;
    }
    RSJresource my_inverterRead (readdata);
    //cout << "json from file = " <<  my_inverterRead.as_str() << endl;
    // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
    invSerial = my_inverterRead["serial"].as<string>();
//    cout << "serial from file = " << invSerial << "\n<br>" << endl;
    invIdx = my_inverterRead["idx"].as<string>();
//    cout << "idx from file = " << invIdx << "\n<br>" << endl;    return 0;
    invType = my_inverterRead["type"].as<int>();
    return 0;
}

int readInverterdata() 
{
//  now read the inverter polldata
    char str[1];
    sprintf(str, "%d", which);
    string fileToread="/ramdisk/invData" + string(str);
    cout << "fileToread = " << fileToread << "<br>" << endl;

    if(fexists(fileToread)) 
    {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
//    }
//    else
//    {
//    cout << "invData" << which << " not exists\n<br>" << endl;
//    return 2;
//    }
// if the file exists we read the data else we make everything 0
      RSJresource my_ecuRead (readdata);
     //cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
      if(enabled != 1) { return 2; }
      acv = my_ecuRead["acv"].as<string>();
//     cout << "acv from file = " << acv << "\n<br>" << endl;
      freq = my_ecuRead["freq"].as<string>();
//      if(freq == "inf") { freq = "0.0"; }
//     cout << "freq from file = " << freq << "\n<br>" << endl;
      temp = my_ecuRead["heath"].as<string>();

// these data we only read when format = 4 or 5
    if(mqtt_format == 4 || mqtt_format == 5) {
//     cout << "temp from file = " << temp << "\n<br>" << endl;
      dcv0 = my_ecuRead["dcv"][0].as<string>();
//     cout << "pw0 from file = " << pw0 << "\n<br>" << endl;
      dcv1 = my_ecuRead["dcv"][1].as<string>();
//     cout << "pw0 from file = " << pw1 << "\n<br>" << endl;
      dcv2 = my_ecuRead["dcv"][2].as<string>();
//     cout << "pw0 from file = " << pw2 << "\n<br>" << endl;
      dcv3 = my_ecuRead["dcv"][3].as<string>();
//     cout << "temp from file = " << temp << "\n<br>" << endl;
      dcc0 = my_ecuRead["dcc"][0].as<string>();
//     cout << "pw0 from file = " << pw0 << "\n<br>" << endl;
      dcc1 = my_ecuRead["dcc"][1].as<string>();
//     cout << "pw0 from file = " << pw1 << "\n<br>" << endl;
      dcc2 = my_ecuRead["dcc"][2].as<string>();
//     cout << "pw0 from file = " << pw2 << "\n<br>" << endl;
      dcc3 = my_ecuRead["dcc"][3].as<string>();
      }
      pw0 = my_ecuRead["pwr"][0].as<string>();
//     cout << "pw0 from file = " << pw0 << "\n<br>" << endl;
      pw1 = my_ecuRead["pwr"][1].as<string>();
//     cout << "pw0 from file = " << pw1 << "\n<br>" << endl;
      pw2 = my_ecuRead["pwr"][2].as<string>();
//     cout << "pw0 from file = " << pw2 << "\n<br>" << endl;
      pw3 = my_ecuRead["pwr"][3].as<string>();
//     cout << "pw0 from file = " << pw3 << "\n<br>" << endl;

      en0 = my_ecuRead["enStack"][0].as<string>();
//     cout << "pw0 from file = " << en0 << "\n<br>" << endl;
      en1 = my_ecuRead["enStack"][1].as<string>();
//     cout << "pw0 from file = " << en1 << "\n<br>" << endl;
      en2 = my_ecuRead["enStack"][2].as<string>();
//     cout << "pw0 from file = " << en2 << "\n<br>" << endl;
      en3 = my_ecuRead["enStack"][3].as<string>();
//     cout << "pw0 from file = " << en3 << "\n<br>" << endl;

      totalen = my_ecuRead["totalen"].as<string>();
//     cout << "totalen from file = " << totalen << "\n<br>" << endl;
      totalpwr = my_ecuRead["totalpw"].as<string>();
//     cout << "totalpw from file = " << totalpwr << "\n<br>" << endl;
      } 
      else
      {  
      // the datafiles are removed when entring sleepmode
      cout << "datafile not exists, all values zero\n<br>" << endl;
      acv = freq = temp = "0.0";
      //freq
      //tem=
      pw0 = pw1 = pw2 = pw3 = "0.0";
      en0 = en1 = en2 = en3 = "0.0";
      totalen = "0.0";
      totalpwr = "0.0";
     }
 return 0;
}

void format1() {
// simple format {"idx":215,"nvalue":0, "svalue:",power;energy} 
toMqtt = "'{\"idx\":" + invIdx + ",\"nvalue\":0,\"svalue\":\"" + totalpwr + ";" + totalen + "\"}'";
cout << "toMqtt = " << toMqtt << "\n<br>" << endl;

sendMqtt();
}

void format2() {
//{"serial":"40800016215","pwr":[pw1, pw2, pw3, pw4], "en":[en1, en2, en3, en4],"totalpwr":totalpw,"totalen":totalen}

toMqtt = "'{\"serial\":\"" + invSerial + "\",\"acv\":" + acv + ",\"freq\":" + freq + ",\"temp\":" + temp;
toMqtt += ",\"pwr\":[" + pw0 + "," + pw1;
if(invType == 1 ) { toMqtt +="," + pw2 + "," + pw3 + "]";} else { toMqtt +="]";} 

toMqtt += ",\"en\":[" + en0 + "," + en1;
if(invType == 1 ) { toMqtt +="," + en2 + "," + en3 + "]";} else { toMqtt +="]";}

toMqtt +=",\"totalpwr\":" + totalpwr + ",\"totalen\":" + totalen + "}'";
sendMqtt();
}

void format3() {

toMqtt = "'{\"serial\":\"" + invSerial + "\",\"acv\":" + acv + ",\"freq\":" + freq  + ",\"temp\":" + temp;
toMqtt += ",\"pw0\":" + pw0 + ",\"pw1\":" + pw1;
if(invType == 1) {toMqtt += ",\"pw2\":" + pw2 + ",\"pw3\":" + pw3;}

toMqtt += ",\"en0\":" + en0 + ",\"en1\":" + en1;
if(invType == 1) { toMqtt += ",\"en2\":" + en2 + ",\"en3\":" + en3;} 

toMqtt += ",\"totalpwr\":" + totalpwr + ",\"totalen\":" + totalen + "}'";
sendMqtt();
}

void format4() {
// can we send the comlete file?
toMqtt = "'{\"serial\":\"" + invSerial + "\",\"acv\":" + acv + ",\"freq\":" + freq  + ",\"temp\":" + temp;
toMqtt += ",\"dcv\":[" + dcv0 + "," + dcv1;
if(invType==1) {toMqtt += "," + dcv2 + "," + dcv3 + "]";} else {toMqtt += "]";}

toMqtt += ",\"dcc\":[" + dcc0 + "," + dcc1;
if(invType==1) {toMqtt += "," + dcc2 + "," + dcc3 + "]";} else {toMqtt += "]";}

toMqtt += ",\"pw\":[" + pw0 + "," + pw1;
if(invType==1) {toMqtt += "," + pw2 + "," + pw3 + "]";} else {toMqtt += "]";}

toMqtt += ",\"en\":[" + en0 + "," + en1;
if(invType==1) {toMqtt += "," + en2 + "," + en3 + "]";} else {toMqtt += "]";}

toMqtt += "}'";
sendMqtt();
}

void format5() {
// values grouped by channel without names
toMqtt = "'{\"serial\":\"" + invSerial + "\",\"acv\":" + acv + ",\"freq\":" + freq  + ",\"temp\":" + temp;
toMqtt += ",\"ch0\":[" + dcv0 + "," + dcc0 + "," + pw0 + "," + en0 + "]";
toMqtt += ",\"ch1\":[" + dcv1 + "," + dcc1 + "," + pw1 + "," + en1 + "]";
if(invType == 1) {
toMqtt += ",\"ch2\":[" + dcv2 + "," + dcc2 + "," + pw2 + "," + en2 + "]";
toMqtt += ",\"ch3\":[" + dcv3 + "," + dcc3 + "," + pw3 + "," + en3 + "]";
}
toMqtt += "}'";
sendMqtt();
}
// ***********************************************************
//                                MAIN
// ***********************************************************
int main (int argc, char **argv)
{

   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running sendMqtt.cgi</h4>\n";

   int info;
//   int which;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);     
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: no inverternumber supplied\n<br>";
       return(3);
    }

    cout << "sendMqtt.cgi running with arg "<< which << "<br>" << endl;
    //cout << "\n";
    //printf("this is printf<br>");
//     cout << "which = "<< which << endl;


   if (wiringPiSetup () == -1) /* initializes wiringPi setup */
     {
      cout << "unable to start wiringPi<br>" << endl;
      return(1);  
     }
      else 
     {
       cout << "wiringPi started\n<br>" << endl;
     }

//    //int serial_port;
//    if ((fd = serialOpen ("/dev/ttyS0", 115200)) < 0)
//    {
//      cout << "unable to open serial_port\n<br>" << endl;
//      return(1);
//    }

// we first have to find out which mqtt format we have to send
// so we have to read the mqttconfigfile

int error = readConfig();
// 1 = no configfile
// 2 = not enabled
if(error != 0) {
cout << "exit with code " << error << "\n<br>" << endl;
return 1;
}

error = readInverterprop();
// 1 = no properties file
if(error != 0) {
cout << "exit with code 2 \n<br>" << endl;
return 2;
}

//mod 22-12 if no inverterData we make all values null
// read the inverterData
error = readInverterdata();
// 1 = no properties file
if(error != 0) {
cout << "invData file didn't exist, return \n<br>" << endl;
return 3;
}

// now we have all data available
switch (mqtt_format) {
   case 1:
     format1();
     cout << "sent message format 1 domoticz\n<br>" << endl;
     break;
   case 2:
     format2();
     cout << "sent message format 2\n<br>" << endl;
     break;
   case 3:
     format3();
     cout << "sent message format 3\n<br>" << endl;
     break;
   case 4:
     format4();
     cout << "sent message format 4\n<br>" << endl;
     break;
   case 5:
     format5();
     cout << "sent message format 5\n<br>" << endl;
   } 
/*
if (mqtt_format == 1) { 
   format1(); 
   cout << "sent message format 1 domoticz\n<br>" << endl;
} else 

if (mqtt_format == 2) {
   format2(); 
   cout << "sent message format 2\n<br>" << endl;
}
else

if (mqtt_format == 3) {
   format3();
   cout << "sent message format 3\n<br>" << endl;
}
*/

// loop
// run the commands
  return 0;
}
