#!/usr/bin/perl

use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running invkeuzeSave.pl";
# test = ecuid=AABBCCDD1122 pw1=1234 pint=120 offs=22
my $query = new CGI;
my $invnr = $query->param('ivnr');

#print "the received in settings.pl commando is:\n ";
#print "$ecu_id $user_pw $poll_int $offset $night_mode $aut_polling<br>\n";

#we gaan deze waarden opslaan in settings.txt
my $filename = '/ramdisk/invChoice.txt';
#open(my $fh, '>', $filename) or die "Could not open file '$filename' $!";

#print $fh "$invnr";
#close $fh;

#print("contents = $json \n");
my $savecommand = "echo $invnr > $filename";
print("savecommand = $savecommand \n<br>");
system($savecommand);

print "\n invChoice.txt saved<br>\n<br>";
print "HTTP/1.1 200 OK";

