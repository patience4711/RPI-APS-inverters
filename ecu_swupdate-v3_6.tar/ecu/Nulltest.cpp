/*
This file checks if there is a invData file in ramdisk
if yes we write all values to null except the total energy
else we make a new file with null values
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>
using namespace std;

#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running invdataNull.cgi</h4>\n";

   int which;
   string what;
   //string energy_total;
   bool newFile = false;
   //string invData;
   // we have 1 argument, what file we clean
// 50

  char str[1];
  sprintf(str, "%d", which);
  string ourDatafile="/ramdisk/invDatatest.txt";
  string readdata;
  
//  the values we need are time and the energy per panel
    string invData = "{'idx':0,'time':, 'acv':,'freq':,'heath':,'dcv':[0, 0, 0, 0],'dcc':[0, 0, 0, 0],'en':[0, 0, 0, 0],'pwr':[0,0,0,0],'totalen':0,'totalpw':0}";

    RSJresource my_resource (invData);


    if(fexists(ourDatafile))
    {
       std::ifstream t(ourDatafile);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
       RSJresource my_resource (invData);
       //energy_total = my_resource["totalen"].as<string>();
       //time = my_resource["time"].as<int>();
       my_resource["acv"] = 0;     // write in the json
       my_resource["freq"] = 0;   // write in the json
       my_resource["heath"] = 0; // write in the json
       //my_resource["time"] = 0; // write in the json

       for(int y = 0; y < 4; y++)
           {
              my_resource["dcv"][y] = 0;
              my_resource["dcc"][y] = 0;
              my_resource["pwr"][y] = 0; // write in the json
              //my_resource["en"][y] = 0; // write in the json
            }
        //my_resource["totalen"] = 0;
        my_resource["totalpw"] = 0;  
        string toSend = my_resource.as_str();

        string command = "echo \"" + my_resource.as_str() + "\" > \"" + ourDatafile + "\"";
        cout << command <<  "\n<br>" << endl; // prints 5
        system(command.c_str());
 
     } 
     // we now have a json with single quotes, we replace them with do$
     // as php cant read this kind of json
        char sedCmd[130]={"sed -i 's|['AA']|'BB'|g' "};
     //add the filename
        strncat( sedCmd, ourDatafile.c_str(), strlen(ourDatafile.c_str()));
     //replace AA with \' and BB with \"
        sedCmd[12] = 92; sedCmd[13] = 39;
        sedCmd[18] = 92; sedCmd[19] = 34;
        cout << "sedCmd = " <<  sedCmd << "\n<br>" <<endl;
        system(sedCmd);
//104        
        cout << "reset values exc energy and time to null\n<br>" << endl;       
        // we have to mqtt this as well
        //string which = std::to_string(y);
        //string mqttCmd ="/usr/lib/cgi-bin/ecu/sendMqtt.cgi " + what;
        //system(mqttCmd.c_str());
      
       


//string toLog = "<br>" + nu + " polling #" + what + " ";
    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%H:%M:%S", ptm);
    //cout << buffer;
    string ts;    
    ts += buffer;
    string toLog;
    //    toLog = "<br>" + ts + "invdataNull.cgi: set values to null except<br>totalen and time in invData" + what;
    toLog = "<br>invdataNull.cgi: set values to null except<br>for totalen and time in /ramdisk/invData" + what;
    cout << "invdataNull.cgi: resetted existing invData\n<br>" << endl;
    
    
    string logCmd = "echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
    system(logCmd.c_str());

    //now do we have to send an entry in the database ?
    //that is done at sunset su we can skip that
    // string dbtestCmd = "curl -i -XPOST 'http:\/\/localhost:8086/write?db=invData' --data-binary 'inv" + to_string(which) + " p=0,e=" + energy_total + "'";
    // cout << "dbtestCmd = " << dbtestCmd << "\n<br>" << endl;
    // system(dbtestCmd.c_str());

    cout << "invdataNull.cgi exit with code 0\n<br>" << endl;
    return 0;
    

} // end main

 


