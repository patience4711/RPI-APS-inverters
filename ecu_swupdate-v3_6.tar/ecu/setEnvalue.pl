#!/usr/bin/perl
use strict;
use warnings;
use Date::Parse; 

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamaters are iv sel in mqidx pan1 pan2 pan3 pan4
print"running script setEnvalue.pl...<br>\n";
$| = 1;
my $query = new CGI;
my $nr =  $query->param('ivnr');
my $dat = $query->param('datum');
my $val = $query->param('env');

print "arg1=$nr arg2=$dat arg3=$val \n<br> ";
#print "argument2 is $dat\n<br> ";
#print "argument3 is $val\n<br> ";

#save invnr and date
my $filename = '/var/www/ecu_data/qinvChoice.txt';
my $savecommand = "echo $dat > $filename";
my $savecommand2 = "echo $nr >> $filename";
print("savecommand = $savecommand \n<br>");
print("savecommand2 = $savecommand2 \n<br>");
system($savecommand);
system($savecommand2);
print "\n qinvChoice.txt saved<br>\n<br>";

#my $ts = $dat."T00:00:01Z";
my $wts = $dat."T04:10:01";

#print "ts is $ts\n<br> ";
# my $timestamp = str2time($ts)."000000000";
my $wtimestamp = str2time($wts)."000000000";
#print "timestamp is $timestamp\n<br> ";
print "wtimestamp is $wtimestamp\n<br> ";
my $start = $dat."T00:00:01Z";
my $stop = $dat."T23:59:59Z"; 

#print "start is $start\n<br> ";
#print "stop is $stop\n<br> ";

#1646607603010231834
#query the old value

my $dbCmd="";
  $dbCmd = "curl -G http://localhost:8086/query?db=invEnergy --data-urlencode \"q=select * from inv$nr where time>\'$start\' and time<\'$stop\' \"";
#print "$dbCmd\n<br>";
print "\n<br>current value(s) are "; 
system($dbCmd);
#we are going to delete the current value for the date
print "\n<br>deleting old value for $dat \n<br>";
my $deleteCmd = "curl -i http://localhost:8086/query?db=invEnergy --data-urlencode \"q=delete from inv$nr where time>'$start' and time<'$stop'\"";
print "deletecommand = $deleteCmd \n<br>";
system($deleteCmd);


if($val != "0") {
print "\n<br>writing new value for $dat \n<br>";
my $writeCmd = "curl -i http:\/\/localhost:8086/write?db=invEnergy --data-binary 'inv$nr e=$val $wtimestamp'";
print "writeCmd = $writeCmd \n<br>";
system($writeCmd);
} else {
print "\n<br>no new value supplied";
}
print "\n<br>query database for $dat\n<br>";
my $queryCmd = "curl http://localhost:8086/query?db=invEnergy --data-urlencode \"q=select e from inv$nr where time >'$start' and time<'$stop'\"";
print "queryCmd = $queryCmd \n<br>";
system($queryCmd);

print "\n<br>all done";
