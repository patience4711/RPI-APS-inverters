#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";
print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print"running script dbBackup.pl...<br>\n";
$| = 1;

sub getTimestamp() {

    my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime(time);
    my $nice_timestamp = sprintf ( "%04d%02d%02d",
                                   $year+1900,$mon+1,$mday);
    return $nice_timestamp;
}

my $dbCmd="";
my $delCmd = "rm /var/www/html/backups/*";
print "<br>cleaning /var/www/html/backups from older backups";
system($delCmd);
my $delCmd2 = "rm /var/www/ecu_data/dbbackup/*";
print "<br>cleaning /var/www/ecu_data/dbbackup from older backups";
system($delCmd2);



#unlink glob "$dir/var/www/ecu_data/dbbackup/*";

print "<br>entering /var/www";
chdir "/var/www";
# ************************************************************************
# backup databases into /var/www/ecu_data/dbbackup
# ************************************************************************

print "<br>going to backup databases invData and invEnergy";
#now backup the individual databases
my $db1Cmd = "influxd backup -portable -database invData ecu_data/dbbackup";
print "$db1Cmd \n<br>";
system ($db1Cmd);

my $db2Cmd = "influxd backup -portable -database invEnergy ecu_data/dbbackup";
print "$db2Cmd \n<br>";
system ($db2Cmd);

# we are in the directory var/www
# ecu_data now contains the database backup.
# when tarred this should be removed
# the next step = backing up the whole directory ecu_data
# to a location where it can be downloaded
# we must make a tar because otherwise it isn't restored

my $timeStamp=getTimestamp(); 
my $tarbal ="/var/www/html/backups/$timeStamp-ecu_backup.tar";
print "<br>tarbal = $tarbal";

my $zipCmd = "tar -cf $tarbal ecu_data";

print "<br>zipCmd = $zipCmd \n<br>";
system ($zipCmd);
print "<br> tarred the whole directory ecu_data";


# cleanup
my $clean5 = "rm /var/www/ecu_data/dbbackup/*";
print "$clean5 \n<br>";
system($clean5);
print "<br>cleaned the directory /var/www/ecu_data/dnbackup";
print "\n dbCmd command processed\n<br>";
print "HTTP:1/1 200 OK";

