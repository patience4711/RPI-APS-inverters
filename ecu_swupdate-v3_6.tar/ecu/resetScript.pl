#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running resetScript.pl...<br>";
print "wiping all inverter data<br>\n";

# remove the properties files
my $remCommand="";
my @a = (0..9);
for(@a){

   my $fileName="/var/www/ecu_data/inverters/invProperties$_";
   #print "$fileName\n<br>";
   if( -e $fileName ) {
     $remCommand= "rm $fileName";
     print "removing $fileName\n<br>";
     print "$remCommand<br>\n";
     system($remCommand);
    }
}

#we also need to drop all values in databases
@a = (0..9);
for(@a){

my $measurement ="inv$_";
print "measurement =  $measurement \n<br> ";
my $dbCmd="";
my $db1Cmd="";
   $dbCmd = "curl -G http://localhost:8086/query?db=invData --data-urlencode 'q=delete from $measurement'";
   system($dbCmd);

   $db1Cmd = "curl -G http://localhost:8086/query?db=invEnergy --data-urlencode 'q=delete from $measurement'";
   system($db1Cmd);
#testcommand on dbase test
#  $dbCmd = "curl -G http://localhost:8086/query?db=test --data-urlencode 'q=delete from $measurement'";
#  system($dbCmd);

 } #end for loop

system "echo 0 > '/var/www/ecu_data/inverterCount.txt'";

# we also set invChoice to 0
system "echo 0 > '/ramdisk/invChoice.txt'";
print "resetcommand runned<br>";
print "HTTP:1/1 200 OK";

