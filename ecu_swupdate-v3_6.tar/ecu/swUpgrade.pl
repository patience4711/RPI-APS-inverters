#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";

print "running script swUpgrade.pl...<br>\n";
$| = 1;

# this script runs when there is a swupgrade tarball
# we need to unzip the file and replace the files
# therefor a script is included in files

# clean redundant files
my $clean = "rm -R /var/www/swupdate/files/*";
print "$clean \n<br>";
system($clean);
print "cleaned eventually files from /var/www/swupdate/files\n<br>";

# first check if there is a file in /var/www/html/protected/uploads
my $filesPresent = 0;
#my $file = 'X';
my $dir = "/var/www/html/protected/uploads";
    opendir(DIR, $dir) or die $!;
    while (my $file = readdir(DIR)) {
        # Use a regular expression to ignore files beginning with a period
        next if ($file =~ m/^\./);
        # Use a regular expression to ignore files NOT .tar
        next unless ($file =~ m/\.tar$/);
        print "$file\n";
        $filesPresent +=1;
    }
    closedir(DIR);
print "found $filesPresent files\n<br>";
if ($filesPresent < 1 || $filesPresent > 1) {
print "no files or too many, should be exactly one \n<br>";
# we check if we should remove files
 if ($filesPresent > 1) {
    my $rem = "rm /var/www/html/protected/uploads/*";
    print "$rem removing the eventual too many files\n<br>";
    system($rem);
    }
exit 10;
} else {
print "found exactly one .tar files \n<br>";
# so now we know that we have exactly one file with extension .tar
# we rename it to ecu_swupdate.tar
my $renameCmd = "mv  /var/www/html/protected/uploads/*.tar /var/www/html/protected/uploads/ecu_swupdate.tar";
print "renameCmd = $renameCmd \n<br>";
system($renameCmd);
}

# if all went ok we now have a file with name ecu_swupdate.tar
#we check that
if ( -e "/var/www/html/protected/uploads/ecu_swupdate.tar") {
my $unzipCmd = "tar -xvf /var/www/html/protected/uploads/ecu_swupdate.tar";
print "unzipCmd = $unzipCmd \n<br>";

#we need to enter the dir /var/www/swupdate/files
print "\n<br>entering /var/www/swupdate/files\n<br>";
chdir "/var/www/swupdate/files";
# now executed the unzip command
print "\n<br>untar the archive\n<br>";
system ($unzipCmd);
# now we have a directory with all the files and a script to take the actions

# first we look for the file apacheRestart.txt to determine to restart apache
my $resFlag = 0;
if(-e "apacheRestart.txt") {
$resFlag = 1;
}
# now we look for the script install.pl in files
if(-e "install.pl") {
# must we make this script executable ? no
# then we execute the script.
print "\n\n<br>calling the install script";
my $installCmd = "/var/www/swupdate/files/install.pl";
system($installCmd);
} else {
print "\n<br<install.pl not found";
}


# so far this works, now restore the database backup in ecu_data/dbbackup
# to a temporary database, from there we copy the data back to the original

# the backup was like "influxd backup -portable -database test ecu_data/dbbackup";
# ****************************************************************************
#                   restore to bak databases
# ****************************************************************************

# ****************************************************************************
#       clean the redundant files and drop the bak databases
# ****************************************************************************
print "\n<br><br> * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *";
print "\n<br><br>going to clean all upgrade files \n<br>";


print "\n<br>leaving /var/www/swupdate/files\n<br>";
chdir "/var/www/swupdate";


my $clean5 = "rm -R /var/www/swupdate/files/*";
print "$clean5 \n<br>";
system($clean5); 

my $clean6 = "rm /var/www/html/protected/uploads/*";
print "$clean6 \n<br>";
system($clean6);

#now all uploaded an unpacked files are removed
# check if apache needs restart
if($resFlag == 1) {
  print "\n\n now going to restart apache<br>";
  print "********** WARNING ***************<br>";
  print "this page wil be greyed out";
  my $apRestart = "sudo systemctl restart apache2.service";
  system($apRestart)
  }
} else {
print "not found ecu_swupdate.tar";
}

print "\n dbCmd command processed\n<br>";
print "HTTP:1/1 200 OK";

