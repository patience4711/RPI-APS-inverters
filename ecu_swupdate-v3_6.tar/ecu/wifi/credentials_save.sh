#!/bin/bash

#this script writes new values in /etc/network/interfaces

ssid=$1
pswd=$2

echo "script credentials_save.pl args: "
echo $ssid
echo $pswd

reppsk="\"$2\""
repssid="\"$1\""

#echo $repssid
#echo $reppsk

sed -i "/ssid/c\ssid=$repssid" /etc/wpa_supplicant/wpa_supplicant.conf
sed -i "/psk/c\psk=$reppsk" /etc/wpa_supplicant/wpa_supplicant.conf

#we moeten nu controleren of we een static ip hadden, zo ja dit rest$
#lees wifi_status.txt
file="/var/www/radio_data/wifistatus.txt"
status=$(cat "$file")
echo $status

if [ $status = "static" ]
then
   cp /etc/network/interfaces_stat /etc/network/interfaces
   echo "wifistatus hersteld"
fi

python /usr/lib/cgi-bin/radio/display/matrix1x.py 'credentials saved'

echo "<br><saved !!<br>"

