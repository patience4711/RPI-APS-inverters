#!/usr/bin/perl
#Dit script wordt uitgevoerd om de wificredentials op te slaan 
#via een sh script wifi_conf.sh
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running script wificredentials.pl ";
# call with ssid= pswd= user= pwd=
my $query = new CGI;
my $ssid = $query->param('ssid');
my $pswd = $query->param('pswd');
my $bauser = $query->param('user');
my $bapass = $query->param('pwd');

my $wisbestand1 = ">temp.txt";


#print "running script wificredentials.pl ";
#print $ssid."<br>";
#print $pswd."<br>";

#my $command="/bin/bash /usr/lib/cgi-bin/ecu/wifi/credentials_save.sh $ssid $pswd";
my $command="sudo /usr/lib/cgi-bin/ecu/wifi/credentials_save.sh $ssid $pswd";

print $command;

print "saving wifi credentials...</br>\n";
system ($command);

my $authCmd = "sudo /usr/lib/cgi-bin/ecu/wifi/setPasswd.cgi $bauser $ bapass";
print $authCmd;
system ($authCmd);

print "wificredentials.pl ready...</br>\n";
print "HTTP/1.1 200 OK";

