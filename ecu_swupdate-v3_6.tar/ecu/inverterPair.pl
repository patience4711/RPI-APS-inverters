#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamater is cmb
print"running script inverterPair.pl...<br>\n";
$| = 1;

my $query = new CGI;
my $zbt = $query->param('ivnr');
print "argument is $zbt\n<br> ";

#we call testZigbee.cgi with arg cmd

my $pairCmd="sudo /usr/lib/cgi-bin/ecu/inverterPair.cgi $zbt";
print "$pairCmd\n<br>";
system($pairCmd);

print "pair command processed\n<br>";
print "HTTP:1/1 200 OK";

