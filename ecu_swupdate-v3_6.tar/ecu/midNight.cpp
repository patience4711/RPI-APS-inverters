/*
the function of this file is to reset the values of the former day
we keep the sum of the energy in invEnergy
if there was a reset, the sum of the energyvalues in invData will not be correct.
In this case we should write the value in ramdisk to invEnergy.
we remove the datafiles in ramdisk insteat of setting them to 0
we remove the file chartdate so that all chart queries point to today
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>
#include "influxdb.hpp"

using namespace std;

template<>
  float RSJresource::as<float> (const float& def) {
        // return 'def' if empty
        if (!exists()) return (def); // required
        // convert member 'data' (of type std::string) into 'user_t' and return
        return (stof(data)); // example
  }

#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

string forMat(float pi, int pr)
{
std::stringstream stream;
stream << std::fixed << std::setprecision(pr) << pi;
std::string s = stream.str();
return s;
}

string thisTime() {
// thisTime is today at 01:00:00
    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%F 01:00:00", ptm); //("Y-m-d H:i:s");
    //cout << buffer;
    string ts;
    ts += buffer;
    return ts;
}
string yesterDay() {
    time_t noow = time(nullptr) - (24*60*60);
    tm * ptm = localtime(&noow);
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%F 01:00:00", ptm); //("Y-m-d H:i:s");
    //cout << buffer;
    string ts;
    ts += buffer;
    return ts;
}

int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running midNight.cgi</h4>\n";

   string beginTime = yesterDay();
   string endTime = thisTime();
//   cout << "begintime = " << beginTime << " endtime = " << endTime << "<br>\n" << endl;


// we start with making the log empty
  string toLog = "";
  toLog = "<br>" + endTime + " running midNight.cgi";
  string logCmd = "echo \"" + toLog + "\" > /ramdisk/ecu_log.txt";
//  cout << "toLog = " << toLog << "\n<br>" << endl;
  system(logCmd.c_str());

  //cout << "toLog = " << toLog << "\n<br>" << endl;
  //string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";


// now we reset the values for each inverter
// we could also just remove them
  for(int y = 0; y <9; y++) {

  // we should make all the values 0 in the invDatafile
  // thats already done at sunset except for totalenergy


  char str[1];
  sprintf(str, "%d", y);
  string ourInverterfile="/var/www/ecu_data/inverters/invProperties" + string(str);
    
  if(fexists(ourInverterfile)) {
  cout << "invProperties exists so we carry on \n<br>" <<endl;
  
  float energy_ramdisk;
  float energy_dbase;
    // we have to set the value for totalen also to null
    // insteat we remove the file if it exists
    // first we read the value of totalenergy
    // if this is bigger than the queried value we use it
    string ourDatafile="/ramdisk/invData" + string(str);
    string readdata;
    if(fexists(ourDatafile))
    {
       std::ifstream t(ourDatafile);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();

       RSJresource my_inverterRead (readdata);
       cout << "json from file = " <<  my_inverterRead.as_str() << "\n<br>" <<endl;
       // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA",
       energy_ramdisk = my_inverterRead["totalen"].as<float>();

       string Command = "rm " + ourDatafile;
       system(Command.c_str());

     } else {
        cout << "datafile not exixts, skipping \n<br>" << endl;
     }

  
// the value we need is the total energy
// we query this from the database
// we need the sum of today's value energy in invData
// first find out what is today // we run this after mid so
// we likely need the date of yesterday
       
//       string sel = "select sum(e) from inv" + to_string(y);
string sel = "select sum(e) from inv" + to_string(y) + " where time > \'" + beginTime + "\' and time < \'" + endTime + "\'";
       cout << "sel = " << sel << "\n<br>" << endl;
       influxdb_cpp::server_info si("127.0.0.1", 8086, "invData", "" , "");
       string resp;

//       int ret = influxdb_cpp::query(resp, "select last(e) from inv0", si);
       int ret = influxdb_cpp::query(resp, sel, si);
       cout << "query has runned, ret = " << ret << "\n<br>" << endl;

       RSJresource my_resp (resp);
  //   cout << "json from file = " <<  my_resp.as_str() << "\n<br>" <<endl;
       energy_dbase = my_resp["results"][0]["series"][0]["values"][0][1].as<float>();

  // if the value in ramdisk = greater than in the query, there must have been a reboot
  // in this case we make the queried value equal to that in ramdisk.
  // the value in ramdisk is the value reported by the inverter
       if(energy_ramdisk > energy_dbase) energy_dbase = energy_ramdisk;
         
// now we write this to invEnergy  

       string dbCmd = "curl -i -XPOST 'http:\/\/localhost:8086/write?db=invEnergy' --data-binary 'inv" + to_string(y) + " e=" + forMat(energy_dbase, 1) + "'";
       cout << "dbCmd = " << dbCmd << "\n<br>" << endl;
       system(dbCmd.c_str());

      } else {
      cout << "invProperties" << str << " not exixts\n<br>"<< endl;
      }
    
  } // end for loop

    // we remove the chartdate settings so we see always the today's charts
     string rmCmd = "rm /var/www/ecu_data/chartDate.txt";
     system(rmCmd.c_str());
    // we also remove the chartMonth settings so we see always the last 2 weeks chart
     string rm2Cmd = "rm /var/www/ecu_data/chartMonth.txt";
     system(rm2Cmd.c_str());
    // we should modify the file /var/www/ecu_data/customQdate.txt wich has 2 rows
    //2022-01-01
    //2022-08-10
    // the second row should become the date of yesterday
    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);

    --ptm->tm_mday; // Move back one day
    mktime(ptm); // Normalize

    char baffer[11];
    strftime(baffer, sizeof(baffer), "%Y-%m-%d", ptm);
    cout << "baffer = " << baffer << "\n" << endl;

    ifstream infile("/var/www/ecu_data/customQdate.txt");
    if (infile.good())
    {
      string sLine;
      getline(infile, sLine);
      //cout << sLine << endl;
      string cd1 = "echo " + sLine + " > /var/www/ecu_data/customQdate.txt";
      //cout << "cd1 = " << cd1 << "<br>\n" << endl;
      system(cd1.c_str());
      //now apped baffer
      string s;
      s += baffer;
      string cd2 = "echo " + s + " >> /var/www/ecu_data/customQdate.txt";
      //cout << "cd2 = " << cd2 << "<br>\n" << endl;
      system(cd2.c_str());
    }    
// prepare the logging
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%H:%M:%S", ptm);
    //cout << buffer;
    string ts;
    ts += buffer;
    toLog = "<br>" + ts + " midNight.cgi moved energy total into db invEnergy";

    logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
    system(logCmd.c_str());

    logCmd = "echo '<br>midNight: removed data files' >> /ramdisk/ecu_log.txt";
  //logCmd = "echo tolog >> /ramdisk/ecu_log.txt";
    system(logCmd.c_str());

     cout << "midNight: exit with code 0\n<br>" << endl;
     return 0;
}
// end main

 


