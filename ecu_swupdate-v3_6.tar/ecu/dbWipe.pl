#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamater is cmb
print"running script dbWipe.pl...<br>\n";
$| = 1;

my $query = new CGI;

my $db = $query->param('db');
my $inv = $query->param('ivnr');

print "arguments are $db and $inv \n<br> ";

my $measurement ="inv$inv"; 
print "measurement  $measurement \n<br> ";
my $dbCmd="";
if ($db eq "invData") {
  $dbCmd = "curl -G http://localhost:8086/query?db=invData --data-urlencode 'q=delete from $measurement'";
} 
if ($db eq "invEnergy") {
  $dbCmd = "curl -G http://localhost:8086/query?db=invEnergy --data-urlencode 'q=delete from $measurement'";
}
if ($db eq "test") {
  $dbCmd = "curl -G http://localhost:8086/query?db=test --data-urlencode 'q=delete from $measurement'";
}

print "$dbCmd \n<br>";
system ($dbCmd);

print "\ndbCmd command processed\n<br>";
print "HTTP:1/1 200 OK";

