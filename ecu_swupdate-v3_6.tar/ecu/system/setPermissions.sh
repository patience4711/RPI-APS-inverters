#!/bin/bash
# we run this script as 
#echo "<br>***********************************************"
#echo "<br>    running the script setPermissions.sm "
#echo "<br>***********************************************"
#echo "<br>going to set permissions and owners for some files and dirs\n<br>"
# this script runs from the directory /var/www/swupdate/files/install.pl
# this is where the tar is unzipped 

# when we tar a dir the privileges get changed, we should correct that
# first we check the permissions on /var/www/html/protected/uploads
#echo "checking permissons on /var/www/html/protected/uploads";

check=`ls -ld /var/www/html/protected/uploads`
if [ ${check:1:9} != 'rwxrwxrwx' ]; then

  echo "rwx failes so we need to restore"

  #first we reset the owners for html dir and ecu
  #echo "change owner of /usr/lib/cgi-bin/ecu to root <br>"
  chown -R root:root /usr/lib/cgi-bin/ecu

  #echo "restoring privileges a+rwx for /var/www/html/protected/uploads <br>" 
  chmod a+rwx /var/www/html/protected/uploads

  #echo "restoring privileges a+rw for /var/www/html/pics <br>"
  chmod a+rw /var/www/html/pics

  #echo "restoring privileges a+rw for /var/www/html/pics/ecu_photo.jpg <br>"
  chmod a+rw /var/www/html/pics/ecu_photo.jpg

  #echo "restoring privileges a+rw for /var/www/html/backups <br>"
  chmod a+rw /var/www/html/backups

  #echo "restoring privileges a+rw for /ramdisk/ecu_log.txt <br>"
  chmod a+rw /ramdisk/ecu_log.txt

  # write to the log
  echo "<br>setPermissions.sh : needed to restored permissions." >> /ramdisk/ecu_log.txt
  echo "setPermissions.sh : needed to restored permissions"
else
  # write to log
  echo "<br>setPermissions.sh : checked permissions OK" >> /ramdisk/ecu_log.txt
  echo "<br>setPermissions.sh : checked permissions OK"
fi

echo "<br>script setPermissions.sh ready<br>"
echo "HTTP:1/1 200 OK<br><br>"

