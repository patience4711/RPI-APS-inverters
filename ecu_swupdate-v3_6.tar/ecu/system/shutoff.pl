#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
$| = 1;

my $haltcmd = "sudo /sbin/shutdown -h now";

print "system is going down...<br>\n";
sleep(5);

system($haltcmd);
print "systeem down...<br>\n";
print "wait 30 sec. before you pull the plug.<br>\n";
print "HTTP/1.1 200 OK"; 

