#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";

$| = 1;

print "\n\n<br>***********************************************";
print "\n<br>   running script install.pl";
print "\n<br>***********************************************";
print "\n\n<br>   installing zram, check log below \n\n<br>";

# this script runs from the directory /var/www/swupdate/files/install.pl
# this is where the tar is unzipped 

# **********************************************************
#   install zram and add lines to /etc/sysctl.conf
# **********************************************************
# we must also replace the file sudoers to obtain permissions
#$filename = "sudoers";
#if (-e $filename) {
#  my $cpSudo = "sudo cp $filename /etc/";
#  print "\n<br>cpSudo = $cpSudo \n<br>";
#  print "copying sudoers /etc \n<br>";
#} else { print "\n<br>file $filename not exists"; }
# 

my $comR = "sudo /var/www/swupdate/files/replace.sh";
print"<br>calling $comR as sudo ..";
system($comR);

# ***************************************************************
#                    update version number
# ***************************************************************

my $versionCmd = "echo 'RPI-ECU-v4_4' > /var/www/static_data/swVersion.txt";
print "\n<br>versionCmd = $versionCmd \n<br>";
system ($versionCmd);


print "\n\n\n install zram done\n<br>";
print "HTTP:1/1 200 OK";

