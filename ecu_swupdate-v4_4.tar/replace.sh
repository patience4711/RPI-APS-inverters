#!/bin/bash
# we run this script as sudo so we set permissions in sudoers
echo "<br>***********************************************"
echo "<br>    running the script zram.sh "
echo "<br>***********************************************"


    echo "<br>running zram.sh<br>"
# we run this script as sudo so we need to set permissions in sudoers

echo "<br> ** processing apt install zram-tools **<br>"
echo"please wait, this can take some time !<br>"
apt install zram-tools --yes

echo "<br>add some lines to /etc/sysctl.conf"
echo "# added mods for zram"  >> /etc/sysctl.conf
echo "vm.vfs_cache_pressure=500" >> /etc/sysctl.conf
echo "vm.swappiness=100" >> /etc/sysctl.conf
echo "vm.dirty_background_ratio=1" >> /etc/sysctl.conf
echo "vm.dirty_ratio=50" >> /etc/sysctl.conf

echo "<br>processing sysctl --system"
sysctl --system
echo "<br>processing cat /proc/swaps"
cat /proc/swaps

echo "<br>script zram.sh ready<br>"
echo "HTTP:1/1 200 OK<br><br>"
