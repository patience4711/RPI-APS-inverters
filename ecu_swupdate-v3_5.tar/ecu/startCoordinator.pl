#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print"running script startCoordinator.pl...<br>\n";
print"calling startCoordinator.cgi\n";
$| = 1;

my $query = new CGI;
my $nr = $query->param('normal');
print "argument is $nr <br>";

# we are going to try to start the coordinator 3 times, 
# after each start we check if it is running

my @a = (1..3);
for(@a){
#  my $command = " sudo /usr/lib/cgi-bin/ecu/startCoordinator.cgi $nr"; 
#  print "command to run = $command<br>";
#  print"calling startCoordinator.cgi\n";
#  system($command);

  #first we check if it is running, if so break out of the loop
  my $checkcommand = " sudo /usr/lib/cgi-bin/ecu/checkCoordinator.cgi";
  print "command to run = $checkcommand<br>";
  print"calling checkCoordinator.cgi\n";
  my $result = system($checkcommand);
  print "result = $result \n<br>";
  if($result == 0) { 
    print "broke out at $_ \n<br>";
    goto rest; 
  }
  print "coordinator checked, not running, starting\n<br>";
  #if it was not running, we start it
  my $command = " sudo /usr/lib/cgi-bin/ecu/startCoordinator.cgi $nr";
  print "command to run = $command<br>";
  print"calling startCoordinator.cgi\n";
  system($command);
  sleep 6;
}
rest:
print "\n make /ramdisk/invChoice and set value and permissions \n<br>";
# invChoice is written in ramdisk so this does not exist at boot
# so we make invChoice equal to the first available name
# and write this in ramdisk
my $keuze = 0;
my $invfile ="";
my @a = (0..9);
for(@a){
   $invfile = "/var/www/ecu_data/inverters/invProperties$_";
   # print "file = $invfile \n<br>";
   if (-e $invfile)
   {
     $keuze = $_;
     #print "found $invfile , choise = $choice \n<br>";
     last;
   }
}
# when nothing found the choice remains 0
my $keuzefile = "/ramdisk/invChoice.txt";
system "echo $keuze > $keuzefile";
# this file should be writable to anyone
# this is done by setPermissions
my $chmodCmd = "chmod a+rwx /ramdisk/invChoice.txt";
system ($chmodCmd);

my $perm ="/usr/lib/cgi-bin/ecu/system/setPermissions.sh";
system($perm);

print "startCoordinator runned<br>";
print "HTTP:1/1 200 OK";

