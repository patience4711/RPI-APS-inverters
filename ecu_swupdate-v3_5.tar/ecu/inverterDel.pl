#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamaters are iv sel in mqidx pan1 pan2 pan3 pan4
print"running script inverterDel.pl...<br>\n";
$| = 1;

my $query = new CGI;
my $nr = $query->param('ivnr');
print "argument is $nr\n<br> ";

#we are going to delete the data file
my $fileName = "/var/www/ecu_data/inverters/invProperties$nr"; 
print "fileName to delete = $fileName\n<br>";
my $deleteCmd="rm $fileName";
print "deletecommand = $deleteCmd \n<br>";
system($deleteCmd);

#we are going to delete the data file
$fileName = "/ramdisk/invData$nr";
print "fileName to delete = $fileName \n<br>";
my $deleteCmd="rm $fileName";
print "deleteCmd = $deleteCmd \n<br>";
system($deleteCmd);

# read inverterCount, decr 1 and save
my $countFile="/var/www/ecu_data/inverterCount.txt";
my $invCount="";
open(FH, "<", $countFile) || die $!;
while ( <FH> ){
$invCount = $_;
}
close(FH);
print "read inverterCount = $invCount \n<br>";
my $count2int = int($invCount)-1;
#$count2int += 1;
print "subtracted 1 from inverterCount $count2int\n<br>";
system "echo $count2int > $countFile";

# invChoice has the value of the deleted inverter,
# this is a problem as it doesn't exist anymore
# so we make invChoice equal to the first available name
my $keuze = 0;
my $invfile ="";
my @a = (0..9);
for(@a){
   $invfile = "/var/www/ecu_data/inverters/invProperties$_";
   # print "file = $invfile \n<br>";
   if (-e $invfile)
   {
     $keuze = $_;
     #print "found $invfile , choise = $choice \n<br>";
     last;
   }
}

my $keuzefile = "/ramdisk/invChoice.txt";
system "echo $keuze > $keuzefile";

print "\n<br>inverter data saved\n<br>";
print "HTTP:1/1 200 OK";

