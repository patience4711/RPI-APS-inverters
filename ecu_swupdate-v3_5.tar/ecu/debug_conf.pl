#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

$| = 1;
my $query = new CGI;
my $status = $query->param('sw');

print"running ecu script debug_conf...<br>\n";
#save the value of sw
my $filename = "/var/www/ecu_data/debugstatus.txt";
print "filename = $filename";
open(my $file, '>', $filename) or die "Could not open file '$filename' $!";
print "saving $status";
print "filename = $filename";
print $file "$status\n";
close $file;

print "settings saved...<br>\n";
print "HTTP/1.1 200 OK"; 



