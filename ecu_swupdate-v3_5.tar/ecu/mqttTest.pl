#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

# the paramaters are addr ans out
print"running script mqttTest...<br>\n";
$| = 1;

my $query = new CGI;
my $address = $query->param('addr');
my $outtopic = $query->param('out');
my $auth = $query->param('auth');
my $username = $query->param('user');
my $password = $query->param('pasw');

print "the value of auth = $auth <br>";
print "the value of username = $username <br>";
print "the value of password = $password <br>";

my $testcommand = "mosquitto_pub -h $address -t  $outtopic -m 'hello from rpi ecu'";

if( $auth == 1) {
   $testcommand = "mosquitto_pub -h $address -u $username -P $password -t $outtopic -m 'authenticated hello from rpi ecu'";
  } 

print("testcommand = $testcommand \n<br>");

system($testcommand);

print "mosquitto test runned..\n<br>";
print "HTTP:1/1 200 OK";

