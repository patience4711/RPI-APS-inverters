#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <sstream>

using namespace std;

char checkCmd[10]={"0"};
char inMessage[512];
int readCounter = 0;
int fd;

// convert a char to Hex **********************************
int StrToHex(char str[])
{
    return (int)strtol(str, 0, 16);
}
// split a char after a delimiter
char *split(char *str, const char *delim)
{
    char* p = new char[254]; //strstr(str, delim);
    //char *p = strstr(str, delim);
    p = strstr(str, delim);
   if (p == NULL)
        return NULL; // delimiter not found
    *p = '\0';                // terminate string after head
    return p + strlen(delim); // return tail substring
}


bool waitSerialAvailable() 
{
  //We start with a minimum delay
  //delay(800);
  unsigned long wait = millis();
  while ( serialDataAvail(fd) == 0 )
      {
      if ( millis() - wait > 2000) return false; // return false after 2000 milis time out
      }
  // if we are here there is something available
   delay(500); // to give the sender the time to write the data
   return true;
}

// format the incoming byte and add it to inMessage
void processIncomingByte(int inByte)
{
char oneChar[10] = {0};
    sprintf(oneChar, "%02x", inByte);
    strncat(inMessage, oneChar, 2); // append 
} // end of processIncomingByte

void sendZigbee(char sendString[] )
{
     // print the FE first
     serialPutchar(fd, 0xFE);
     //
     char bufferSend[3];
     for (uint8_t i = 0; i <= strlen(sendString) / 2 - 1; i++)
        {
         // we use 2 characters to make a byte
            strncpy(bufferSend, sendString + i * 2, 2);
            delayMicroseconds(250);                     
            serialPutchar(fd, StrToHex(bufferSend));    
        }

}

void readZigbee() {
  readCounter = 0;
  memset( &inMessage, 0, sizeof(inMessage) ); //zero out the 
  delayMicroseconds(250);

  while ( serialDataAvail(fd) > 0 )
    {
      if (readCounter < 512)
      {
         processIncomingByte(serialGetchar(fd));
         readCounter += 1;
       }
       else
       {
         serialGetchar(fd); // we read from serial to empty the buffer but do not process
       }
    
       if (serialDataAvail(fd) == 0)  // the buffer is empty
         {
         //fullIncomingMessage[readcounter] = '\0'; // terminate the char ha mod
         uint16_t iToUpper = 0; // has to be 16bit because the received message if the YC600 answers is longer then 255
         while (inMessage[iToUpper])
          {
             inMessage[iToUpper] = toupper(inMessage[iToUpper]);
             iToUpper++;
          }
        }
     }
        // now we should have catched inMessage
     if (serialDataAvail(fd) == 0)
     {
          //  _waiting_for_response = false;
          //  _ready_to_send = true;
      }
    //cleanIncoming(); // check for F8 and remove it
}


#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

// **********************************************************
//             M A I N  P R O G R A M 
// **********************************************************
int sendCommands() {
char * tail;
string readdata;
string idInvers = "xxxxxxxxxxxx";
    
   strncpy(checkCmd, "00270027", 9); // including len and crc
 
   cout << "command = "<< checkCmd << "\n<br>" << endl;

   sendZigbee(checkCmd); // sends the global checkCmd

   waitSerialAvailable(); 
    //  return false; 
   
   // if there was nothing to read we returned
   // so there is data available
   readZigbee();
   if(readCounter < 2 ){
        cout << "no answer\n<br>" << endl;
        return 1;
   }
   if(readCounter > 19 ){
        cout << "answer too long \n<br>" << endl;
        return 2;
   }
   cout << "answer = " << inMessage << " rc=" << readCounter << "\n<br>" << endl; 
   
   // now we need to analize it
   // we read the file ecuProperites to get ecu rev
    string fileToread="/var/www/ecu_data/ecuProperties";
    cout << "fileToread = " << fileToread << "<br>" << endl;
    if(fexists(fileToread)) {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
    }
    else
    {
    cout << fileToread << " not exists\n<br>" << endl;
    return(9);
    }
    RSJresource my_ecuRead (readdata);
    //cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
// is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"BBAA"}
    idInvers = my_ecuRead["idinvers"].as<string>();
    cout << "idinvers from file = " << idInvers << "\n<br>" << endl;

    if( readCounter == 19 && strstr(inMessage, idInvers.c_str()) )
    {
        tail = split(inMessage, idInvers.c_str() + 4);
        if( strstr(tail, "0709") ) 
            {
             return 0; // coordinator up          
            }
//        if( strstr(tail, "0700") )
//            {
//             return 3; // coordinator needs start
//            }
     } // end if 19              
// if we are here there is an error
return 5;
}

void empty_serial() {
// read all avialable bytes to make the buffer empty
  while ( serialDataAvail(fd) > 0 )
    {
       serialGetchar(fd);
    }
 }

int main ()
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running checkCoordinator.cgi</h4>\n";

   if (wiringPiSetup () == -1) /* initializes wiringPi setup */
   {
      
      cout << "unable to start wiringPi\n<br>" << endl;
      return 1;  
   }
    else 
   {
    cout << "wiringPi started\n<br>" << endl;
   }

    //int serial_port;
    //we opern serial0 (portalias) should work for raspberry 2

  if ((fd = serialOpen("/dev/serial0", 115200)) < 0)
  {
    cout << "unable to open serial_port\n<br>" << endl;
    return(0);
  } else {
    cout << "opened port serial0 \n<br>" << endl;
    // if port open we read the serial buffer empty
    empty_serial();
  }

int success;

// loop
success = sendCommands();

serialClose(fd);

    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%H:%M:%S", ptm);
    //cout << buffer;
    string ts;
    ts += buffer;

    string toLog = "<br>" + ts + " checking zb system ";

    switch (success) {
     case 0:
      toLog += "running ok";
      cout << "coordinator is running ok \n<br>" << endl;
      //return 0;
      break;
     case 1:
      toLog += "failed, no answer on serial";
      cout << "no answer on serial \n<br>" << endl;
      //return 1;
      break;
     case 2:
      toLog += "failed, answer too long";
      cout << "answer too long \n<br>" << endl;
      //return(2);
      break;
//     case 3:
//      toLog += "failed, need start (6700)  command";
//      cout << "coordinator needs to be started \n<br>" << endl;
//      break;
    case 5:
      toLog += "failed, an unknown error occurred";
      cout << "an unknown error occurred \n<br>" << endl;
      //return(5);
      break;
   case 9: 
      toLog += "failed, no inverter properties file";
      cout << "no inverter properties file found \n<br>" << endl;
      break;
  }
  // now we send the log
     cout << "toLog = " << toLog << "\n<br>" << endl;
     string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
     cout << "logCmd = " << logCmd << "\n<br>" << endl;
     system(logCmd.c_str());
    
     if (success == 0) { return 0; } else {return 1;}
}

 


