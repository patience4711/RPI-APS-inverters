#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";

print"running script logScript.pl....<br>\n";
$| = 1;

my $query = new CGI;
my $tolog = $query->param('tolog');

print "argument is $tolog\n<br> ";
my $syscmd="echo '<br>$tolog' >> /ramdisk/ecu_log.txt";

system($syscmd);

print "command processed\n<br>";
print "HTTP:1/1 200 OK";


