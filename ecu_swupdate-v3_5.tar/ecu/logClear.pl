#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print"running script logClear.pl...<br>\n";

$| = 1;

my $command = "echo  >  /ramdisk/ecu_log.txt"; 
print "command to run = $command \n";
system($command);

print "\ncommand runned<br>";
print "HTTP:1/1 200 OK";

