#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the pamater is cmb
print"running script dbQuery.pl...<br>\n";
$| = 1;

my $query = new CGI;

my $db = $query->param('db');
my $inv = $query->param('ivnr');
my $dat = $query->param('datum');
print "arguments are $db and $inv and $dat \n<br> ";

#save invnr and date
my $filename = '/var/www/ecu_data/qinvChoice.txt';
my $savecommand = "echo $dat > $filename";
my $savecommand2 = "echo $inv >> $filename";
#print("savecommand = $savecommand \n<br>");
#print("savecommand2 = $savecommand2 \n<br>");
system($savecommand);
system($savecommand2);
#print "\n qinvChoice.txt saved<br>\n<br>";

my $measurement ="inv$inv"; 
# print "measurement  $measurement \n<br> ";
my $dbCmd="";
if ($db eq "invData") {
#  $dbCmd = "curl -G http://localhost:8086/query?db=invData --data-urlencode \"q=select * from $measurement WHERE time < '$dat'+1d  ORDER BY desc LIMIT 20\"";
  $dbCmd = "curl -G http://localhost:8086/query?db=invData --data-urlencode \"q=select * from $measurement WHERE time < '$dat'+1d  ORDER BY desc LIMIT 1000\"";
  print "<h4> ** query last 1000 entries from $dat **</h4>";
} else {
  $dbCmd = "curl -G http://localhost:8086/query?db=invEnergy --data-urlencode \"q=select * from $measurement WHERE time < '$dat'+1d ORDER BY desc \"";
  print "<h4> ** $db query all values from $dat **</h4>";
}
print "$dbCmd \n<br>";

my $outputfile="/var/www/ecu_data/query.txt";
my $tempfile="/var/www/ecu_data/temp.txt";

my $tCmd="> $outputfile";
my $qc=$dbCmd . $tCmd;
#print "\n$qc";
system($qc);

#if ($db eq "invEnergy") {
my $trCmd1 = "tr [ '\n' < $outputfile > $tempfile";
#print "\n\n $trCmd1";
system($trCmd1);
my $trCmd2 = "tr -d ] < $tempfile > $outputfile";
#print "\n\n $trCmd2";
system($trCmd2);

my $sedCmd2 = "sed -i '1,5d' $outputfile";
#print "\n\n $sedCmd2";
system($sedCmd2);

#remove first character of each line
my $sedCmd4 = "sed -i 's/^.//g' $outputfile";
#print "\n\n $sedCmd4";
system($sedCmd4);

#remove braces
my $sedCmd6 = "sed -i 's/}//g' $outputfile";
#print "\n\n $sedCmd3";
system($sedCmd6);

if ($db eq "invEnergy") {
#remove comma's
my $sedCmd3 = "sed -i 's/,//g' $outputfile";
#print "\n\n $sedCmd3";
system($sedCmd3);

#replace doublequotes with space
my $sedCmd4 = "sed -i 's/\"/ e= /g' $outputfile";
#print "\n\n $sedCmd4";
system($sedCmd4);
#print "\n\n<br>";

} else {
#replace comma's
my $sedCmd3 = "sed -i 's/,/ p= /2' $outputfile";
#print "\n\n $sedCmd3";
system($sedCmd3);

#remove other comma's
my $sedCmd5 = "sed -i 's/,//g' $outputfile";
#print "\n\n $sedCmd3";
system($sedCmd5);

#remove doublequotes 
my $sedCmd4 = "sed -i 's/\"/ e= /g' $outputfile";
#print "\n\n $sedCmd4";
system($sedCmd4);

}

open(FH, '<', $outputfile)  or die $!;
while(<FH>){
print "\n<br> $_";
}
close(FH);

print "\n<br><br>dbCmd command ready\n<br>";
print "HTTP:1/1 200 OK";

