#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";
# the paramater is cmb
print"running script testZigbee.pl...<br>\n";
$| = 1;

# my $query = new CGI;
# my $zbt = $query->param('cmd');
# print "argument is $zbt\n<br> ";

#we call testZigbee.cgi with arg cmd

my $testCmd="sudo /usr/lib/cgi-bin/ecu/checkCoordinator.cgi";
print "$testCmd\n<br>";
my $result = system($testCmd);
my $startresult;
print "result = $result \n<br>";
use Switch;
switch(result) {
  case 0 { print "coordinator running OK") }
  
  case 1 { my $startCmd = "sudo /usr/lib/cgi-bin/ecu/startCoordinator.cgi";
           startresult = system($startCmd);
         {
  
  case 3 { my $startCmd = "sudo /usr/lib/cgi-bin/ecu/sendZigbee.cgi 6700"; }
 }

print "command processed\n<br>";
print "HTTP:1/1 200 OK";

