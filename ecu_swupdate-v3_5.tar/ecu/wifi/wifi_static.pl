#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";


$| = 1;
# this script is used to setup a static ip
 
my $query = new CGI;
my $gw = $query->param('gw');
my $ip = $query->param('ip');
my $nm = $query->param('nm');
#
print"<br>static ip configuration<br>\n";
print "gw  = $gw<br>\n";
print "ip  = $ip<br>\n";
print "nm  = $nm<br>\n";

#print "the writecommand = \n";
my $regel1 = "echo 'source-directory /etc/network/interfaces.d'> /etc/network/interfaces";
my $regel2 = "echo '#\n#\n#\nauto lo\niface lo inet loopback\nallow-hotplug wlan0 \n#\n#\n#\n'>> /etc/network/interfaces";

my $regel3 = "echo 'iface wlan0 inet static' >> /etc/network/interfaces";
my $regel4 = "echo 'address $ip' >> /etc/network/interfaces";
my $regel5 = "echo 'netmask $nm' >> /etc/network/interfaces";

#we have to breakup the ipadress by removing the last dot
my $ipbase = $gw;
#print "ipbase original = $ipbase \n";
$ipbase =~s/\.[^.]+$//;
#print "ipbase processed = $ipbase \n";
# network 192.168.0.0
# gateway 192.168.0.1
# broadcast 192.168.0.255

my $regel6 = "echo 'network $ipbase.0' >> /etc/network/interfaces";
my $regel7 = "echo 'gateway $gw' >> /etc/network/interfaces";
my $regel8 = "echo 'broadcast $ipbase.255' >> /etc/network/interfaces";
my $regel9 = "echo '\n#\n#\nwpa-conf /etc/wpa_supplicant/wpa_supplicant.conf' >> /etc/network/interfaces";


system($regel1);
system($regel2);
system($regel3);
system($regel4);
system($regel5);
system($regel6);
system($regel7);
system($regel8);
system($regel9);

my $statuscommand = "echo static > /var/www/ecu_data/wifistatus.txt";
system($statuscommand);

my $rebootcmd = "sudo /sbin/reboot";
system ($rebootcmd);

print "static ip configured.. reboot now..<br>\n";
print "HTTP/1.1 200 OK"; 
