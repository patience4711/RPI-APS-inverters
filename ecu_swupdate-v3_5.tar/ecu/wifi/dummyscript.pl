#!/usr/bin/perl
# this script is runned to delete the wifi credentails
#via an sh script wifi_conf.sh
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running dummy script.pl \n<br> ";
# call with ssid= pswd= user= pwd=
#my $query = new CGI;
sleep(5);
print "dummyscript ready...</br>\n";
print "<h3>reboot to start the accesspoint</h3>";
print "HTTP/1.1 200 OK";

