#!/usr/bin/perl
# this script is runned to delete the wifi credentails
#via an sh script wifi_conf.sh
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print "running script wipe_wificredentials.pl \n<br> ";
# call with ssid= pswd= user= pwd=
#my $query = new CGI;
my $ssid = "ssid";
my $pswd = "ppww";
my $bauser = "admin";
my $bapass = "0000";

my $wisbestand1 = ">temp.txt";

#print $ssid."<br>";
#print $pswd."<br>";

#my $command="/bin/bash /usr/lib/cgi-bin/ecu/wifi/credentials_save.sh $ssid $pswd";
my $command="sudo /usr/lib/cgi-bin/ecu/wifi/credentials_save.sh $ssid $pswd";

print $command;

print "wiping wifi credentials...</br>\n";
system ($command);

my $authCmd = "sudo /usr/lib/cgi-bin/ecu/wifi/setPasswd.cgi $bauser $bapass";
print $authCmd;
#system ($authCmd);

print "wipe_wificredentials.pl ready...</br>\n";
print "<h3>reboot to start the accesspoint</h3>";
print "HTTP/1.1 200 OK";

