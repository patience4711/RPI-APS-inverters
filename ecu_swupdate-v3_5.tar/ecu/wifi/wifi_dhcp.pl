#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

print"<br>dhcp config<br>\n";
$| = 1;
# this script is used for setup of a static ip
 
my $regel1 = "echo 'source-directory /etc/network/interfaces.d'> /etc/network/interfaces";
my $regel2 = "echo '#\n#\n#\nauto lo\niface lo inet loopback\n\nallow-hotplug wlan0'>> /etc/network/interfaces";

my $regel3 = "echo 'iface wlan0 inet dhcp' >> /etc/network/interfaces";

my $regel9 = "echo '\n\n\nwpa-conf /etc/wpa_supplicant/wpa_supplicant.conf' >> /etc/network/interfaces";


system($regel1);
system($regel2);
system($regel3);
system($regel9);

my $statuscommand = "echo dhcp > /var/www/ecu_data/wifistatus.txt";
system($statuscommand);
#print "dhcp set<br>";
#print "HTTP/1.1 200 OK"; 
my $rebootcmd = "sudo /sbin/reboot";
system ($rebootcmd);
#print "rebooting<br>";
#print "HTTP/1.1 200 OK";



