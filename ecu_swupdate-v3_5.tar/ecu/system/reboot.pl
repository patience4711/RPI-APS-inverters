#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";

$| = 1;


my $rebootcmd = "sudo /sbin/reboot";




print "<br>system going to reboot...<br>\n";
print "\n<br> WARNING: this may take some time !";
print "\n<br> the ECU is not reponsive during this time !";
#sleep(5);

system($rebootcmd);
print "\n\n<h3>after a minute, click \"home\" (left above)</h3>";

print "HTTP/1.1 200 OK"; 

