#!/usr/bin/perl -l
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
print"running script timeset..<br>\n";
$| = 1;


# the argumenten come from args array
# de parameter has the shape tz=Europe/Amsterdam
my $query = new CGI;
my $tijdZone = $query->param('tz');
print "provided timezone = $tijdZone<br>";
if ($tijdZone eq "") {
  print "timezone is empty<br>\n";
  $tijdZone = "error";
} 
#we check if this tz data is valid
my $check = "/usr/share/zoneinfo/$tijdZone";
#print "check = $check<br>"; 

if (-e $check) {
# a command that $tijdZone save in timezone_temp.txt
my $command = "echo $tijdZone > /var/www/ecu_data/timezone_temp.txt";
print "valid timezone, you have to reboot to effectuate";
system($command);
} else {
# a command that error in timezone_temp.txt writes
my $command = "echo error > /var/www/ecu_data/timezone_temp.txt";
system($command);
print "ERROR! invalid timezone, try again<br>\n";
}

print "<br>script done...check for errors!<br>\n";
print "HTTP/1.1 200 OK";

