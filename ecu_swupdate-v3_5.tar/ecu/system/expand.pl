#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body>";

$| = 1;
# we gaan eerst kijken of dit wel nodig is
print"running script expand.pl<br>\n";
my $filenaam = "/var/www/ecu_data/expand.txt";
open(my $fh, '<', $filenaam) or die "Could not open file '$filenaam' $!";
my $expand = <$fh>;
chomp $expand;

close $fh;

if ( $expand ne "y" ) {

#my $radiostopcmd = "/usr/lib/cgi-bin/radio/stop_all.cgi";
my $rebootcmd = "sudo /sbin/reboot";
my $expandcmd = "sudo /usr/bin/raspi-config --expand-rootfs";
my $filecmd = "echo \"y\" > /var/www/ecu_data/expand.txt";

# eerst eventueel bestaande mpg123 processen beeindigen
#system ($radiostopcmd);

#my $displaycmd = "/usr/bin/python /usr/lib/cgi-bin/radio/display/matrix1x.py 'expanding rootfs'";
#my $rat = system($displaycmd);

#my $pin_mode = "gpio mode 26 out";
#my $led_mode = "gpio mode 27 out";
#my $pin_hoog = "gpio write 26 1";
#my $pin_laag = "gpio write 26 0";
#my $led_hoog = "gpio write 27 1";
#my $led_laag = "gpio write 27 0";

#system($pin_mode);
#system($led_mode);

# de power uitschakelen de standby led in
#system($pin_laag);
#system($led_hoog);

print "expanding rootfs...<br>\n";
sleep(5);
system($filecmd); #echo y
system($expandcmd);
system($rebootcmd);

} else {

print "skipped, already expanded";
}
print "HTTP/1.1 200 OK";
