#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <iostream>
#include <fstream>
#include <stdbool.h>
#include "RSJparser.tcc"
#include <math.h>
#include <sstream>
#include <iomanip>
using namespace std;

char inMessage[512];
int readCounter = 0;
int fd;
int invType;
int panels[4] ={0,0,0,0};
int which;
int idx;
int errorcode;
float totalpw; // global as we need to log this
int timespan;
// template to be able to read values from json as float
    template<>
    float RSJresource::as<float> (const float& def) {
        // return 'def' if empty
        if (!exists()) return (def); // required
        // convert member 'data' (of type std::string) into 'user_t' and return
        return (stof(data)); // example
    }

// convert a char to Hex **********************************
int StrToHex(char str[])
{
    return (int)strtol(str, 0, 16);
}

// ************ calculate length of a message to send *****************
char* sLen(char Command[])
{
    char* bufferSln = new char[254];
    sprintf(bufferSln, "%02x", (strlen(Command) / 2 - 2));
    delayMicroseconds(250); //give memset a little bit of time to empty all the buffers

    uint8_t iToUpper = 0;
    while (bufferSln[iToUpper])
    {
        bufferSln[iToUpper] = toupper(bufferSln[iToUpper]);
        iToUpper++;
    }
    return bufferSln;
}


// *************  calculate  the checksum of the message ****************************
char *checkSum(char Command[])
{
    char* bufferCRC = new char[254];
    char bufferCRCdiezweite[254] = {0};

    strncpy(bufferCRC, Command, 2); //as starting point perhaps called "seed" use the first two chars fro$
    delayMicroseconds(250);         //give memset a little bit of time to empty all the buffers

    for (uint8_t i = 1; i <= (strlen(Command) / 2 - 1); i++)
    {
        strncpy(bufferCRCdiezweite, Command + i * 2, 2);
        delayMicroseconds(250);
        sprintf(bufferCRC, "%02x", StrToHex(bufferCRC) ^ StrToHex(bufferCRCdiezweite));
        delayMicroseconds(250); //give memset a little bit of time to empty all the buffers
    }
    uint8_t iToUpper = 0;
    while (bufferCRC[iToUpper])
    {
        bufferCRC[iToUpper] = toupper(bufferCRC[iToUpper]);
        iToUpper++;
    }
    return bufferCRC;
}

bool waitSerialAvailable() 
{
  //We start with a minimum delay
  //delay(800);
  unsigned long wait = millis();
  while ( serialDataAvail(fd) == 0 )
      {
      if ( millis() - wait > 2000) return false; // return false after 2000 milis time out
      }
  // if we are here there is something available
   delay(1000); // to give the sender the time to write the data
   return true;
}

// format the incoming byte and add it to inMessage
void processIncomingByte(int inByte)
{
char oneChar[10] = {0};
    sprintf(oneChar, "%02x", inByte);
    strncat(inMessage, oneChar, 2); // append 
} // end of processIncomingByte

void sendZigbee(char sendString[] )
{
     // print the FE first
     serialPutchar(fd, 0xFE);
     //
     char bufferSend[3];
     for (uint8_t i = 0; i <= strlen(sendString) / 2 - 1; i++)
        {
         // we use 2 characters to make a byte
            strncpy(bufferSend, sendString + i * 2, 2);
            delayMicroseconds(250);                     
            serialPutchar(fd, StrToHex(bufferSend));    
        }

}

void readZigbee() {
  readCounter = 0;
  memset( &inMessage, 0, sizeof(inMessage) ); //zero out the 
  delayMicroseconds(250);

  while ( serialDataAvail(fd) > 0 )
    {
      if (readCounter < 256)
      {
         processIncomingByte(serialGetchar(fd));
         readCounter += 1;
       }
       else
       {
         serialGetchar(fd); // we read from serial to empty the buffer but do not process
       }
    
       if (serialDataAvail(fd) == 0)  // the buffer is empty
         {
         //fullIncomingMessage[readcounter] = '\0'; // terminate the char ha mod
         uint16_t iToUpper = 0; // has to be 16bit because the received message if the YC600 answers is longer then 255
         while (inMessage[iToUpper])
          {
             inMessage[iToUpper] = toupper(inMessage[iToUpper]);
             iToUpper++;
          }
        }
     }
        // now we should have catched inMessage
     if (serialDataAvail(fd) == 0)
     {
          //  _waiting_for_response = false;
          //  _ready_to_send = true;
      }
    //cleanIncoming(); // check for F8 and remove it
}
// ***************************************************************************************************$
//                             extract values
// ***************************************************************************************************$
float extractValue(uint8_t startPosition, uint8_t valueLength, float valueSlope, float valueOffset, char toDecode[512])

{
//    Serial.println("re declare tempMsgBuffer");
char tempMsgBuffer[64] = {0}; // was 254

    memset(&tempMsgBuffer[0], 0, sizeof(tempMsgBuffer)); //zero out all buffers we could work with "me$
    delayMicroseconds(250);                              //give memset a little bit of time to empty a$
    strncpy(tempMsgBuffer, toDecode + startPosition, valueLength);
    delayMicroseconds(250); //give memset a little bit of time to empty all the buffers

     return (valueSlope * (float)StrToHex(tempMsgBuffer)) + valueOffset;
}

char *split(char *str, const char *delim)
{
    char* p = new char[254]; //strstr(str, delim);
    //char *p = strstr(str, delim);
    p = strstr(str, delim);
   if (p == NULL)
        return NULL; // delimiter not found
    *p = '\0';                // terminate string after head
    return p + strlen(delim); // return tail substring
}

float roundoff(float value, unsigned char prec)
{
  float pow_10 = pow(10.0f, (float)prec);
  return round(value * pow_10) / pow_10;
}

#include <fstream>
bool fexists(const std::string& filename) {
  std::ifstream ifile(filename.c_str());
  return (bool)ifile;
}

string forMat(float pi, int pr)
{
std::stringstream stream;
stream << std::fixed << std::setprecision(pr) << pi;
std::string s = stream.str();
return s;
}

string thisTime() {
    time_t noow = time(nullptr);
    tm * ptm = localtime(&noow);
    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
    strftime(buffer, 32, "%H:%M:%S", ptm);
    //cout << buffer;
    string ts;
    ts += buffer;
    return ts;
}

// *********************************************************
//             D E C O D E  P O L L   A N S W E R
// ********************************************************
int decodePollAnswer()
{
// we need to know some properties of inverter which
// the connected panels


// Serial.println("1 decodePollAnswer which = " + String(which) );
// we need the fullincomingMessge and the inverterSerial
  char messageToDecode[512] = {0};
  //char _CC2530_answer_string[] = "4481";
  //char _noAnswerFromInverter[32] = "FE01 6401 00 64 FE03 4480 CD14011F";
  //char noAnswerMess[22] = "FE0164010064FE034480"; //
                        // FE0164010064FE034480 CD14011F
//                       FE0164010064FE034480 E9 14013B
//                       FE0164010064FE034480 E9 14013B
//                       FE0164010064FE034480 00 1401D2 // net voordat er waardes komen
 
  char s_d[254] = {0};
  uint8_t Message_begin_offset = 0;
 
//  time_t t_old = 0;
//  time_t t_new = 0;
  int t_old = 0;
  int t_new = 0;
  float en_old[4] = {0}; // energy old
  float en_new[4]={0};  // energy new
  float en_increase[4]={0};
  float power[4] = {0};
  float en_new_total = 0;
  float en_old_total = 0;
  float en_inc_total = 0;
  //float time_extracted  = 0;
  float en_extracted[4] = {0}; //energy extracted per panel
  float totalEnergy = 0;
  float enstack[4] = {0};
  float enstack_total = 0;
  int polled;
  bool resetFlag = false;
  bool errorFlag = false; 
// if we are here there was an incoming message and the inverter is paired
// incoming message is something like this (4 messages at once)
//FE01 64 01 00 64        request status 6401 00=success
//FE03 44 80 00 14 01 D2    AF_DATA_CONFIRM description: sent by the device to the user after it receives a data request.
// 44 81 AF_INCOMING_MSG Description: This callback message is in response to incoming data to any of the registered endpoint$
//FE72 44 81 0000 06013A101414001F006B20D000005E 408000158215 FBFB51B1042D0F42AA00008E8F00000001200360506704A1000000000020000$

//F8FE0164010064 FE03 448000 1401D2 FE03 45 C4 3A1000A8 FE72 4481000 006013A101414002C001ECBE200005E 408000158215 FBFB51B1042$
//FE0164010064FE034480001401D2FE0345C43A1000A8FE724481000006013A101414004C00
//FE0164010064FE034480

    if(!*inMessage) return 50; // if empty we return with erroCode 50
    strncpy(messageToDecode, inMessage, strlen(inMessage));
    //delayMicroseconds(250); //give memset a little bit of time to empty all the buffers
    cout << "messageToDecode = " << messageToDecode << "\n<br>"<< endl;
    // we dont need this char anymore so make it empty
    memset( &inMessage, '\0', sizeof(inMessage) ); //zero out the
    delayMicroseconds(250);

    char *tail;
    // diagnose the received message
    // diagnose the received message
    //if(diagNose) ws.textAll( "received " + String(messageToDecode));
//FE0164010064
//FE034480001401D2
//FE0345C43A1000A8
//FE724481000006013A10141400730053CF0100005E408000158215FBFB51B103E50F427200003C0B000000C64069C520690494000000000408000079111$


    if(strstr(messageToDecode,  "FE01640100") == NULL) // answer to AF_DATA_REQUEST 00=success
    {
     cout << "AF_DATA_REQUEST failed\n<br>" << endl;
    return 10;
    } else
    if (strstr(messageToDecode, "FE03448000") == NULL) //  AF_DATA_CONFIRM the 00 byte = success
    {
      cout << "no AF_DATA_CONFIRM \n<br>" << endl;
      return 11;
    } else
    if (strstr(messageToDecode, "FE0345C4") == NULL) //  ZDO_SRC_RTG_IND
    {
      cout << "no route receipt \n<br>";
      //return 12; // this command seems facultative
    } else
    if (strstr(messageToDecode, "4481") == NULL)
    {
      cout << "no  AF_INCOMING_MSG \n<br>" << endl;
      return 13;
    }


    if (strlen(messageToDecode) < 223) // this message is not valid inverter data
    {
       cout << "message too short, returning \n<br>" << endl;
       return 15;
    }

    //shorten the message by removing everything before 4481

    tail = split(messageToDecode, "44810000"); // remove the 0000 as well
    cout << "message split after 44810000 " << tail << "\n<br>" << endl;
    //NEW VERSION of s_d generation with search string
    memset(&s_d[0], 0, sizeof(s_d)); //zero out all buffers we could work with "messageToDecode"
    delayMicroseconds(250);            //give memset a little bit of time to empty all the buffers
    strncpy(s_d, tail + 30, strlen(tail));
    delayMicroseconds(250); //give memset a little bit of time to empty all the buffers

//this i the json where we put the values;
//this meas that we need to write every value
    string invData = "{'idx':0,'time':, 'acv':,'freq':,'heath':,'dcv':[0, 0, 0, 0],'dcc':[0, 0, 0, 0],'totalenStack':,'enStack':[0, 0, 0, 0],'en':[0, 0, 0, 0],'pwr':[0,0,0,0],'totalen':0,'totalpw':0}";
    RSJresource my_resource (invData);
    my_resource["idx"] = idx; 
//cout << "json at start = " <<  invData << endl;
//      frequency ac voltage and temperature
        //float acv = ((float)((extractValue(56, 4, 1, 0, s_d) * ((float)1 / (float)1.3277)) / 4), 1);
    float acv;
    float freq;
    float heath;
    cout << "polling an invertertype: " << invType << "\n<br> " << endl;

    if (invType == 2 ) // DS3
    {
      //cout << "polling a ds3\n<br> " << endl;
      acv = roundoff( (float) (extractValue(68, 4, 1, 0, s_d) / 3.8 ), 1);
      freq = roundoff((float)(extractValue(72, 4, 1, 0, s_d)/100 ), 1);
      heath = roundoff(extractValue(96, 4, 1, 0, s_d) * 0.0198 - 23.84, 1);
    }
    else  // yc or qs
    {
       //cout << "polling a yc600 or qs1 \n<br> " << endl;
       acv = roundoff( (float)((extractValue(56, 4, 1, 0, s_d) * ((float)1 / (float)1.3277)) / 4), 1);
         
       freq = roundoff((float)50000000 / extractValue(24, 6, 1, 0, s_d), 1);
       
       heath = roundoff(extractValue(20, 4, 0.2752F, -258.7F, s_d), 1);
     }
     // catch wrong values
     if (acv < 10) acv=220;
     if(isinf(freq)) freq = 50.0;
     // write in the json
     my_resource["acv"] = forMat(acv, 1);     // write in the json
     my_resource["freq"] = forMat(freq, 1);   // write in the json
     my_resource["heath"] = forMat(heath, 1); // write in the json
     
     float dcVoltage[4] = {0,0,0,0};
     float dcCurrent[4] = {0,0,0,0};
    //     char dcc[which][5];
     cout << "processing voltage & current\n<br> " << endl;
     if(invType == 2) // ds3
     {
     dcVoltage[0] = extractValue( 56, 4, 1, 0, s_d )  / (float)48;
     dcVoltage[1] = extractValue( 52, 4, 1, 0, s_d )  / (float)48;
     dcCurrent[0] = extractValue( 60, 4, 1, 0, s_d ) * 0.0125;
     dcCurrent[1] = extractValue( 64, 4, 1, 0, s_d ) * 0.0125;
      // to do dcCurrent
     }
     else
     { // qs or yc
     //cout << "processing voltage & current\n<br> " << endl;
     // ******************  voltage   *****************************************
     //voltage ch0 offset 27
     dcVoltage[0] = (extractValue( 54, 2, (float)16, 0, s_d ) + extractValue(52, 1, 1, 0, s_d)) * (float)82.5 / (float)4096;
         
     //voltage ch1 offset 24
     dcVoltage[1] = (extractValue( 48, 2, (float)16, 0, s_d ) + extractValue(46, 1, 1, 0, s_d)) * (float)82.5 / (float)4096;
     // ******************  current   *****************************************
     //current ch0 offset 25
     dcCurrent[0] = (extractValue(53, 1, (float)256, 0, s_d) + extractValue(50, 2, 1, 0, s_d)) * (float)27.5 / (float)4096; 
     //current ch1 offset 22
     dcCurrent[1] = (extractValue(47, 1, (float)256, 0, s_d) + extractValue(44, 2, 1, 0, s_d)) * (float)27.5 / (float)4096; 
     // ********************************************************************************************
     //                                     SQ1
     // ********************************************************************************************
     if(invType == 1) //SQ1 inverter, extra 2 panels
	{
        //offset 21 -> byte for voltage ch3
        dcVoltage[2] = (extractValue( 42, 2, (float)16, 0, s_d ) + extractValue(40, 1, 1, 0, s_d)) * (float)82.5 / (float)4096;
         //offset 18 -> byte for voltage ch4
        dcVoltage[3] = (extractValue( 36, 2, (float)16, 0, s_d ) + extractValue(34, 1, 1, 0, s_d)) * (float)82.5 / (float)4096;

        // ***************************  current  *****************************************
        //offset 19 and 20 for current and status ch2
        dcCurrent[2] = ( extractValue( 41, 1, (float)256, 0, s_d ) + extractValue(38, 2, 1, 0, s_d)) * (float)27.5 / (float)4096; 
        // offset 16 and 17 for current and status ch3
        dcCurrent[3] = ( extractValue( 35, 1, (float)256, 0, s_d ) + extractValue(32, 2, 1, 0, s_d)) * (float)27.5 / (float)4096; 
        }
        //write the values to the json
      } // end else

        // now we have all the dc values an can write them in the json
      for(int y = 0; y < 4; y++)
      {  
         my_resource["dcv"][y] = forMat(dcVoltage[y], 1);
         my_resource["dcc"][y] = forMat(dcCurrent[y], 1);
      }
    
  // **********************************************************************
  //               calculation of the power per panel
  // **********************************************************************
  //we are going to save the decoded values to a json in ramdisk
  // at start of the decoding we read this file to know some old values
  // the power is calculated from the energy-increase in a timespam 

  // first we read some old values. the time and the energy/panel
  char str[1];
  sprintf(str, "%d", which);
  string ourDatafile="/ramdisk/invData" + string(str);  
  string readdata;  
//the values we need are time and the energy per panel
    if(fexists(ourDatafile))
    {
       std::ifstream t(ourDatafile);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();

       RSJresource my_inverterRead (readdata);
       cout << "json from file = " <<  my_inverterRead.as_str() << "\n<br>" <<endl;
       // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA",
       t_old = my_inverterRead["time"].as<int>();
       cout << "time from file = " << t_old << "\n<br>" << endl;

       for(int z=0; z<4; z++ ) {
          en_old[z] = my_inverterRead["en"][z].as<float>();
          enstack[z] = my_inverterRead["enStack"][z].as<float>();
          //en_old[z] = my_inverterRead["en"][z].as<float>();
       }
       
       en_old_total = my_inverterRead["totalen"].as<float>();
       enstack_total = my_inverterRead["totalenStack"].as<float>();
       cout << "en_old_total from file = " << en_old_total << "\n<br>" << endl;
       cout << "totalenStack from file = " << enstack_total << "\n<br>" << endl;

     } 
       else
     {
     // the file doesn't exist, we make all values 0;
       for(int z=0; z<4; z++ ) { en_old[z] = 0;} // 
         t_old = 0;
         en_old_total = 0;
         }
// now we know the old values and can we calculate the timespan and energy increases   

// **************************************************************
//      extract the new time offset differs yc, ds, qs
// **************************************************************

switch(invType) {
    case 0: // yc600
        t_new = extractValue(34, 4, 1, 0, s_d); // dataframe timestamp
        break;
    case 1: // qs
        t_new = extractValue(60, 4, 1, 0, s_d); // dataframe timestamp
        break;
    case 2: // ds3
        t_new = extractValue(76, 4, 1, 0, s_d); // dataframe timestamp
    }

    cout << "time from inverter " << t_new << "\n<br>" << endl;
    // write the new time value
    my_resource["time"] = t_new;
    if ( t_new > t_old ) {
    timespan = t_new - t_old;
    //  cout << "the timespan = " <<  t_new - t_old <<  "\n<br>" << endl;;
    } else {
    // if the time is lower than the former, we had a reset
    resetFlag = true;
    timespan = t_new; // timespan is equal to t_new -/- 0
    }
    cout << "the timespan = " <<  timespan <<  "\n<br>" << endl;
    // set these values for yc an qs
    int offst = 74;
    int increment = 10; // this is incremented with 10
    int btc= 6;
    // if DS3 we change these values
    if(invType == 2) { offst = 100; increment = 8; btc = 8; } // for the DS3 we have different offset/increment

    totalpw = 0;

    // for every panel of inverter which we go through this loop
    cout << "* * * * POLLED INVERTER " << which << " * * * *\n<br>";
    for(int x = 0; x < 4; x++ )
    {
    if(panels[x] == 1) { // is this panel connected ? otherwise skip
        cout << "** values panel " << x << "**\n<br>" << endl;
         // now we extract energy_new[x] 
        en_extracted[x] = extractValue(offst+x*increment, btc, 1, 0, s_d); // offset 74 todays module energy channel 0
        cout << "extracted energy_ext[x] = " << to_string(en_extracted[x]) << "\n<br>" << endl;
        //calculate the daily energy for this panel
        if(invType == 2) // DS2
        {
           en_new[x] = ((en_extracted[x] / (float)1000)/100)*1.66F;
        } else { // YC and QS
           en_new[x] = (en_extracted[x] * 8.311F / (float)3600); //[Wh]
        }

        cout << "en_new[x] = " << to_string(en_new[x]) << "  en_old[x] = " << to_string(en_old[x]) << "\n<br>" << endl;
        
        // calculate the energy increase
        // it can happen that its equal to the former poll
        // if the new energy lower than the old, there must have been a reset 
        // which means that the increase equals to en_new -/- 0
        if (resetFlag) 
        {
        // there has been a reset or start of the day
        // in this case the energy increase = new -/-/ 0 == new
        // the time restarted also but that is calculated in the time calculation
          en_increase[x] = en_new[x];
        } 
        else 
        {
          en_increase[x] = (en_new[x] - en_old[x]);
        }
        cout << "en_increase[x] = " << to_string(en_increase[x]) << "\n<br>" << endl;
        // validate the energy increase  
        if(en_increase[x] < 0 || en_increase[x] > 2500) {
        cout << "en_increase[x] invalid, ignoring this poll\n<br>" << endl;
        // what do we do now, we return 100 and ignore this poll
        return 100;
        }
        // calculation of the power
        // the same for any invertertype
        power[x] = (en_increase[x] / timespan) * (float)3600; //[W] timespan always 300 5minutes  

        totalpw += power[x]; // totalize the power for all panels
        en_new_total += en_new[x]; //totalize the daily energy
        en_inc_total += en_increase[x];
        //energy_old_total += energy_old[x]; // when this is 0 this is a first poll
        cout << "panel " << x  << "  energy to now " << en_new[x] << "\n<br>" << endl;
        }
     else
     { // end if panelConnected
        cout << "no panel " << x << "\n<br>"<< endl;
        en_new[x] = 0; //power[x]=0;
        en_increase[x] = 0;
     }
  }// end for loop
  
  
  if(resetFlag == true || en_old_total == 0) 
  { 
     // we had a situation that the new time was lower than the old
     // was the old value 0 than the invDatafile didn't exist so 
     //it was the first poll else it was a reset of the inverter
      string toLog = "<br>" + thisTime() + " polled inv " + string(str) + " ";
       
      if(en_old_total == 0) 
       {
          toLog += "1st poll after inverter start";
       }  
      else 
       {
       toLog += "inverter restarted";
       }
       cout << "toLog = " << toLog << "\n<br>" << endl;
       string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
       cout << "logCmd = " << logCmd << "\n<br>" << endl;
       system(logCmd.c_str());
    } // end if resetflag

     cout <<  "  en_new_total: " << en_new_total << "\n<br>" << endl;
     cout <<  "  en_increase_total: " << en_inc_total << "\n<br>" << endl;     
    // write the values in the json 
     for(int z=0; z<4; z++ ) 
     {
       my_resource["pwr"][z]=forMat(power[z], 1); // write in the json
       // now we write the energy values in the json
       my_resource["en"][z]=forMat(en_new[z], 1); // write in the json
       enstack[z] += en_increase[z]; 
       // enstack cannot be smaller than en_new. Can we make a check for that
       if(enstack[z] > en_new[z]) {
          my_resource["enStack"][z]=forMat(enstack[z], 1);
       } else {
          my_resource["enStack"][z]=forMat(en_new[z], 1);
       }  
     } 

    // do we use totalen for some kind of calculation? 
    // if not we could use it to stack the energy increases
    // we have enstack_total from ramdisk and add the total increase  
       enstack_total += en_inc_total;
       my_resource["totalen"] = forMat(en_new_total, 1);
       // enstack_total can never be smaller than en_new_total
       // if this is the case (could happen after reboot), we
       // set it to equal to the energy from inverter
       if (enstack_total > en_new_total) {
       my_resource["totalenStack"] = forMat(enstack_total, 1);
       } else {
       my_resource["totalenStack"] = forMat(en_new_total, 1);
       }
      // my_resource["totalen_inc"] = forMat(en_inc_total, 1);
 
       my_resource["totalpw"] = forMat(totalpw, 1);
     
     // we need the avgpw to determine sunshine or not
     int avgpw ;
     if(invType==1) {avgpw = totalpw/4;} else {avgpw = totalpw/2;}
     string cmd = "echo \"" + to_string(avgpw) + "\" > /ramdisk/avgpw.txt";
     system(cmd.c_str());
     
     //now we have all the data ready in the json,
     // we write the data in ramdisk
     string toSend = my_resource.as_str();
     string command = "echo \"" + my_resource.as_str() + "\" > \"" + ourDatafile + "\"";
     cout << command <<  "\n<br>" << endl; // prints 5
     system(command.c_str());
     // we now have a json with single quotes, we replace them with double
     // as php cant read this kind of json
     char sedCmd[130]={"sed -i 's|['AA']|'BB'|g' "};
     //add the filename
     strncat( sedCmd, ourDatafile.c_str(), strlen(ourDatafile.c_str()));
     //replace AA with \' and BB with \"
     sedCmd[12] = 92; sedCmd[13] = 39;
     sedCmd[18] = 92; sedCmd[19] = 34;
     cout << "sedCmd = " <<  sedCmd << "\n<br>" <<endl;
     system(sedCmd);

// in the database we put only the increased power value and for check the new energy

     string dbCmd = "curl -i -XPOST 'http:\/\/localhost:8086/write?db=invData' --data-binary 'inv" + to_string(which) + " p=" + forMat(totalpw, 1) + ",e=" + forMat(en_inc_total, 1) + "'";
     cout << "dbCmd = " << dbCmd << "\n<br>" << endl;
     system(dbCmd.c_str());
// for test we have a shadow database to save totalen and time       
//     string dbtestCmd = "curl -i -XPOST 'http:\/\/localhost:8086/write?db=inverterData' --data-binary 'inv" + to_string(which) + " e=" + forMat(en_new_total, 1) + ",t=" + to_string(t_new) + "'";
//     cout << "dbtestCmd = " << dbtestCmd << "\n<br>" << endl;
//     system(dbtestCmd.c_str());
     
     errorcode = 0;
     return 0;
}

// ***************************************************************
//           SEND THE POLLCOMMAND
// ***************************************************************
int sendCommands() 
{
    char sendCmd[254] = {0};
    string idInvers= "xxxxxxxxxxxx";
    string idShort= "XXXX";
    string id = "xxxxxxxxxxxx";
    string invSerial="xxxxxxxxxxxx";
    string invId="xxxx";
    string invIdrev = "xxxx";
    string readdata;

    char pollBaseCommand[][254] = 
    {
        "2401",                      //+ ..string.sub(inv_id[x],3,4)..string.sub(inv_id[x],1,2).. (inv short addr
        "1414060001000F13",          //append (concatenate) _ecu_id_reverse
        "FBFB06BB000000000000C1FEFE" // end of String
    };
    

     // now read the inverter serialnr and type and panels connected
     char str[1];
     sprintf(str, "%d", which);
     string fileToread="/var/www/ecu_data/inverters/invProperties" + string(str);
     //cout << "fileToread = " << fileToread << "\n<br>" << endl;
     if(fexists(fileToread)) 
     {
        std::ifstream t(fileToread);
        std::stringstream buffer;
     	buffer << t.rdbuf();
     	readdata=buffer.str();
     }
     	else
     {
     	cout << fileToread << " not exists\n<br>" << endl;
     	return 5;
     }
     RSJresource my_inverterRead (readdata);
     //cout << "json from file = " <<  my_inverterRead.as_str() << "\n<br>" <<endl;
     // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA",
     invId = my_inverterRead["id"].as<string>();
     //cout << "invId = " << invId << "\n<br>" << endl;
     if(invId == "unpaired") { 
     //cout << "this inverter is not paired, return\n<br>" << endl;
     return 6; }

     invSerial = my_inverterRead["serial"].as<string>();
     cout << "invSerial from file = " << invSerial << "\n<br>" << endl;
     invType = my_inverterRead["type"].as<int>();
     cout << "invType = " << invType << "\n<br>" << endl;
     idx = my_inverterRead["idx"].as<int>();
     cout << "idx = " << idx << "\n<br>" << endl;
     
     // invId has the form 0xABCD so we skip the 0x
     invIdrev = invId.substr(4,2) + invId.substr(2,2); // inverter id inversed
     cout << "invIdrev = " << invIdrev << "\n<br>" << endl;
    // sort is id 2 and 1 is BBAA
     idShort = idInvers.substr(8, 4);
     cout << "idShort  = " << idShort << "\n<br>" << endl;


    // construct the commands, we need more data
    // the serial of the inverter and the id, the ecu id invers
    // we read this from file
    fileToread="/var/www/ecu_data/ecuProperties";
    //cout << "fileToread = " << fileToread << "\n<br>" << endl;
    if(fexists(fileToread))
    {
       std::ifstream t(fileToread);
       std::stringstream buffer;
       buffer << t.rdbuf();
       readdata=buffer.str();
    }
    else
    {
    //cout << fileToread << " not exists\n<br>" << endl;
    return 7;
    }
     RSJresource my_ecuRead (readdata);
     //cout << "json from file = " <<  my_ecuRead.as_str() << "\n<br>" <<endl;
     // is like this{"id":"AABBCCDD1122","idinvers":"2211DDCCBBAA","idshort":"B$
     id = my_ecuRead["id"].as<string>();
     idInvers = my_ecuRead["idinvers"].as<string>();
     cout << "idinvers from file = " << idInvers << "\n<br>" << endl;


     for(int z=0; z<4; z++) {panels[z] = my_inverterRead["panels"][z].as<int>();} 

      //construct command 1
   strncpy(sendCmd, pollBaseCommand[0], strlen(pollBaseCommand[0])); // the 2401
   strncat(sendCmd, invIdrev.c_str(), 5);
   strncat(sendCmd, pollBaseCommand[1], strlen(pollBaseCommand[1]) );
   strncat(sendCmd, idInvers.c_str(), 13);
   strncat(sendCmd, pollBaseCommand[2], strlen(pollBaseCommand[2]) );
   // calculate and add len and crc
   strcpy(sendCmd, strncat(sLen(sendCmd), sendCmd, sizeof(sLen(sendCmd)) + sizeof(sendCmd)));
   strcpy(sendCmd, strncat(sendCmd, checkSum(sendCmd), sizeof(sendCmd) + sizeof(checkSum(sendCmd))));
   // the command is ready
   cout << "poll cmd = " << sendCmd << "\n<br>" << endl;
   sendZigbee(sendCmd); // sends t
   waitSerialAvailable(); 
    //  return false; 
   
   // if there was nothing to read we returned
   // so there is data available
   readZigbee();
   int result;
   if(readCounter > 0){
   cout <<" answer = " << inMessage << "\n<br>" << endl; 
   result = decodePollAnswer();
   // this can give all kinds of values
      
   } 
      else 
   {
      cout << "no answer\n<br>" << endl;
   }
   cout << "all cmds sent\n<br>" << endl;
   
   // result 1 = first time polles 
   if (result != 0) { 
   //errorcode = result;
   return result; } else { 
   //errorcode = 0;
   return 0;
   }  
}
// ***********************************************************
//                     M A I N 
// ***********************************************************

int main ( int argc, char **argv)
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<head>\n";
   cout << "<title>RPI ECU PROGRAM</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<h4>running inverterPoll.cgi</h4>\n";

// we need an argument to know which inverter to poll
string what;
//   int which;
   if(argc > 1)
   {
       using std::atoi;
       which =atoi(argv[1]);
       what = string(argv[1]);
       //cout << "there is an argument: which = " << which << "<br>" << endl;
    } else {
       cout << "error: no inverternumber supplied \n<br>";
       return(3);
    }
    if( which > 8)
    {
      cout << "error: invalid inverternumber supplied \n<br>";
      return (4);
    }
     cout << "inverterpoll running with arg "<< which << "\n<br>" << endl;


   if (wiringPiSetup () == -1) /* initializes wiringPi setup */
   {
      
      cout << "unable to start wiringPi \n<br>" << endl;
      return 1;  
   }
    

    //int serial_port;
    if ((fd = serialOpen ("/dev/serial0", 115200)) < 0)
    {
      cout << "unable to open serial_port serial0\n<br>" << endl;
      //if ((fd = serialOpen ("/dev/ttyAMA0", 115200)) < 0)
      //   {
      //   cout << "unable to open serial_port ttyAMA0\n<br>" << endl;
      return(1);
          
     } 


//  if ((fd = serialOpen("/dev/ttyS0", 115200)) < 0)
//  {
//    cout << "unable to open serial_port \n<br>" << endl;
//    return 1;
//  }


// loop
errorcode = sendCommands();
cout << "returned by sendCommands() " << errorcode << "\n<br>" << endl;
// prepare the logging
//    time_t noow = time(nullptr);
//    tm * ptm = localtime(&noow);
//    char buffer[32];
    //strftime(buffer, 32, "%a, %d.%m.%Y %H:%M:%S", ptm);
//    strftime(buffer, 32, "%H:%M:%S", ptm);
    //cout << buffer;
//    string ts;
//    ts += buffer;

string toLog = "<br>" + thisTime() + " polled inv " + what + " ";


if (errorcode == 0) {
  serialClose(fd);
  cout << "inverterpoll exit with code 0\n<br>" << endl;
// we log the total power
  toLog += "ts: " + forMat(timespan, 0) + " pw: " + forMat(totalpw, 1);
  cout << "toLog = " << toLog << "\n<br>" << endl;
  string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
  cout << "logCmd = " << logCmd << "\n<br>" << endl;
  system(logCmd.c_str());
  return 0;
  // we can mqtt and no log
  }

// if the inverter was polled earlyer but now failed, we stil have to mqtt the null values


  switch(errorcode) {
  case 5:
      toLog += "error 5 no inverterfile";
      break;
  case 6:
      toLog += "error 6 inverter not paired";
      break;
  case 7:
      toLog += "error 7 no ecu settings file";
      break;
  case 10:
      toLog += "error 10 AF_DATA_REQ fail";
      break;
  case 11:
      toLog += "error 11 AF_DATA_CONFIRM fail";
      break;
  case 13:
      toLog += "error 10 AF_INCOMING_MSG fail";
      break;
  case 15:
      toLog += "error 15 message too short";
      break;
  case 100:
      toLog += "error 100 invalid energy value";
      break;

//  case 1:
//      toLog += "error 1 energy lower than former poll";
//      break;
//  case 2:
//      toLog += "error 2 first poll is ignored.";
//      break;
  }

  cout << "toLog = " << toLog << "\n<br>" << endl;
  string logCmd ="echo \"" + toLog + "\" >> /ramdisk/ecu_log.txt";
  cout << "logCmd = " << logCmd << "\n<br>" << endl;
  system(logCmd.c_str()); 

  serialClose(fd);
  // if we are here the polling failed
  // we should make all the values 0 in the invDatafile
  // except for the energy values
  // in which cases we  dont have to make the file 0
  // not if not paired not if no ecu or inverter files 5 6 7
  // determined by the returnstatements in the switch
if ( errorcode == 5 || errorcode == 6 || errorcode == 7 ) { 
cout << "inverterpoll exit (without resetting files) with code 1\n<br>" << endl;
return 1;
}

 // in case of other errors the inverter exists and is polled unsuccessfully. 
 // we reset the values to null
 // and we have to mqtt them so we return 0


 // with this nullcmd all values are reset to null except energy
 string nullCmd ="/usr/lib/cgi-bin/ecu/invdataNull.cgi " + what;
 system(nullCmd.c_str());
//to simulate another inverter
/*
 string testwhat = "3";
 string testnullCmd ="/usr/lib/cgi-bin/ecu/invdataNull.cgi " + testwhat;
 system(testnullCmd.c_str());
*/
     cout << "inverterpoll exit with code 0\n<br>" << endl;
     return 0;

}

 


