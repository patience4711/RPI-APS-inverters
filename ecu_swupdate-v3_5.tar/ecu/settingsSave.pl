#!/usr/bin/perl

use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";
print "<body><span style='font-size:12px; font-family: arial;'>";
# test = ecuid=AABBCCDD1122 lati=51.432 long=5.476 offs=30

my $query = new CGI;
my $ecu_id = $query->param('ecuid');
my $long = $query->param('long');
my $lati = $query->param('lati');
my $offset = $query->param('offs');
my $price = $query->param('ep');
my $cur = $query->param('cur');

#print "the received in settings.pl commando is:\n ";
#print "$ecu_id $long $lati $ap <br>\n";
#we are going to save as json in settings.txt

my $json1 = qq{'{"id":"$ecu_id","longitude":$long,"latitude":$lati,"offset":$offset,"price":$price}'};

my $filename = '/var/www/ecu_data/settings.json';

my $savecmd = "echo $json1 > $filename";
print("savecmd = $savecmd \n<br>");
system($savecmd);

$filename = '/var/www/ecu_data/currency.txt';
my $saveCurcmd="echo '$cur' > $filename";
system($saveCurcmd);

#my $aps = 0;
#if( $ap eq "on") {
#$aps = 1;
#}

#$filename = '/var/www/ecu_data/autopoll.txt';
#my $savepolcmd="echo '$aps' > $filename";
#system($savepolcmd);

# invert ecuid, calculate short and save
my $invers="xxxxxxxxxxxx";
my $idshort="xxxx";
#line 40
my@a = (0,2,4,6,8,10);
my$b = 0;
my$tmp = "";
# ecuid = 12 characters aabbccdd1122
# if ecuid = 0 and 1, inverted = 10 and 11  
for(@a){
$tmp = substr $ecu_id, $_, 2; #
#line 50
#print "tmp = : $tmp \n";
$b=10-$_;
substr($invers, $b, 2) = $tmp; 
}

#ecu_id.substring(2,4) + ecu_id.substring(0,2) with D6A3011B9780 this would be A3D6
# with reversed 80971b01A3D6 this would be substr idreversed 7,4
my $jsonfile = "/var/www/ecu_data/ecuProperties"; 

my $json = qq{'{"id":"$ecu_id","idinvers":"$invers"}'};

#print("contents = $json \n");
my $savecommand = "echo $json > $jsonfile";
print("savecommand = $savecommand \n<br>");
system($savecommand);

# we write in the log
$filename = '/ramdisk/ecu_log.txt';
my $savelogcmd="echo '<br>settings saved' >> $filename";
system($savelogcmd);

#if the settings have changed we must run sun.py
print ("running sun.py");
my $sunCmd="python /usr/lib/cgi-bin/ecu/sun.py";
system($sunCmd);

print "\nfile settings saved<br>\n<br>";
print "HTTP/1.1 200 OK";

