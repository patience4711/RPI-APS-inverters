#!/usr/bin/perl
use strict;
use warnings;

use CGI;
print CGI::header();
print "";
print "<html>";
print "<head>";

print "</head>";

print "<body><span style='font-size:12px; font-family: arial;'>";

#print "<br><br>running script install.pl...<br>\n";
$| = 1;

print "\n\n<br>***********************************************";
print "\n<br>   running script install.pl";
print "\n<br>***********************************************";
print "\n\n<br>   upgrading to a new softwareversion check below \n\n<br>";

# this script runs from the directory /var/www/swupdate/files/install.pl
# this is where the tar is unzipped 

my $filename="";
my $testrun = 0;
# 0
print "\n<br>going to copy several files to their relative directories\n<br>";
# we must replace the file sudoers
$filename = "sudoers";
if (-e $filename) {
  my $cpSudo = "sudo cp $filename /etc/";
  print "\n<br>cpSudo = $cpSudo \n<br>";
  print "copying sudoers /etc \n<br>";
  if($testrun == 0) { system ($cpSudo);} else { print" testrun\n<br>"; }

} else { print "\n<br>file $filename not exists"; }

# **********************************************************
#     replace /var/www/html and /usr/lib/cgi-bin/ecu
# **********************************************************
# to be able to exclude pics in the rm and cp actions
# we need to do this with an sh script
# we call this as sudo, permission is set in sudoers
# call replace.sh
my $comR = "sudo /var/www/swupdate/files/replace.sh";
print"<br>calling $comR as sudo ..";
#system($comR);
if($testrun == 0) { system ($comR);} else { print" testrun\n<br>"; }

# ***************************************************************
#               restore the file permissions
# ***************************************************************
# now we have replaced all html and cgi-bin scripts
# when we tar a dir the owners/privileges get changed, we should correct that
#we have a separate script for that
# now we look for the script install.pl in files
if(-e "setPermissions.sh") {
# must we make this script executable ? no
# then we execute the script.
print "\n\n<br>calling the setPermissions script as sudo";
my $permissionCmd = "sudo /var/www/swupdate/files/setPermissions.sh";
  if($testrun == 0) { system ($permissionCmd);} else { print" testrun\n<br>"; }
} else {
print "\n<br>setPermissions.sh not found";
}

# ***************************************************************
#                    update version number
# ***************************************************************
my $versionCmd = "echo 'RPI-ECU-v3_5' > /var/www/ecu_data/swVersion.txt";
print "\n<br>versionCmd = $versionCmd \n<br>";
system ($versionCmd);
  if($testrun == 0) { system ($versionCmd);} else { print" testrun\n<br>"; }


print "\n\n\n install software upgrade ready\n<br>";
print "HTTP:1/1 200 OK";

