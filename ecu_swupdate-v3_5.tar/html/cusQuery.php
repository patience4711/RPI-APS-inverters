<?php
/*
this page queries the values from invEnergy invx per month
also queries the last entry of energy in invData invx when
the query is over the currnt month
If that value != null we add it to the first query
so that we have a value for the present day.
At midnight the value in invData is copied to invEnergy
and the value in inv is set to null.
*/

//globally defined vars
$errortxt = "";
$error = "";

//we start with reading the dates and inv nr
$file="/var/www/ecu_data/customQdate.txt";
if(file_exists($file)){
$fp = fopen($file, 'r');
$beginDate = fgets($fp);
$endDate = fgets($fp);
$invnr = fgets($fp);
fclose($fp);
} 

// we read the file invChoice.txt
$invnr = file_get_contents("/ramdisk/invChoice.txt");
//echo "query inverter: " . $invnr;
$from = "inv". $invnr;

require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";

//get connection
$client = new InfluxDB\Client($host, $port);
$database = $client->selectDB('invEnergy');

// are there values for this inverter?
$query="SELECT e FROM {$from}";
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
$lengte= strlen($points);
if($lengte < 10) {
$error = "invalid";
$errortxt = "no data for this inverter";
}

/*
check if there are values in the chosen dates
*/

$begin = new DateTime("$beginDate");
$end = new DateTime("$endDate");
// is begin < end else error
if($end < $begin){
$error = "invalid";
$errortxt = "Error: wrong period definition. \n<br>Begindate later than enddate?";
}

//$begin->modify("-1 day");
$beginS = $begin->format("Y-m-d H:i:s");
//echo "\n<br>beginS = " . $beginS;

//$begin = new DateTime("$beginDate");
$begin->modify("+1 day");
$beginE = $begin->format("Y-m-d");
//echo "\n<br>beginE = " . $beginE;

// 
$query="SELECT e FROM {$from} where time > '{$beginS}' and time < '{$beginE}'";
//echo"\n\n<br><br> query = " . $query;
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
//echo $points;
$lengte= strlen($points);
if($lengte > 10) {$beginHasValue = true;}

//echo "lengte op begindatum = " . $lengte;

$endS = $end->format("Y-m-d H:i:s");

$end->modify("+1 day");
$endE = $end->format("Y-m-d");

// 
$query="SELECT e FROM {$from} where time > '{$endS}' and time < '{$endE}'";
//echo"\n\n<br><br> query = " . $query;
$result=$database->query($query);
$points = $result->getPoints();
$points = json_encode($points);
//echo $points;
$lengte= strlen($points);
if($lengte > 10) {$endHasValue= true;}
//echo "lengte op einddatum = " . $lengte;

if( !$beginHasValue or !$endHasValue or $beginDate > $endDate) {
$error = "invalid";
$errortxt = "Error: no value in some dates.\n<br>Did you select the present day or an invalid starting day?";
goto Panic;
} 
else 
{
//echo "values on both dates";
/*
what do we want to query
mode average spread min max count median
*/
// the average
$query="SELECT mean(e), sum(e), spread(e), median(e), mode(e), count(e) FROM {$from} where time > '{$beginS}' and time < '{$endE}'";
//echo"\n\n<br><br> query = " . $query;

$result=$database->query($query);
//$points = $result->getPoints();
$punten = $result->getPoints();
//$points = json_encode($punten);
//echo $points;

$mean = $punten[0]["mean"];
$sum = $punten[0]["sum"];
$spread = $punten[0]["spread"];
$median = $punten[0]["median"];
$mode = $punten[0]["mode"];
$cnt = $punten[0]["count"];
//echo "mean = " . $mean;
//echo "cnt = " . $cnt;

// now we do a query from invData
//get connection
//$client = new InfluxDB\Client($host, $port);
$database = $client->selectDB('invData');

$query="SELECT mean(p), spread(p), median(p), mode(p) FROM {$from} where time > '{$beginS}' and time < '{$endE}'";
//echo"\n\n<br><br> query = " . $query;
$result=$database->query($query);
//$points = $result->getPoints();
$punten = $result->getPoints();
$meanP = $punten[0]["mean"];

// ******* select highest value*****************
$query="SELECT max(p) FROM {$from} where time > '{$beginS}' and time < '{$endE}'";
$result=$database->query($query);
$punten= $result->getPoints();
//$points = json_encode($points);
//$punten = json_decode($points, true);
$maxP = $punten[0]["max"];
$whenhigh = substr($punten[0]["time"], 0, 10);

$query="SELECT max(mean) from (select mean(p) FROM {$from} where time > '{$beginS}' and time < '{$endE}' group by time(1d) )";
//echo $query;
$result=$database->query($query);
$punten= $result->getPoints();
$maxavgP = $punten[0]["max"];
$whenhighavg = substr($punten[0]["time"], 0, 10);


$query="SELECT min(mean) from (select mean(p) FROM {$from} where time > '{$beginS}' and time < '{$endE}' group by time(1d) )";
//echo $query;
$result=$database->query($query);
$punten= $result->getPoints();
$minavgP = $punten[0]["min"];
$whenlowavg = substr($punten[0]["time"], 0, 10);

}

Panic:
// check if an error ocurred
if ( $error == "invalid") {
echo "i paniced !<br>";
echo $errortxt . "<br>";
}


?>

