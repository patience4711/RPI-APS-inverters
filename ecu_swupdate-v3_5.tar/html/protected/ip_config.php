<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=0.78' />
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />

<style>
.inp7 {
    font-size:24px; 
    }
.inp1 {
    font-size:20px;
    width: 156px; 
    }

.knop {
  font-size: 12px;
  height: 30px; 
  background-color:#330066; 
  color:#99ffff; 
  padding: 5px 8px; 
  border-radius:8px;
  }
table{margin-left:50px}
table, th {text-align: center;}

td {
position: relative;
}
.switch {
  position: relative;
  display: inline-block;
  width: 120px;
  height: 46px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: " dhcp";
  height: 36px;
  width: 52px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(52px);
  -ms-transform: translateX(52px);
  transform: translateX(52px);
  content: "static";
}
.floatingDiv {
position:absolute;  
z-index:10000;
left:5%;
top:250px;
width:33%;
background-color:#FFF;
min-width:217px;
text-align: left;
border-radius: 10px 10px;
border:solid;
border-width:1px;
border-color:#000;
vertical-align:top;
padding:10px;

background-image: -ms-linear-gradient(top, #CCCCCC 0%, #FFFFFF 25px, #FFFFFF 100%);
background-image: -moz-linear-gradient(top, #CCCCCC 0%, #FFFFFF 25px, #FFFFFF 100%);
background-image: -o-linear-gradient(top, #CCCCCC 0%, #FFFFFF 25px, #FFFFFF 100%);
background-image: -webkit-linear-gradient(top, #CCCCCC 0%, #FFFFFF 25px, #FFFFFF 100%);
background-image: linear-gradient(to bottom, #CCCCCC 0%, #FFFFFF 25px, #FFFFFF 100%);

box-shadow:3px 3px 5px #003; 
filter: progid:DXImageTransform.Microsoft.Shadow(color='#000033', Direction=145, Strength=3);
}

</style>
<script type='text/javascript'>
    
function test() {
//alert("test");
if(document.getElementById("sw").checked){
document.getElementById('myDiv').innerHTML = "<h4>setup static ip address</h4><form method='post' id='staticForm' onsubmit='zendStatic()' target='hiddenFrame'><?php $file = fopen("/var/www/ecu_data/myipnr.txt","r");
$localip = rtrim(fgets($file));
fclose($file);
$gateway = substr($localip, 0, strrpos($localip, "."));
$gateway .= ".1";
echo"<table><tr><td>ip router <td><input name='gw' id='gw' required pattern='^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$' class='inp1' title='192.168.x.x (niet over 254)' value='" . $gateway . "'>";?><tr><td>static ip<td><input name='ip' id='ip' required pattern='^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$' class='inp1' title='192.168.x.x (niet groter dan 254)'><tr><td>netmask<td><input name='nm' id='nm' required pattern='^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$' value='255.255.255.0' class='inp1' title='192.168.x.x (not over 255)'></table><br> <button class='knop'>SAVE</button></form>";
} 
else {
document.getElementById('myDiv').innerHTML = "<form method='post' id='dhcpForm' target='hiddenFrame' onsubmit='zendDhcp()'><h4>setup dhcp</h4><button class='knop'>SAVE</button> </form>";
}
}

function zendStatic() {
//als we hier komen dan heeft submit al plaatsgevonden met verificatie van de input
//dus nu moet het script aangeroepen worden met de formulier argumenten.
var gateway = document.getElementById("gw").value;
var adres = document.getElementById("ip").value;
var netmask = document.getElementById("nm").value;
//alert( gateway);
//alert( adres + gateway + netmask);
//alert( netmask);
//we bevolken nu het verborgen formulier met deze waardes
document.getElementById("formulier_gw").value = gateway;
document.getElementById("formulier_ip").value = adres;
document.getElementById("formulier_nm").value = netmask;

if(confirm('setup static ip, are you sure?')){
   document.getElementById('formulier').submit();
   myMsgBox("the date is sent, this page closes after some seconds");
   setTimeout(function(){ window.location = "/index.php"; }, 50000); 
} else {
     alert("setup static ip canceled"); 
     return false;  
}
}

function zendDhcp() {

	if(confirm('setup dhcp, are you sure?')) {
	myMsgBox("the date is sent, the device is going to restart.\r\n Close this page after some seconds");
	//document.getElementById('form_dhcp').submit();
	setTimeout(function(){ window.location = "/index.php"; }, 5000); 
	} else {
     alert("dhcp setup canceled"); 
     return false;  
	}
}

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}


</script>
  
</head>
<body>
<div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>IP CONFIG HELP</h3>
  <b>IP ADDRESS:</b><br>
  With the ip-address you can find your device in your network.
  <br><br><b>DHCP</b><br>The router determines the ip address.
  <br><br><b>STATIC</b><br>
  The ip address is defined by you. Usually this is not needed<br>because the router always handsout the same ip address to a certain device.
   <br><br>
<b>SUBMIT</b><br>
If you changed the settings and clicked 'save', the device is going to reboot.<br>
This may take a while.<br>
You can find your device by typing <strong>http://rpiecu.local </strong> in your browser.

</div>

<div id='msect'>
<kop>  HANSIART RPI ECU </KOP>
</div>

<div id='msect'>
<ul>
<li><a href='#' onclick='helpfunctie()'>help</a></li>
<li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

</ul><br>
</div>
<div id='msect'>
<div class='divstijl' style='width:430px; font-size:16px;'>
<center>
<h4>SETUP STATIC / DYNAMIC IP-ADDRESS</h4>
<span style='font-size:12px; color:green;'>Tip: click on "help".<br>
</span><br><br>
<?php
$file = fopen("/var/www/ecu_data/wifistatus.txt","r");
$status = rtrim(fgets($file));
fclose($file);
if ($status == 'static') {
$chk = checked;
} else {
$chk = "";
}

echo "<table><tr>";
echo "<td>DHCP<td><label class='switch' onchange='test()'>";
echo "<input type='checkbox' id='sw'" . $chk . "><span class='slider'></span>";
?>
</label><td>STATIC</td></tr></table><br>

<div id='myDiv' style='border: solid 1px;'>
<form method='post' id='dhcpForm' target='hiddenFrame' onsubmit='zendDhcp()'><h4>setup dhcp</h4><button class='knop'>SAVE</button> </form>
</div>
<br>
<div class="floatingDiv" id="msgBox" style="visibility:hidden"></div>


<?php
$file = fopen("/var/www/ecu_data/debugstatus.txt","r");
$status = rtrim(fgets($file));
fclose($file);
if ($status == 'on') {

echo "<iframe name='hiddenFrame' width='420' height='50'></iframe>";
} else {
echo"<iframe name='hiddenFrame' width='20' height='50'hidden></iframe>";
}
?>


<script>
function openWindow(id){
"use strict";
document.getElementById(id).style.visibility = 'visible'; 
}
function closeWindow(id){
"use strict";
document.getElementById(id).style.visibility = 'hidden'; 
}

function myMsgBox(TITLE,MESSAGE) {
"use strict";   
document.getElementById("msgBox").innerHTML = "<h2 style=\"text-align:center; margin-top:0px;\">" + TITLE + "</h2>";
openWindow("msgBox");
}
</script>

<form method="post" action='/cgi-bin/ecu/wifi_static.pl' id='formulier' style='display: none;'>
<input name='gw' id='formulier_gw'>
<input name='ip' id='formulier_ip'>
<input name='nm' id='formulier_nm'>
</form>

<form method="post" action='/cgi-bin/ecu/wifi_dhcp.pl' id='form_dhcp' style='display: none;'>
</form>

 </body>
 </html> 


