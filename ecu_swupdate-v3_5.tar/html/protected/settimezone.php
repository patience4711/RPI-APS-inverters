<html>
<head>
<meta name='viewport' content='width=device-width, initial-scale=0.78' />
<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<style>
.knop {
  font-size: 22px;
  height: 50px; 
  background-color:#330066; 
  color:#99ffff; 
  padding: 5px 8px; 
  border-radius:8px;
  }
.inp1 {
width: 360px;
font-size: 22px;
font-weight: 500;
box-sizing: border-box;
display: block;
color: #444;
padding: .6em 1.4em .5em .8em;
border: 1px solid #aaa;
box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
border-radius: .5em;

}
.select-css {
    display: block;
    font-size: 22px;
    font-family: sans-serif;
    font-weight: 500;
    color: #444;
    line-height: 1.3;
    padding: .6em 1.4em .5em .8em;
    width: 360px
    box-sizing: border-box;
    margin: 0;
    border: 1px solid #aaa;
    box-shadow: 0 1px 0 1px rgba(0,0,0,.04);
    border-radius: .5em;
    -moz-appearance: none;
    -webkit-appearance: none;
    appearance: none;
    background-color: #fff;
}
.select-css::-ms-expand {
    display: none;
}
.select-css:hover {
    border-color: #888;
}
.select-css:focus {
    border-color: #aaa;
    box-shadow: 0 0 1px 3px rgba(59, 153, 252, .7);
    box-shadow: 0 0 0 3px -moz-mac-focusring;
    color: #222; 
    outline: none;
}
.select-css option {
    font-weight:bold;
}

</style>

<script type='text/javascript'>
 
function selectSubmit() {
spinner();
checkReaction();
document.getElementById('tijdZselect').submit();
}

function inputSubmit() {
if(confirm('change timezone, are you sure about the syntax???')) {
alertbox();
document.getElementById('tijdZinput').submit();
}
else {
     alert("new timezone cancelled"); 
     return false; } 
}


function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}



function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
     hideLoader();
     //document.getElementById("formdiv").style.display="none";
    //document.getElementById("rebootdiv").style.display="block";
    setTimeout( function() { location.reload(); }, 1000);
  }
}


function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

</script>

</head>
<body>
<div id='msect'>
  <div id='bo'></div>
  <div id='help'>
  <span class='close' onclick='sl();'>&times;</span><h3>TIMEZONE HELP</h3>
  <b>timezone:</b><br>
  You can see what the current timezone is. For Europe many of these options don't make any difference, Amsterdam and Berlin have the same time. So if your systemtime is correct then you don't have to bother. 
 
<br><br>
<b>change the timezone</b><br>
Choose a timezone in the list. You can now see that the desired timezone has changed into the timezone you entered. You should reboot to effectuate the new timezone.
<br><br><b>incourant timezone</b><br>
If your timezone is not in the list, you can enter a timezone yourself.<br>Make sure that the correct data is entered otherwise this won't work! A correct syntax is something like 'America/Argentina/Cordoba' or 'Europe/Berlin'.<br>You can find these timezones on 'https://en.wikipedia.org/wiki/List_of_tz_database_time_zones'
<br>Reboot to effectuate.
<br><br>
  </div>
</div>


<div id='msect'>
<ul>
<!--<li><a href='/index.php'>home</a></li>-->
<li><a href='#' onclick='helpfunctie()'>help</a></li>
<li><a href='info.php'>info</a></li>
<li><a href='systemcmds.php'>reboot</a></li>
<li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

</ul>
</div>
<br>
<div id='msect'><center>
<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>
</div>
</div>
<div id='msect'>
<div class='divstijl' style='width:460px; font-size:16px;'>
<center>

<h4>
<?php
$file = fopen("/var/www/ecu_data/timezone.txt","r");
     $ltz = fgets($file);
     fclose($file);
$realtz = substr($ltz, 9);
echo "current timezone = " . $realtz . "<br>";
// timezone_temp contains what is entered via this page
$file = fopen("/var/www/ecu_data/timezone_temp.txt","r");
     $tz = fgets($file);
     fclose($file);
echo "desired timezone = " . $tz ."<br>";
//if($realtz === $tz){ echo "they are equal";} else {echo "not equal";}
if (strpos($tz, "error") === false && strpos($tz, "nothing") === false && $realtz != $tz ) {
   echo "<br><marquee style='width:380px; color:green;'>reboot to effectuate " . $tz ." !</marquee>";
   } else {
      if (strpos($tz, "error") !== false ) { 
        echo "<br><span style='color:red;'>please try again</span>";
      } else {
    echo "<br><span style='color:red;'>please enter a timezone</span>";
      }
    
   } 
 
?></h4>

<form id="tijdZselect" method="post" action="/cgi-bin/ecu/system/timeset.pl" target='hiddenFrame'>
<select name="tz" onchange='selectSubmit()' class='select-css' >
<option disabled selected>choose from this list</option>
<option value="Africa/Johannesburg">Africa/Johannesburg</option>
<option value="Africa/Casablanca">Africa/Casablanca</option>
<option value="America/Aruba">America/Aruba</option>
<option value="America/Barbedos">America/Barbedos</option>
<option value="America/Argentina/Buenos_Aires">America/Argentina/Buenos_Aires</option>

<option value="America/Chicago">America/Chicago</option>
<option value="America/Los_Angeles">America/Los_Angeles</option>                
<option value="America/New_York">America/New_York</option>
<option value="America/Vancouver">America/Vancouver</option>

<option value="Asia/Baghdad">Asia/Baghdad</option>
<option value="Asia/Bangkok">Asia/Bangkok</option>
<option value="Asia/Calcutta">Asia/Calcutta</option>
<option value="Asia/Dubai">Asia/Dubai</option>
<option value="Asia/Pyongyang">Asia/Pyongyang</option>
<option value="Asia/Saigon">Asia/Saigon</option>
<option value="Asia/Tokyo">Asia/Tokyo</option>

<option value="Australia/Adelaide">Australia/Adelaide</option>
<option value="Australia/Brisbane">Australia/Brisbane</option>
<option value="Australia/Melbourne">Australia/Melbourne</option>
<option value="Australia/West">Australia/West</option>

<option value="Europe/Amsterdam">Europe/Amsterdam</option>
<option value="Europe/Athens">Europe/Athens</option>        
<option value="Europe/Berlin">Europe/Berlin</option>
<option value="Europe/London">Europe/London</option>
<option value="Europe/Helsinki">Europe/Helsinki</option>    
<option value="Europe/Kiev">Europe/Kiev</option>
<option value="Europe/Lisbon">Europe/Lisbon</option>
<option value="Europe/Moscow">Europe/Moscow</option>        
</select>            
</form>

 alternative when your timezone is not in the list:
<form style="border:solid 1px; width:90%;" id="tijdZinput" method="post" action="/cgi-bin/ecu/system/timeset.pl" target='hiddenFrame'>
<input name="tz" class='inp1' type='text'>

<br><button class='knop' type='button' onclick='inputSubmit()' >SAVE</button></td>
</form>

<span style='color: green; font-size: 12px;' class="groen">
Tip: Click help.</span><br>


<br>
<iframe name='hiddenFrame' width='420' height='100'></iframe>
</div>

<br><br>
<br><br>


 </body>
 </html> 


