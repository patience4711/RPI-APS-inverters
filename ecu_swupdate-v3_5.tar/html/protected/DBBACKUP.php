<!DOCTYPE html><html><head><meta charset='utf-8'>

<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<META HTTP-EQUIV="Content-Disposition" CONTENT="inline" />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">

<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}

function dl(file) {
var link = "../backups/" + file;
var lank = "../backups/" + file;
window.location.href=(lank);
setTimeout(function () {window.location.href="zanks.html";}, 5000);
}


function backupsubmit() {

        if(!confirm("ECU BACKUP: all inverter settings and databases will be backed up ! ! ! Are you sure you want this?"))
       {
          //location.reload() 
          return false;
       }
          // make the backupbutton invisible
    document.getElementById("backbut").style.display="none";
    
    spinner();
    checkReaction();   
    document.getElementById("backform").submit();
    
} 

</script>
</head>
<body>

<div id='msect'>
<div id='bo'></div>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>BACKUP / RESTORE HELP</h3>
  <b>PURPOSE:</b><br>
  With this tool you can backup all the settings and databases. <br>
<br><b>WHY:</b><br>
If there is a new softwareversion, you have to install a new sd-card image. <br>This means that you will lose all of your settings and data.<br><br>
<b>WHEN</b>
<br>If you install new software, it is best to do this during darkness, because there in no activity in the ECU.<br>Just before upgrading you make a backup of your settings first. <br><br>

<b>BACKUP:</b><br>Click the backup button. Now a file is made and a downloadbutton will reveal. Click this and after a moment you can find the file in the map 'downloads' of your computer. Store this file in a save place. Don't rename the file.<br>
<br><br>
</div>
</div>
 

<div id='msect'>
    <div id='bo'></div>
    <ul>
    <!--<li><a href='menu.html'>done</a></li>-->
    <li><a href='#' onclick='helpfunctie()'>help</a></li>
 <li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

    </ul>
 </div>

 <div id='msect'>
   <kop>ECU DATABASE BACKUP</kop>
 </div>

<div id='msect'>
<div class='divstijl' style='height:44vh; width: 54vw'>
<center>
<div style='border:1px solid'>
<div id='warn'></div>
<div id='backbut'>
<h3>compose a backupfile</h3>

<!-- 
 **********************************************************
 *                         backform                       *
 ********************************************************** 
-->

<form id='backform' action='/cgi-bin/ecu/dbBackup.pl' target='hiddenFrame'></form>
<button class= 'butt' onclick = 'backupsubmit()'>BACKUP</button>
<br><br>
</div>

<div id ="dldiv" style='visibility:hidden'>
Now you can download the backupfile ecu_backup.tar<br>
if this failes check your browser settings.<br><br>

<?php
// the file to download = date + filename
$bestand = date("Ymd") . "-ecu_backup.tar";

echo "<button type='button' class='butt' onclick='dl(\"" . $bestand . " \")'>Download " . $bestand . "</button>";

?>
</div></div><br><br>
<div id='msect'><center>

<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>
</div>

<iframe name='hiddenFrame' width='100%' height='150'></iframe>  

<script>
function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
//setTimeout( function() { hideLoader(); }, 1000);
}

function checkReaction() {
//console.log("a = " + a);
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
     hideLoader();
     document.getElementById("dldiv").style.visibility="visible";
  }
}

</script>
<iframe id="my_iframe" style="display:none;"></iframe>
<script>

function Download(url) {
alert("do you want to download " . url);
    document.getElementById('my_iframe').src = url;
    //setTimeout(function () {window.location.href="menu.html";}, 5000);
};
</script>
</body></html>