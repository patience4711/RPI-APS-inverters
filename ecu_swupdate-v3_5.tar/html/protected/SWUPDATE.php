<!DOCTYPE html><html><head><meta charset='utf-8'>

<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<META HTTP-EQUIV="Content-Disposition" CONTENT="inline" />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}


function restsubmit() {
          spinner();
          checkulReaction();   
          document.getElementById("updateForm").submit();
   } 

function installsubmit() {
        if(!confirm("install the software upgrade ! Are you sure?"))
       { 
          return false;
       }
          window.frames[0].document.body.innerHTML = ""; 
          spinner();
          checkinstallReaction();   
          document.getElementById("installform").submit();
   } 

function dummy(){
var q = 10;
 // do nothing
}
function readyfunction(){
window.location.href = "menu.html";
}
</script>
<style>
.inputfile {
	width: 0.1px;
	height: 0.1px;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
}
.lbl {
border:3px solid black;
font-size:20px;
padding: 4px;
color: blue;
background-color:lightgrey;
border-radius: 8px;}
label:hover {
    background-color:red;
}</style>

</head>
<body>
 <div id='msect'>
<div id='bo'></div>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>SOFTWARE UPGRADE HELP</h3>
  <b>PURPOSE:</b><br>
  With this tool you can install software upgrades on your ECU.<br>
<br><b>WHY:</b><br>
If there is a new software upgrade available, you can download it via the github repository or other, on the internet.<br>This is a file that will have the format <strong>"ecu_update_timestamp.tar"</strong>.<br><br>
<b>WHEN</b>
<br>If you install new software, it is best to do this during darkness, because there is no activity in the ECU.<br><br>
<b>UPLOAD:</b><br>Click the 'choose a file' select button. You can select a file with the name <strong>"ecu_update_timestamp.tar"</strong>. <br>ATTENTION check the properties of the file to be sure that you upload the right file.<br>
Click the upload button. Now the file is uploaded to your ecu.<br> when this is done correctly an 'install' button will reveal.<br>
Click this to complete the software upgrade.<br>
<br>In the frame below you can follow the process. When this is done you will see a button 'ok'. Check the results of the upgrade in the frame below.
  <br><br>
  </div>
</div>
 

<div id='msect'>
    <div id='bo'></div>
    <ul>
    <!--<li><a href='menu.html'>done</a></li>-->
    <li><a href='#' onclick='helpfunctie()'>help</a></li>
 <li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';
    </ul>
   </div>

   <div id='msect'>
   <kop>ECU SOFTWARE UPGRADE</kop>
   </div>

<div id='msect'>
<div class='divstijl' style='height:36vh; width: 54vw'>
<center>
<div id="okdiv" style='display:none;position: relative;
  top: 30px;' >
The installation script has run, check the results below and click OK<br>
<br>
<button type='button' class= 'butt' onclick='readyfunction()'>OK</button>
</div>

<div style='border:1px solid; display:block' id='formdiv'>
  <br>
  <form id="updateForm" method="post" enctype="multipart/form-data" action="upload_update.php" target='hiddenFrame'>

  <div>
<label id='laBel' for='fileToUpload' class='lbl'>choose a file</label>

<input type='file' name="fileToUpload" id="fileToUpload" accept ='.tar' required='required' oninput='showButton()' class='inputfile'></div>
  </form>
<h3><div id='show'></h3></div>
<br>

  <div id='subButton' style='display:none'><button class= 'butt' type='button' name='haha' onclick='restsubmit()'>upload</button><br><br></div>

<!-- wat een klotenzooi -->
<form id='installform' target='hiddenFrame' action='/cgi-bin/swUpgrade.pl'></form>
<div id ="installdiv" style='display:none'>
To start the installation of the software upgrade, click install<br><br>
<button type='button' class= 'butt' onclick='installsubmit()'>install</button><br><br>
</div></div>


<br><br>


<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>
</div>
</div><br><center>

<iframe name='hiddenFrame' width='60%' height='200'></iframe>  

<script>
function spinner(){
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

function checkinstallReaction() {
window.frames[0].document.body.innerHTML == ""; 
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkinstallReaction, 500);
   } else {
     hideLoader();
//hide the form including the install button, 
//insteat show another form
document.getElementById("formdiv").style.display="none";
document.getElementById("installdiv").style.display="none";
document.getElementById("subButton").style.display="none";
// show an ok button
document.getElementById("okdiv").style.display="block";
  }
}

function checkulReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkulReaction, 500);
   } else {
   hideLoader();
var reaction = window.frames[0].document.body.innerHTML; 
console.log(reaction);
if( reaction.indexOf("Error") == -1){
document.getElementById("installdiv").style.display="block";
document.getElementById("subButton").style.display="none";
document.getElementById("formdiv").style.display="none";

   } else {
alert("An error occurred, please try again");
   refreshfunction();
   }
  }
}

function showButton() {
var hihi = document.getElementById("fileToUpload").value;
var hoho = hihi.replace(/^.*\\/, "");
//alert("value = " + hoho);
document.getElementById("show").innerHTML=hoho;

//var hoho=document.getElementById("fileToUpload").value;
//alert("showbutton " + hoho);
if(hoho == "") {
alert("you didn't choose a file, try again");
refreshfunction();
} else {
document.getElementById("subButton").style.display="block";
}
}
</script>


</body></html>
