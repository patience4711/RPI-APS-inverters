<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}
function showSubmit() {
document.getElementById("sub").style.display = "block";
}

function pairFunction() {
if(!confirm("are you sure to pair this inverter?")){
   return false;
   }
spinner();
checkReaction();   
document.getElementById('pairform').submit();
 
}

function checkReaction() {
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
   }
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

</script>
<style>
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }
div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}
.loader {
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-bottom: 16px solid #ffff00; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  font-size: 38px;
  color: #ff00ff; 
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
</head>
<body>

<div id='msect'>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>INVERTER PAIRING HELP</h3>
  <b>pairing</b><br>
   Choose the inverter you want to pair. <br>
In the screen below you can follow the process.<br><br>

<b><troubleshooting></b><br>
In case anything goes wrong check the debug information<br>
If no incoming messages check if the coordinator is up.<br>

<br> when successfully paired you will see the obtained inverter ID in the status field.
   
  <br><br>
  </div>
</div>

<div id='msect'>
<ul>
<li><a href='menu.html'>done</a></li>
<li><a href='#' onclick='helpfunctie()'>help</a></li>
</ul>
</div>
<div id='msect'>
<kop>INVERTER PAIRING</kop>
</div>
<div id='msect'>
<center><div class='divstijl' style='height:64vh; width: 94vw'>
<br><br>
<?php

$inverterCount;
if(file_exists("/var/www/ecu_data/inverterCount.txt"))
{
$file = fopen("/var/www/ecu_data/inverterCount.txt","r");
$Count = rtrim(fgets($file));
$inverterCount=(int)$Count;
fclose($file);
} 

else 
{
goto error1;
}

echo "<form id='pairform' method='get' action='/cgi-bin/ecu/inverterPair.pl' oninput='showSubmit()' target='outputFrame'>";
echo "<select class='sb1' name='ivnr'>";
echo "<option selected='selected' disabled='disabled'>Select an inverter</option>";

for ($x = 0; $x < 10; $x++) {
$filename="/var/www/ecu_data/inverters/invProperties" . $x;
if(file_exists($filename)) { 
 echo "<option value='" . $x . "'>INVERTER " . $x . "</option>";
   }
}
echo "</select>";
echo"";
goto phpend;

error1:
echo"<h1>currently no inverter exists, click done</h4>"; 
echo"</body></html><!--"; 

phpend:
?>

</form>

<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>

<br>
<iframe name='outputFrame' width='90%' height='250'></iframe>

<br></div></div>
<div id='msect'>
<ul>
<li id='sub'><a href='#' onclick='pairFunction()'>pair</a></li>
</ul>

<br>

</body></html>