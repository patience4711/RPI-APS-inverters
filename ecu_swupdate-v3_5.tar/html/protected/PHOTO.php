<!DOCTYPE html><html><head><meta charset='utf-8'>

<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<META HTTP-EQUIV="Content-Disposition" CONTENT="inline" />
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="stylesheet" type="text/css" href="/STYLESHEET2.css">
<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}


function restsubmit() {
          window.frames[0].document.body.innerHTML = ""; 
          spinner();
          checkulReaction();   
          document.getElementById("uploadForm").submit();
window.setTimeout('window.location.reload()', 4000);
   } 

function installsubmit() {
        if(!confirm("install the software upgrade ! Are you sure?"))
       { 
          return false;
       }
          window.frames[0].document.body.innerHTML = ""; 
          spinner();
          checkinstallReaction();   
          document.getElementById("installform").submit();
   } 

function dummy(){
var q = 10;
 // do nothing
}
function readyfunction(){
window.location.href = "menu.html";
}
</script>
<style>
.inputfile {
	width: 0.1px;
	height: 0.1px;
	opacity: 0;
	overflow: hidden;
	position: absolute;
	z-index: -1;
}
.lbl {
border:3px solid black;
font-size:20px;
padding: 4px;
color: blue;
background-color:lightgrey;
border-radius: 8px;}
label:hover {
    background-color:red;
}</style>

</head>
<body>
 <div id='msect'>
<div id='bo'></div>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>PHOTO UPLOAD HELP</h3>
  <b>PURPOSE:</b><br>
  With this tool you can upload a photo to your ECU.<br>You can have only one photo at the same time, when you upload another photo, the existing one will be overwritten.
<br><br><b>FILENAME:</b><br>
The upoad accepts only photo's with the name ecu_photo.jpg. <br><br>
<b>FILESIZE:</b>
<br>The size of the photo is limited to 140 kB (140.000 bytes).
<br>If your photo is too large, try to open it with photo software like 'paint' and export it with a size of hight 500pixels. This is usually enough.<br><br>
<b>CHECK:</b>
<br>You can check the results of the upload in the frame below. In case of an error you can try again. <br>If you do not see the expected photo, please delete your browser cache. 
  <br><br>
  </div>
</div>
 

<div id='msect'>
    <div id='bo'></div>
    <ul>
    <!--<li><a href='menu.html'>done</a></li>-->
    <li><a href='#' onclick='helpfunctie()'>help</a></li>
    <li><a href='/photo.html'>view</a></li>
    <li><a href='#' onclick='deletefunction()'>delete</a></li>
  <li style='float:right;'><a href='menu.html'><img src='/close.png' class='icon'></a><li>';

    </ul>
   </div>

   <div id='msect'>
   <kop>ECU PHOTO UPLOAD</kop>
   </div>

<div id='msect'>
<div class='divstijl' style='height:36vh; width: 54vw'>
<center>
<div id="okdiv" style='display:none;position: relative;
  top: 30px;' >
The installation script has run, check the results below and click OK<br>
<br>
<button type='button' class= 'butt' onclick='readyfunction()'>OK</button>
</div>

<div style='border:1px solid; display:block' id='formdiv'>
  <br>
  <form id="uploadForm" method="post" enctype="multipart/form-data" action="upload_photo.php" target='hiddenFrame'>

  <div>
<label id='laBel' for='fileToUpload' class='lbl'>choose a file</label>

<input type='file' name="fileToUpload" id="fileToUpload" accept ='.jpg' required='required' oninput='showButton()' class='inputfile'></div>
  </form>
<h3><div id='show'></h3></div>
<br>

  <div id='subButton' style='display:none'><button class= 'butt' type='button' name='haha' onclick='restsubmit()'>upload</button><br><br></div>

</div>
<form id='delform' action='/cgi-bin/ecu/photoDel.pl' style='display:none' target='hiddenFrame'>
</form>


<br><br>


<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>
</div>
</div><br><center>

<iframe name='hiddenFrame' width='60%' height='200'></iframe>  

<script>
function spinner(){
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
}

function checkinstallReaction() {
window.frames[0].document.body.innerHTML == ""; 
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkinstallReaction, 500);
   } else {
     hideLoader();
//hide the form including the install button, 
//insteat show another form
//document.getElementById("formdiv").style.display="none";
//document.getElementById("installdiv").style.display="none";
//document.getElementById("subButton").style.display="none";
// show an ok button
//document.getElementById("okdiv").style.display="block";
  }
}

function checkulReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkulReaction, 500);
   } else {
   hideLoader();
var reaction = window.frames[0].document.body.innerHTML; 
console.log(reaction);
if( reaction.indexOf("Error") == -1){
document.getElementById("installdiv").style.display="block";
document.getElementById("subButton").style.display="none";
document.getElementById("formdiv").style.display="none";

   } else {
alert("An error occurred, please try again");
   refreshfunction();
   }
  }
}

function showButton() {
var hihi = document.getElementById("fileToUpload").value;
var hoho = hihi.replace(/^.*\\/, "");
//alert("value = " + hoho);
document.getElementById("show").innerHTML=hoho;

//var hoho=document.getElementById("fileToUpload").value;
//alert("showbutton " + hoho);
if(hoho == "") {
alert("you didn't choose a file, try again");
refreshfunction();
} else {
document.getElementById("subButton").style.display="block";
}
}

function deletefunction() {
if(!confirm("are you sure to delete the existing photo?")){
return false;
}
window.frames[0].document.body.innerHTML = ""; 
spinner();
checkulReaction();   
document.getElementById("delform").submit();
window.setTimeout('window.location.reload()', 3000);
}
</script>


</body></html>