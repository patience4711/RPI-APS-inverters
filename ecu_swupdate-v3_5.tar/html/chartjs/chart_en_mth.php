<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="112">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<style type="text/css">

#chart-container {
    width: 90vw;
    height: auto;
    border: 1px solid;
    background: white;
    font-color:yellow;
}
canvas{
  width:90vw !important;
  height:30vw !important;
}
@media only screen and (max-width: 800px) {
canvas{ 
  height:36vh !important;
  }
}
@media screen and (max-width: 800px) and (orientation: landscape) {
canvas{ 
  height:300px !important;
  }
}

/*
.butt {
  font-size:26px; 
  heigth:34px;
    border: 2px solid black;
  border-radius:6px;
  
}
*/
.close {
  color: red;
  float: right;
  font-size: 58px;
  font-weight: bold;
  cursor: pointer;
padding: 0px 20px 0px 0px; /* trbl */
}
.close:hover {color: green;}


</style>
<script>

function submitFunction(a) {
//alert("value of maand = " + 
var terug = "chart_en_mth.php?inv=" + a; 
//document.getElementById('maand').value;
document.getElementById("bo").innerHTML="<br>wait...<br>quering<br>this<br>chart"; 
document.getElementById("bo").style.display="block"; 
document.getElementById('formulier').submit();
//setTimeout(function(){window.location.href='chart_en_mth.php';}, 3000 ); 
setTimeout(function(){window.location.href=terug;}, 3000 ); 
}

var message = "viewing this page is not allowed!";
function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }
if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }
document.onmousedown = rtclickcheck;

</script>

</head>
<body>

<script type="text/javascript" src="chart.min.js"></script>

<script type="text/javascript" src="jquery.min.js"></script>


<div id='bo'></div>
<div id='msect'>
   <div class='divstijl'><center>

<?php
// read the parameters in the url
$invnr = $_GET['inv'];
$goBack = $_GET['page'];
// compose the link
if($goBack == 0) {  
echo '<a href="/index.php"><span class="close">&times;</span></a><br>';
} else {
echo '<a href="/invpage.php?inv=' . $invnr . '"><span class="close">&times;</span></a><br>';
}


//echo '<a href="/invpage.php?inv=' . $invnr . '"><span class="close">&times;</span></a><br>';

$name="daily energy inverter " . $invnr; //chart tittle
//echo"<h3>ENERGY INVERTER " . $invnr . "</h3>";


// *******  the form for the date select **********
// first read chartmonth to put the value in the select
// if we don't do that our date value = 0


$myFile = "/var/www/ecu_data/chartMonth.txt";
// we check if file exists and not empty
if(file_exists($myFile) && filesize($myFile)){
$lines = file($myFile);//file in to an array
$dat = $lines[0]; 
//$flagDate = $lines[1]; 
$datum = new DateTime("$dat");
$datum = $datum->format("Y-m");
//echo "datum = " . $datum;
} else {
$datum = date('Y-m-d');
}

//echo "<h4>vlagDatum = " . $vlagDatum . "</h4>";

$today = date('Y-m-d');
// if today = datum there was no entry in the file
// if filesize = 0 there was no entry un the fike
//if ($today != $datum) {
if (filesize($myFile) ){
//echo "found that we should show a regular month chart";
$namepe="daily energy inverter " . $invnr; //  chart title 
} else {
//echo $datum . " not equal to " . $today;
$namepe="last 14 days yield inverter " . $invnr; //  chart title 
}

echo "<form id='formulier' action='writeMonth.php' target='hiddenFrame' method='post' onchange='submitFunction(" . $invnr . ")'>";
echo"<table><tr><td><input type='month' name='maand' id='maand' value='" . $datum . "' style='width: 220px;' >";
echo "</input></form></td>";
echo "</table>";


?>
<br>
<div id="chart-container">
  <canvas id="graphCanvas"></canvas>
</div>
<br>
</div></div>

<script>
var naam = "<?php echo $namepe; ?>"; // chart tittle lable
var w = "chartdata_en_mth.php?inv=" + "<?php echo $invnr; ?>"; 
//alert("w = " + w);      

$(document).ready(function () {showGraph();});

   function showGraph()
   {
     {
     $.post(w, function (data)
      
       {
    
    var time = [];
    var energy = []; 
    jsonObj = eval("("+data+")");
    console.log("jsonObj = " + jsonObj);
     var lengte = jsonObj.length; 
     console.log("lengte = " + lengte);
     if(jsonObj.length===0){
     console.log("obj = null");
     var canvas = document.getElementById('graphCanvas');
     var ctx = canvas.getContext("2d");
     ctx.font = "30px Arial";
     ctx.fillText("no data available",30,70);
     ctx.globalCompositeOperation = 'destination-over'
     // Now draw!
     ctx.fillStyle = "#ffcce0";
     ctx.fillRect(0, 0, canvas.width, canvas.height);
     return;    
     }

    for(var i in jsonObj)
    {
    tijd = jsonObj[i].time.substr(0,10);
    
    time.push(tijd);
    energy.push(jsonObj[i].e);

    }
                     
     var chartdata = {
        labels: time,
       datasets: [
            {
               label: naam,
               backgroundColor: '#ff99e6',
               borderColor: '#4d0039',
               borderWidth: 1,
               pointBorderWidth: 2,
               pointRadius: 1,
               hoverBackgroundColor: '#CCCCCC',
               hoverBorderColor: '#666666',
               data: energy,
               },]
            }

                var graphTarget = $("#graphCanvas");

                var barGraph = new Chart(graphTarget, {
                    type: 'bar',
                    data: chartdata,
                 options: {
    responsive: true,
    plugins: {
         legend: {
           labels: {
             color: "#000099",
                font: {
                  size: 18,
                 }
               }
          }    
   },

    maintainAspectRatio: false,
                    scales: {
 y: { 
    title: { 
       display: true,
       color: 'red', 
      text: 'Watt/hour',
      },
     grid: {
        color: 'lightgrey'
      },
     ticks: {
        color: 'red',
     }
   }//end y:
}
                    }

                 });
             });
          }
      }
      </script>
<br><center><iframe name='hiddenFrame' width='420' height='100'  hidden></iframe>  
</body>
</html>
