<?php
/*
this page queries the values from invEnergy invx per month
also queries the last entry of energy in invData invx when
the query is over the currnt month
If that value != null we add it to the first query
so that we have a value for the present day.
At midnight the value in invData is copied to invEnergy
and the value in inv is set to null.
*/

// we need to read which inverter we want
// so we read the file invChoice.txt
// $invnr = file_get_contents("/ramdisk/invChoice.txt");
// we read the inverternr from the url
$invnr = $_GET['inv'];
$from="inv". $invnr; // to be used in the query

$myFile = "/var/www/ecu_data/chartMonth.txt";
if( file_exists($myFile) && filesize($myFile) ){
//echo "file exists and not empty";
$lines = file($myFile);//file in to an array
$datum = $lines[0]; 
//$flagDate = $lines[1]; 
rtrim($datum, "\r\n");
} else {
//echo "file not exists or empty<br>";
$datum = date('Y-m');
//norMal = 0;
}
// now decide what kind of char we get
// so if there is no date in the file
// we have the last 2 weeks chart

if ( filesize($myFile) ) {
//echo "filesize = not nill";
$norMal = 1; 
} else {
//echo "filesize = 0<br>";
$norMal = 0;
}

//echo "<br><br>***********************************<br><br>";
if (date_default_timezone_get()) {
$tz = date_default_timezone_get();
}

require '/usr/lib/cgi-bin/ecu/vendor/autoload.php';
$host = "127.0.0.1";
$port = "8086";
$dbname= "invEnergy";
//get connection

$client = new InfluxDB\Client($host, $port);

// the timestamp in the database = utc time, so the
// entries at midnight are at 23.00


// ******* select e in invEnergy *****************
$database = $client->selectDB('invEnergy');
//echo "norMal = " . $norMal . "<br>"; //$norMal="0";
if ($norMal == "1") {
$begin = new DateTime("$datum"); // first of the month
//$begin->modify("-1 day");
$begin = $begin->format("Y-m-d 02:i:s");
//echo "begin = " . $begin;
$eind = new DateTime("$datum");
$eind->modify("+1 month -1 day");

$end = $eind->format("Y-m-d 23:30:s");

// all the values are utctime 23:00
$query="SELECT e FROM {$from} where time > '{$begin}' and time < '{$end}'";
//echo "<br>" . $query . "<br>";
} else {

$today = date("Y-m-d");

$eind = new DateTime($today);
$eind->modify("-1 day");
$eind = $eind->format("Y-m-d 23:30:s");

$begin = new DateTime($today);
$begin->modify('-2 week');
$begin = $begin->format("Y-m-d");

//$query="SELECT e FROM {$from} where time < '{$eind}' ORDER BY //time DESC LIMIT 20";
$query="SELECT e FROM {$from} where time > '{$begin}' and time < '{$eind}'";
//echo $query;
}
//echo "<br><br>\n\n\n\n *************************************<br><br> \n";

$result=$database->query($query);
$points = $result->getPoints();

// now we decide if we should add the present day
// we only do this when the current month = 
// equal to the queried month
// if the month is the current month we do the following
$curMonth = (int)date('m');
//echo "curMonth = " . $curMonth . "<br>";
$desMonth = (int)substr($datum, 5, 2);
//echo "desMonth = " . $desMonth . "<br>";

if($desMonth == $curMonth ) {
//echo "they are equal, adding present day so far";

// ******* select sum e in invData for today *****************
$begin = date("Y-m-d 03:i:s");
$eind = date("Y-m-d 23:i:s");

$result = "";
$dbname= "invData";
$database = $client->selectDB('invData');

$query="SELECT sum(e) FROM {$from} where time > '{$begin}' and time < '{$eind}' tz('$tz')"; // gives sum(e)
$result=$database->query($query);
$paints = $result->getPoints();
$sum = $paints[0]["sum"];
//echo "sum = " .$sum;

// we need to know if the e value = null

if($sum <= 0) { 
//echo "\nfound null value\n";
$points = json_encode($points);
} 
else 
{
//echo "found a value so we merge the array's";
$mix=array_merge($points, $paints);
$points = json_encode($mix);
$points = str_replace("sum","e", $points);
}

} else { // end if desMonth == curMonth
//echo "they are not equal";
$points = json_encode($points);
}

echo $points;

?>
