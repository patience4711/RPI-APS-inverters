<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>RPI-ECU</title>
<meta http-equiv="refresh" content="112">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<SCRIPT language=JavaScript>

var message = "viewing this page is disabled!";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;
</SCRIPT>

<style>
body {
 background-color: #EEE;
}

table, th, td {
   border: 1px solid blue; 
 border-collapse: collapse;
  font-size:14px; 
  padding:2px;
  }

.colwidth0, .colwidth1, .colwidth2 {
background-color:lightgreen;
}
.colwidth1 {width: 76px;}
.colwidth2 {width: 70px;}
.colwidth0 {width: 38px;}

.nm{
  font-weight: bold;
  text-align: center;
  Background-color:lightgreen;
  }

/* .nm {Background-color:lightgreen;} */

#ch0, #ch1, #ch3 { 
  font-size:18px;
  font-weight:bold;
  text-align: center;
  type:text;
  }
#ch3 { background-color:#e6b3cc;}
#ch1 { background-color:#94b8b8;}
#ch0 { font-size: 16px;}
#ch4 { background-color: #99cc00; border:none}

@media only screen and (max-width: 800px) {
#ch0, #ch1, #ch3 { 
  font-size:16px;
  } 

.colwidth1 {width: 80px;}
.colwidth2 {width: 50px;}
.colwidht0 {width: 38px;}

}

.linkbt {
  width: 72px;
  height: 36px;
  border-radius: 10px;
  border: solid 1px #29293d; 
  box-shadow: 0 5px #29293d; /*r u u d */
  padding: 0px 2px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size:18px;
  font-weight: bold; 
  color: black;
  background-image:
    radial-gradient(
      
      rgb(255, 255, 0), 
      green 90%

    );
}
.linkbt:hover {background-image: linear-gradient(red, yellow, green);}

.linkbt:active {
  background-color: #3e8e41;
  box-shadow: 0 2px #666;
  transform: translateY(4px);
}

</style></head>
<!--
// *****************************************************
//                     B O D Y 
// *****************************************************
-->
<body style="font-family: 'lato',Verdana,Sans-serif;font-size:16px;">

<center>
<a href="/index.php"><span class="close">&times;</span></a><br>


<?php
// we first need to know if it is nighttime
//we can check if exists /ramdisk/sleepFlag.txt
$fn = "/ramdisk/sleepFlag.txt";
if(!file_exists($fn)) {
 $bac="linear-gradient(#e8edc8, #c8eaed)"; $clr="green";
} else { 
$bac="grey"; $clr="white";
}
//get invnr from the request
$invnr = $_GET['inv']; 
// save the invnr to invChoice
//file_put_contents('/var/www/ecu_data/invChoice.txt', $invnr);
//file_put_contents('/ramdisk/invChoice.txt', $invnr);
/*
# *****************************************************
# *    READING INV PROPERTIES AND DATA                *
# *****************************************************
*/

// we dont have to check if invProperties exists
// so the file exists, we read it
$filename="/var/www/ecu_data/inverters/invProperties" . $invnr;
$jsan = file_get_contents($filename);
$orr = json_decode($jsan, true);
$name = $orr["name"];
//$type = $orr["type"];

$p0a=$orr["panels"][0];
$p1a=$orr["panels"][1];
$p2a=$orr["panels"][2];
$p3a=$orr["panels"][3];
//echo "type = " . $type;
//echo "panels". $p0a . $p1a. $p2a . $p2a;
$panel0 = "1";
$panel1 = "2";
$panel2 = "3";
$panel3 = "4";

$filename = "/ramdisk/invData" . $invnr;
//echo"<h3> filename = ". $filename . "</h3>";
if(file_exists($filename)) 
{ 
  $json = file_get_contents($filename);
  $arr = json_decode($json, true);

  $pwt = floatval($arr["totalpw"]);
  $ent = floatval($arr["totalenStack"]);
  $temp = $arr["heath"];
  $freq = $arr["freq"];
  $acv = $arr["acv"];

  if($p0a == 1) {
    $dcv0 = $arr["dcv"][0];
    $dcc0 = $arr["dcc"][0];
    $pw0 = $arr["pwr"][0];
    $en0 = $arr["enStack"][0];
    } else {
    $pw0 = $en0 = "n/e";
    $panel0 = "n/e";
  }
  
  if($p1a == 1) {
    $dcv1 = $arr["dcv"][1];
    $dcc1 = $arr["dcc"][1];

    $pw1 = $arr["pwr"][1];
    $en1 = $arr["enStack"][1];
    } else {
    $pw1 = $en1 = "n/e";
    $panel1 = "n/e";
  }

  if($p2a == 1) {
    $dcv2 = $arr["dcv"][2];
    $dcc2 = $arr["dcc"][2];

    $pw2 = $arr["pwr"][2];
    $en2 = $arr["enStack"][2];
    } else {
    $pw2 = $en2 = "n/e";
    $panel2 = "n/e";
  }
  
    if($p3a == 1) {
    $dcv3 = $arr["dcv"][3];
    $dcc3 = $arr["dcc"][3];

    $pw3 = $arr["pwr"][3];
    $en3 = $arr["enStack"][3];
    } else {
    $pw3 = $en3 = "n/e";
    $panel3 = "n/e";
  }

  } // the file exists


/*
# *****************************************************
# *      FORM THE PAGE AND DATA TABLE                 *
# *****************************************************
*/
echo "<center><h2>today's data " . $name . "</h2>";

echo "<div class='divstijl' style='background:" . $bac . ";'><center><br>";

echo "<center><table style='border:1px solid black; background-color:#c2c2d6;'><tr style='font-weight:bold; font-size:14px; text-align:center; border:none;'>";

echo"<td class='colwidth0'>panel<td class='colwidth1'>dc Volts<td class='colwidth1'>dc Amp<td class='colwidth2'>power W<td class='colwidth2'>nrg Wh</td></tr>";

$panelcount=0;
if($p0a == 1) {
echo "<tr><td class='nm'>" . $panel0;
echo "<td id='ch0'>" . $dcv0;
echo "<td id='ch0'>" . $dcc0;
echo "<td id='ch1'>" . $pw0;
echo "<td id='ch1'>" . $en0;
$panelcount = $panelcount + 1;
}
if($p1a == 1) {
echo "<tr><td class='nm'>" . $panel1;
echo "<td id='ch0'>" . $dcv1;
echo "<td id='ch0'>" . $dcc1;
echo "<td id='ch1'>" . $pw1;
echo "<td id='ch1'>" . $en1;
$panelcount = $panelcount + 1;
}
if($p2a == 1) {
echo "<tr><td class='nm'>" . $panel2;
echo "<td id='ch0'>" . $dcv2;
echo "<td id='ch0'>" . $dcc2;
echo "<td id='ch1'>" . $pw2;
echo "<td id='ch1'>" . $en2;
$panelcount = $panelcount + 1;
}
if($p3a == 1) {
echo "<tr><td class='nm'>" . $panel3;
echo "<td id='ch0'>" . $dcv3;
echo "<td id='ch0'>" . $dcc3;
echo "<td id='ch1'>" . $pw3;
echo "<td id='ch1'>" . $en3;
$panelcount = $panelcount + 1;
}
if($panelcount > 0) {

echo "<tr style='font-weight:bold; text-align:center; height:48px;'>";
echo "<td id='ch3' colspan='2'><a href='chartjs/stats_e.php?inv=" . $invnr . "'><button class='linkbt' style='width:94px;'>statistics</button></a>";

echo "<td class='colwidth1' style='font-size:18px'>totals"; 

echo "<td id='ch3'><a href='/chartjs/chart_pe.php?page=1&inv=" . $invnr . "'><button class='linkbt'>" . number_format($pwt, 1, '.', '') . "</button></a>"; 

echo "<td id='ch3'><a href='/chartjs/chart_en_mth.php?page=1&inv=" . $invnr . "'><button class='linkbt'>" . number_format($ent, 1, '.', '') . "</button></a>"; 
//echo "<td id='ch3'>" . number_format($ent, 1, '.', ''); 
}


echo "<tr><td class='nm' colspan='2'>temperature<td id='ch0'>" . $temp . " &deg;C";

echo "<td id='ch4' colspan='2' rowspan='3'><a href='photo.html'><img style='display:block; border: 2px solid #99cc00;' src='pics/ecu_photo.jpg' width='96%' height='124px' alt='default.jpg' onerror='this.onerror=null;this.src=this.alt;'></a></td>";

echo "<tr><td class='nm' colspan='2'>frequency<td id='ch0'> " . $freq . " Hz ";
echo "<tr><td class='nm' colspan='2'>ac voltage<td id='ch0'> " . $acv . " V";


echo "</table>";

//skip1:
//echo "<center>" . $error;
 // end for loop

echo "<pre><span style='color:" . $clr . "'>Powered by Hansiart</span></pre><br>";

?>
</div>

<br><center><iframe name='hiddenFrame' width='420' height='100' hidden ></iframe>  </body>
 </html> 

