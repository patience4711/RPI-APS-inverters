<!DOCTYPE html><html><head><meta charset='utf-8'>
<meta http-equiv="refresh" content="200">
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">
<style>
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }
div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}

html {
  scroll-behavior: smooth;
 }
</style>
<script>
function scrollDown(){
document.getElementById('down').scrollIntoView(true);
}
</script>
</head>
<body onload="scrollDown()">
<div style='position:fixed;'>
  <div id='msect'>
    <div id='bo'></div>
    <form id="clear" action="/cgi-bin/ecu/logClear.pl" target="hiddenFrame"> </form>
    <ul>
    <!--<li><a href='details.php'>done</a></li>-->
    <li><a href="#up">up</a><li>
    <li><a href="#down">down</a><li>
    <li style='float:right;'><a href='index.php'><img src='close.png' class='icon'></a><li>
</ul>
</div>   

   <div id='msect'>
   <kop>RPI-ECU MEMORANDUM</kop>
   </div>
</div>
<div id='msect'>
<div class='divstijl' id='up' style='width: 94vw'>
<center><br><br><br><br><br><br>
<?php

$filename="/var/www/ecu_data/notes.txt";

if(file_exists($filename)) { 
//echo "file exists";
  foreach(file($filename) as $line) { 
      echo "<br>" . $line;
    } 
   

} else {
goto error1;
}

//echo $log;

goto phpend;

error1:
echo"<h1>currently no memo's exists, click done</h4>"; 
echo"</body></html><!--"; 

phpend:
?>
<div id='down'></div>
<iframe name='hiddenFrame' width='420' height='100' hidden></iframe>  

<br>
</body></html>