<!DOCTYPE html><html><head><meta charset='utf-8'>
<title>ESP-ECU</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" type="image/x-icon" href="/favicon.ico" />
<link rel="stylesheet" type="text/css" href="/STYLESHEET.css">

<script type='text/javascript'>

function helpfunctie() {
document.getElementById("help").style.display = "block";
}
function sl() {  
document.getElementById("help").style.display = "none";
}

function hideLoader() {
document.getElementById('waitDiv').style.visibility = 'hidden';
}

function refreshfunction() {
location.reload();
}

</script>
<style>

.butt {
  font-size:24px; 
  heigth:34px;
    border: 2px solid black;
  border-radius:6px;
  box-shadow: 5px 10px #888888;

}
.cap {
  font-weight:bold; 
  Background-color:lightgreen;
 }

div.overlay {
  display: block;
  width: 100%;
  height: 100%;
  background-color: rgba(0,0,0,0.7);
  z-index: 0;
  text-align: center;
  vertical-align: middle;
  line-height: 300px;
}

.loader {
  border: 16px solid #f3f3f3; /* Light grey */
  border-top: 16px solid #3498db; /* Blue */
  border-bottom: 16px solid #ffff00; /* Blue */
  border-radius: 50%;
  width: 120px;
  height: 120px;
  font-size: 38px;
  color: #ff00ff; 
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
</head>
<body>

<div id='msect'>
  <div id="help">
  <span class='close' onclick='sl();'>&times;</span><h3>RECOVER HELP</h3>
For security reasons this page is only accessible from users in your own network.<br><br>

If you forgot the credentials for the website of your ECU<br>
you can wipe your wifi credentials too.<br><br>

After reboot the ECU will start the wifi accesspoint where you can re-enter all credentials.<br><br>

<br><br>In the screen below you can follow the process.<br><br>

  </div>
</div>

<div id='msect'>
<ul>
<li><a href='menu.html'>done</a></li>
<li><a href='#' onclick='helpfunctie()'>help</a></li>
</ul>
</div>
<div id='msect'>
<kop>RESET WIFI CREDENTIALS</kop>
</div>
<div id='msect'>
<center><div class='divstijl' style='height:100vh; width: 94vw'>
<br>

<div id='refreshdiv' style='visibility: hidden; position:absolute; top: 140px; left: 35vw; z-index: 10;'><button class='butt' onclick='refreshfunction()'>send another command</button></div>

<div id='formdiv' style='visibility: visible;'></>
<select id='sel' class='sb1' name"actionSelect" onchange="actionFunction()">
<option selected readonly>CHOOSE AN ACTION</option>
<option value='7'>remove wifi credentials</option>

</select>

<div id='waitDiv' style='position:absolute; top: 200px; left: 36vw; visibility: hidden; z-index: 10;'></div>

<iframe id='of' name='outputFrame' width='90%' height='450'></iframe>


<form id='wipe_cr' action='/cgi-bin/ecu/wifi/wipe_wificredentials.pl' style='display:none' target='outputFrame'></input></form>

</body>

<script>

function spinner(){
//alert("alertbox");
document.getElementById('waitDiv').innerHTML = "<div class='loader'><div>";
document.getElementById('waitDiv').style.visibility = 'visible';
//setTimeout( function() { hideLoader(); }, 1000);
}

function actionFunction() 
{

// we change the visibility for the inputs
   document.getElementById("formdiv").style.visibility = 'hidden';
   document.getElementById("refreshdiv").style.visibility = 'visible';
   
   b=document.getElementById("sel").value;
   

    if(b==7) // remove wifi credentials 
   {
       if(!confirm("This command will delete your wificredentials. At reboot the system will start the accesspoint radioAP ! ! ! \n\n Are you sure you want this? (see help)"))
       {
          location.reload() 
          return false;
       }
          spinner();
          checkReaction();   
          document.getElementById("wipe_cr").submit();
   } 


}

function checkReaction() {
//spinner();
if(window.frames[0].document.body.innerHTML == "") {
   window.setTimeout(checkReaction, 500);
   } else {
   hideLoader();
}
}

</script>
</html>